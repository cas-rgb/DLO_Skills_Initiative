import { sql } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  text,
  integer,
  boolean,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";

// Session storage table for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  role: varchar("role").default("learner"), // learner, facilitator, admin
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Course table - simplified structure
export const courses = pgTable("courses", {
  id: varchar("id").primaryKey(),
  title: varchar("title").notNull(),
  shortName: varchar("short_name").notNull(),
  description: text("description").notNull(),
  category: varchar("category").notNull(),
  level: varchar("level").notNull().default("beginner"), // beginner, intermediate, advanced
  duration: integer("duration").notNull(), // in hours
  isPublished: boolean("is_published").default(true),
  facilitatorId: varchar("facilitator_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Course sections - Moodle-like structure
export const courseSections = pgTable("course_sections", {
  id: varchar("id").primaryKey(),
  courseId: varchar("course_id").references(() => courses.id, { onDelete: 'cascade' }),
  title: varchar("title").notNull(),
  description: text("description"),
  orderIndex: integer("order_index").notNull(),
  visible: boolean("visible").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Course modules/activities within sections
export const courseModules = pgTable("course_modules", {
  id: varchar("id").primaryKey(),
  courseId: varchar("course_id").references(() => courses.id, { onDelete: 'cascade' }),
  sectionId: varchar("section_id").references(() => courseSections.id, { onDelete: 'cascade' }),
  title: varchar("title").notNull(),
  description: text("description"),
  content: text("content").notNull(),
  videoUrl: varchar("video_url"), // YouTube or other video URLs
  type: varchar("type").notNull().default("lesson"), // lesson, quiz, assignment, resource
  orderIndex: integer("order_index").notNull(),
  duration: integer("duration").default(0), // in minutes
  isAvailable: boolean("is_available").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Student enrollments
export const enrollments = pgTable("enrollments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id, { onDelete: 'cascade' }),
  courseId: varchar("course_id").references(() => courses.id, { onDelete: 'cascade' }),
  enrolledAt: timestamp("enrolled_at").defaultNow(),
  completedAt: timestamp("completed_at"),
  progress: integer("progress").default(0), // percentage 0-100
});

// Module completion tracking
export const moduleCompletions = pgTable("module_completions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id, { onDelete: 'cascade' }),
  moduleId: varchar("module_id").references(() => courseModules.id, { onDelete: 'cascade' }),
  completedAt: timestamp("completed_at").defaultNow(),
});

// Audio completion tracking
export const audioCompletions = pgTable("audio_completions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id, { onDelete: 'cascade' }),
  moduleId: varchar("module_id").references(() => courseModules.id, { onDelete: 'cascade' }),
  completedAt: timestamp("completed_at").defaultNow(),
});

// Quiz completion tracking for individual module quizzes
export const moduleQuizCompletions = pgTable("module_quiz_completions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id, { onDelete: 'cascade' }),
  moduleId: varchar("module_id").references(() => courseModules.id, { onDelete: 'cascade' }),
  score: integer("score").notNull(), // 0-100 percentage
  answers: jsonb("answers"), // Store user's answers for review
  completedAt: timestamp("completed_at").defaultNow(),
});

// Quiz table
export const quizzes = pgTable("quizzes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  courseId: varchar("course_id").references(() => courses.id, { onDelete: 'cascade' }),
  moduleId: varchar("module_id").references(() => courseModules.id, { onDelete: 'cascade' }),
  title: varchar("title").notNull(),
  description: text("description"),
  instructions: text("instructions"),
  timeLimit: integer("time_limit"), // in minutes, null for no limit
  passingScore: integer("passing_score").default(70), // percentage
  maxAttempts: integer("max_attempts").default(3), // null for unlimited
  shuffleQuestions: boolean("shuffle_questions").default(false),
  showCorrectAnswers: boolean("show_correct_answers").default(true),
  availableFrom: timestamp("available_from"),
  availableUntil: timestamp("available_until"),
  isPublished: boolean("is_published").default(false),
  createdBy: varchar("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Quiz questions
export const quizQuestions = pgTable("quiz_questions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  quizId: varchar("quiz_id").references(() => quizzes.id, { onDelete: 'cascade' }),
  type: varchar("type").notNull().default("multiple_choice"), // multiple_choice, true_false, short_answer, essay
  question: text("question").notNull(),
  options: jsonb("options"), // Array of answer options for multiple choice
  correctAnswer: text("correct_answer"), // For multiple choice: option index/text, for others: correct answer
  explanation: text("explanation"), // Explanation shown after answering
  points: integer("points").default(1),
  orderIndex: integer("order_index").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Quiz attempts by students
export const quizAttempts = pgTable("quiz_attempts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  quizId: varchar("quiz_id").references(() => quizzes.id, { onDelete: 'cascade' }),
  userId: varchar("user_id").references(() => users.id, { onDelete: 'cascade' }),
  attemptNumber: integer("attempt_number").notNull(),
  startedAt: timestamp("started_at").defaultNow(),
  submittedAt: timestamp("submitted_at"),
  timeSpent: integer("time_spent"), // in seconds
  score: integer("score"), // percentage 0-100
  totalPoints: integer("total_points"),
  earnedPoints: integer("earned_points"),
  isPassed: boolean("is_passed").default(false),
  feedback: text("feedback"), // Overall feedback from instructor
  gradedAt: timestamp("graded_at"),
  gradedBy: varchar("graded_by").references(() => users.id),
});

// Individual question responses
export const quizResponses = pgTable("quiz_responses", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  attemptId: varchar("attempt_id").references(() => quizAttempts.id, { onDelete: 'cascade' }),
  questionId: varchar("question_id").references(() => quizQuestions.id, { onDelete: 'cascade' }),
  response: text("response"), // Student's answer
  isCorrect: boolean("is_correct"),
  pointsEarned: integer("points_earned").default(0),
  feedback: text("feedback"), // Question-specific feedback
  answeredAt: timestamp("answered_at").defaultNow(),
});

// Module narration scripts and audio files
export const moduleNarrations = pgTable("module_narrations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  moduleId: varchar("module_id").unique().references(() => courseModules.id, { onDelete: 'cascade' }),
  teacherScript: text("teacher_script"), // Generated teacher narration script
  audioFilePath: varchar("audio_file_path"), // Path to the generated audio file
  voiceType: varchar("voice_type").default("en-US-Neural2-F"), // Google TTS voice selection
  generatedAt: timestamp("generated_at"),
  scriptGeneratedAt: timestamp("script_generated_at"),
  audioGeneratedAt: timestamp("audio_generated_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Relations
export const courseRelations = relations(courses, ({ many }) => ({
  sections: many(courseSections),
  modules: many(courseModules),
  enrollments: many(enrollments),
}));

export const sectionRelations = relations(courseSections, ({ one, many }) => ({
  course: one(courses, {
    fields: [courseSections.courseId],
    references: [courses.id],
  }),
  modules: many(courseModules),
}));

export const moduleRelations = relations(courseModules, ({ one, many }) => ({
  course: one(courses, {
    fields: [courseModules.courseId],
    references: [courses.id],
  }),
  section: one(courseSections, {
    fields: [courseModules.sectionId],
    references: [courseSections.id],
  }),
  completions: many(moduleCompletions),
}));

export const enrollmentRelations = relations(enrollments, ({ one }) => ({
  user: one(users, {
    fields: [enrollments.userId],
    references: [users.id],
  }),
  course: one(courses, {
    fields: [enrollments.courseId],
    references: [courses.id],
  }),
}));

export const moduleCompletionRelations = relations(moduleCompletions, ({ one }) => ({
  user: one(users, {
    fields: [moduleCompletions.userId],
    references: [users.id],
  }),
  module: one(courseModules, {
    fields: [moduleCompletions.moduleId],
    references: [courseModules.id],
  }),
}));

export const quizRelations = relations(quizzes, ({ one, many }) => ({
  course: one(courses, {
    fields: [quizzes.courseId],
    references: [courses.id],
  }),
  module: one(courseModules, {
    fields: [quizzes.moduleId],
    references: [courseModules.id],
  }),
  creator: one(users, {
    fields: [quizzes.createdBy],
    references: [users.id],
  }),
  questions: many(quizQuestions),
  attempts: many(quizAttempts),
}));

export const quizQuestionRelations = relations(quizQuestions, ({ one, many }) => ({
  quiz: one(quizzes, {
    fields: [quizQuestions.quizId],
    references: [quizzes.id],
  }),
  responses: many(quizResponses),
}));

export const quizAttemptRelations = relations(quizAttempts, ({ one, many }) => ({
  quiz: one(quizzes, {
    fields: [quizAttempts.quizId],
    references: [quizzes.id],
  }),
  user: one(users, {
    fields: [quizAttempts.userId],
    references: [users.id],
  }),
  grader: one(users, {
    fields: [quizAttempts.gradedBy],
    references: [users.id],
  }),
  responses: many(quizResponses),
}));

export const quizResponseRelations = relations(quizResponses, ({ one }) => ({
  attempt: one(quizAttempts, {
    fields: [quizResponses.attemptId],
    references: [quizAttempts.id],
  }),
  question: one(quizQuestions, {
    fields: [quizResponses.questionId],
    references: [quizQuestions.id],
  }),
}));

// Type exports
export type User = typeof users.$inferSelect;
export type UpsertUser = typeof users.$inferInsert;
export type Course = typeof courses.$inferSelect;
export type InsertCourse = typeof courses.$inferInsert;
export type CourseSection = typeof courseSections.$inferSelect;
export type InsertCourseSection = typeof courseSections.$inferInsert;
export type CourseModule = typeof courseModules.$inferSelect;
export type InsertCourseModule = typeof courseModules.$inferInsert;
export type Enrollment = typeof enrollments.$inferSelect;
export type InsertEnrollment = typeof enrollments.$inferInsert;
export type ModuleCompletion = typeof moduleCompletions.$inferSelect;
export type InsertModuleCompletion = typeof moduleCompletions.$inferInsert;
export type AudioCompletion = typeof audioCompletions.$inferSelect;
export type InsertAudioCompletion = typeof audioCompletions.$inferInsert;
export type ModuleQuizCompletion = typeof moduleQuizCompletions.$inferSelect;
export type InsertModuleQuizCompletion = typeof moduleQuizCompletions.$inferInsert;
export type Quiz = typeof quizzes.$inferSelect;
export type InsertQuiz = typeof quizzes.$inferInsert;
export type QuizQuestion = typeof quizQuestions.$inferSelect;
export type InsertQuizQuestion = typeof quizQuestions.$inferInsert;
export type QuizAttempt = typeof quizAttempts.$inferSelect;
export type InsertQuizAttempt = typeof quizAttempts.$inferInsert;
export type QuizResponse = typeof quizResponses.$inferSelect;
export type InsertQuizResponse = typeof quizResponses.$inferInsert;