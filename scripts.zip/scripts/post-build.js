#!/usr/bin/env node
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(__dirname, '..');

// Copy built files from dist/public to server/public for production serving
const sourceDir = path.join(projectRoot, 'dist', 'public');
const targetDir = path.join(projectRoot, 'server', 'public');

console.log('Post-build: Copying static files for production deployment...');

if (fs.existsSync(sourceDir)) {
  // Create target directory if it doesn't exist
  if (!fs.existsSync(targetDir)) {
    fs.mkdirSync(targetDir, { recursive: true });
  }

  // Copy all files from source to target
  function copyRecursive(src, dest) {
    const stats = fs.statSync(src);
    if (stats.isDirectory()) {
      if (!fs.existsSync(dest)) {
        fs.mkdirSync(dest, { recursive: true });
      }
      const files = fs.readdirSync(src);
      files.forEach(file => {
        copyRecursive(path.join(src, file), path.join(dest, file));
      });
    } else {
      fs.copyFileSync(src, dest);
    }
  }

  copyRecursive(sourceDir, targetDir);
  console.log(`✅ Static files copied from ${sourceDir} to ${targetDir}`);
} else {
  console.error(`❌ Source directory not found: ${sourceDir}`);
  process.exit(1);
}

console.log('✅ Post-build script completed successfully');