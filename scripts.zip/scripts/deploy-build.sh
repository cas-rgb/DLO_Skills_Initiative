#!/bin/bash

# Deployment build script for DLO Academy
# This script ensures all build steps are completed for successful deployment

echo "🚀 Starting deployment build process..."

# Step 1: Run the standard build process
echo "📦 Building application..."
npm run build

# Check if build was successful
if [ $? -ne 0 ]; then
  echo "❌ Build failed"
  exit 1
fi

# Step 2: Run post-build script to copy static files
echo "📂 Running post-build tasks..."
node scripts/post-build.js

# Check if post-build was successful
if [ $? -ne 0 ]; then
  echo "❌ Post-build tasks failed"
  exit 1
fi

echo "✅ Deployment build completed successfully!"
echo "🌟 Application is ready for production deployment"