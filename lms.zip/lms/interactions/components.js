// JET 101 Interactive Components and Quiz System

// Global state management
const JETState = {
    currentUser: null,
    currentModule: null,
    quizProgress: {},
    scenarioResponses: {},
    tutorHistory: [],
    actionPlan: null
};

// Initialize module
function initializeModule(moduleId) {
    JETState.currentModule = moduleId;
    loadModuleProgress(moduleId);
    console.log(`Module ${moduleId} initialized`);
}

// Quiz System
class QuizEngine {
    constructor() {
        this.quizzes = {};
        this.loadQuizData();
    }

    async loadQuizData() {
        // Quiz data for each module
        this.quizzes = {
            m1: {
                title: "Module 1: Introduction to JET",
                questions: [
                    {
                        id: "m1_q1",
                        type: "multiple-choice",
                        question: "What does JET stand for?",
                        options: [
                            "Just Energy Technology",
                            "Just Energy Transition",
                            "Joint Energy Trading",
                            "Justified Energy Transfer"
                        ],
                        correct: 1,
                        explanation: "JET stands for Just Energy Transition, emphasizing fairness and equity in the shift to clean energy."
                    },
                    {
                        id: "m1_q2",
                        type: "multiple-choice",
                        question: "Which principle is NOT a core component of JET?",
                        options: [
                            "Equity",
                            "Participation",
                            "Profitability",
                            "Justice"
                        ],
                        correct: 2,
                        explanation: "While economic viability matters, profitability alone is not a core JET principle. JET focuses on equity, participation, justice, and sustainability."
                    },
                    {
                        id: "m1_q3",
                        type: "true-false",
                        question: "Africa has limited renewable energy resources.",
                        correct: false,
                        explanation: "Africa has abundant renewable energy resources including solar, wind, hydro, and geothermal potential."
                    }
                ]
            },
            m2: {
                title: "Module 2: Five Pillars of JET",
                questions: [
                    {
                        id: "m2_q1",
                        type: "multiple-choice",
                        question: "How many pillars form the JET framework?",
                        options: ["Three", "Four", "Five", "Six"],
                        correct: 2,
                        explanation: "The JET framework consists of five pillars: Equitable Access, Environmental Justice, Job Creation & Workforce Transition, Reducing Inequalities, and Community Involvement."
                    },
                    {
                        id: "m2_q2",
                        type: "multiple-choice",
                        question: "Which pillar focuses on protecting communities from environmental harm?",
                        options: [
                            "Equitable Access",
                            "Environmental Justice", 
                            "Job Creation",
                            "Community Involvement"
                        ],
                        correct: 1,
                        explanation: "Environmental Justice focuses on protecting communities from environmental harm while promoting clean energy development."
                    },
                    {
                        id: "m2_q3",
                        type: "true-false",
                        question: "The five pillars operate independently without interconnection.",
                        correct: false,
                        explanation: "The five pillars are deeply interconnected and work together to ensure a comprehensive approach to just energy transition."
                    }
                ]
            },
            m3: {
                title: "Module 3: South Africa's REIPPPP",
                questions: [
                    {
                        id: "m3_q1",
                        type: "multiple-choice",
                        question: "When was South Africa's REIPPPP launched?",
                        options: ["2009", "2010", "2011", "2012"],
                        correct: 2,
                        explanation: "REIPPPP was launched in 2011 as South Africa's flagship renewable energy procurement program."
                    },
                    {
                        id: "m3_q2",
                        type: "multiple-choice",
                        question: "What was a key success of REIPPPP?",
                        options: [
                            "Increased coal dependency",
                            "Dramatic cost reductions for renewables",
                            "Eliminated all energy poverty",
                            "Stopped all coal mining"
                        ],
                        correct: 1,
                        explanation: "REIPPPP achieved dramatic cost reductions for renewable energy, with solar costs declining by over 70%."
                    },
                    {
                        id: "m3_q3",
                        type: "true-false",
                        question: "REIPPPP only focused on large-scale solar projects.",
                        correct: false,
                        explanation: "REIPPPP included diverse technologies: wind, solar PV, concentrated solar power, and biomass projects."
                    }
                ]
            },
            m4: {
                title: "Module 4: Energy Value Chains",
                questions: [
                    {
                        id: "m4_q1",
                        type: "multiple-choice",
                        question: "What is a major difference between coal and renewable energy value chains?",
                        options: [
                            "Coal creates more jobs",
                            "Renewables have higher upfront costs but lower operating costs",
                            "Coal is more environmentally friendly",
                            "Renewables require more water"
                        ],
                        correct: 1,
                        explanation: "Renewable energy typically has higher upfront capital costs but much lower operating and fuel costs compared to coal."
                    },
                    {
                        id: "m4_q2",
                        type: "multiple-choice",
                        question: "What does PPA stand for?",
                        options: [
                            "Power Production Agreement",
                            "Public Private Alliance",
                            "Power Purchase Agreement",
                            "Primary Power Allocation"
                        ],
                        correct: 2,
                        explanation: "PPA stands for Power Purchase Agreement, a contract between electricity generators and purchasers."
                    },
                    {
                        id: "m4_q3",
                        type: "true-false",
                        question: "Renewable energy projects typically require minimal stakeholder engagement.",
                        correct: false,
                        explanation: "Renewable energy projects require extensive stakeholder engagement to ensure community support and address local concerns."
                    }
                ]
            },
            m5: {
                title: "Module 5: Career Opportunities",
                questions: [
                    {
                        id: "m5_q1",
                        type: "multiple-choice",
                        question: "Which skill category is increasingly important for green jobs?",
                        options: [
                            "Only technical skills",
                            "Only business skills", 
                            "A combination of technical, soft, and digital skills",
                            "Only traditional energy skills"
                        ],
                        correct: 2,
                        explanation: "Green jobs require a combination of technical skills, soft skills (like communication), and digital skills for the modern energy sector."
                    },
                    {
                        id: "m5_q2",
                        type: "multiple-choice",
                        question: "Which role focuses on facilitating community participation in energy projects?",
                        options: [
                            "Energy Engineer",
                            "Community Engagement Officer",
                            "Grid Integration Specialist",
                            "Financial Analyst"
                        ],
                        correct: 1,
                        explanation: "Community Engagement Officers specialize in facilitating meaningful community participation in energy projects."
                    },
                    {
                        id: "m5_q3",
                        type: "true-false",
                        question: "Green jobs are only available in developed countries.",
                        correct: false,
                        explanation: "Green jobs are rapidly growing in developing countries, especially in Africa, as renewable energy deployment accelerates."
                    }
                ]
            }
        };
    }

    renderQuiz(moduleId, containerId) {
        const container = document.getElementById(containerId) || document.querySelector(`[data-quiz-module="${moduleId}"]`);
        if (!container) return;

        const quiz = this.quizzes[moduleId];
        if (!quiz) return;

        // Clear container safely
        container.innerHTML = '';
        
        // Create quiz header
        const quizHeader = document.createElement('div');
        quizHeader.className = 'quiz-header';
        
        const titleEl = document.createElement('h3');
        titleEl.textContent = quiz.title;
        quizHeader.appendChild(titleEl);
        
        const progressDiv = document.createElement('div');
        progressDiv.className = 'quiz-progress';
        
        const progressText = document.createElement('span');
        progressText.id = 'quiz-progress-text';
        progressText.textContent = `Question 1 of ${quiz.questions.length}`;
        progressDiv.appendChild(progressText);
        
        const progressBarDiv = document.createElement('div');
        progressBarDiv.className = 'quiz-progress-bar';
        
        const progressFill = document.createElement('div');
        progressFill.className = 'quiz-progress-fill';
        progressFill.id = 'quiz-progress-fill';
        progressFill.style.width = '0%';
        progressBarDiv.appendChild(progressFill);
        
        progressDiv.appendChild(progressBarDiv);
        quizHeader.appendChild(progressDiv);
        container.appendChild(quizHeader);
        
        // Create questions container
        const questionsContainer = document.createElement('div');
        questionsContainer.id = 'quiz-questions-container';
        container.appendChild(questionsContainer);
        
        // Create quiz controls
        const controlsDiv = document.createElement('div');
        controlsDiv.className = 'quiz-controls';
        
        const prevBtn = document.createElement('button');
        prevBtn.id = 'quiz-prev-btn';
        prevBtn.className = 'nav-btn secondary';
        prevBtn.disabled = true;
        prevBtn.textContent = 'Previous';
        controlsDiv.appendChild(prevBtn);
        
        const nextBtn = document.createElement('button');
        nextBtn.id = 'quiz-next-btn';
        nextBtn.className = 'nav-btn primary';
        nextBtn.textContent = 'Next';
        controlsDiv.appendChild(nextBtn);
        
        const submitBtn = document.createElement('button');
        submitBtn.id = 'quiz-submit-btn';
        submitBtn.className = 'nav-btn primary';
        submitBtn.style.display = 'none';
        submitBtn.textContent = 'Submit Quiz';
        controlsDiv.appendChild(submitBtn);
        
        container.appendChild(controlsDiv);
        
        // Create results container
        const resultsDiv = document.createElement('div');
        resultsDiv.id = 'quiz-results';
        resultsDiv.style.display = 'none';
        container.appendChild(resultsDiv);

        this.currentQuiz = {
            moduleId,
            questions: quiz.questions,
            currentQuestion: 0,
            answers: {},
            completed: false
        };

        this.renderCurrentQuestion();
        this.bindQuizEvents();
    }

    renderCurrentQuestion() {
        const container = document.getElementById('quiz-questions-container');
        const question = this.currentQuiz.questions[this.currentQuiz.currentQuestion];
        
        // Clear container safely
        container.innerHTML = '';
        
        // Create question wrapper
        const questionDiv = document.createElement('div');
        questionDiv.className = 'quiz-question fade-in';
        
        // Create and set question header
        const headerEl = document.createElement('h4');
        headerEl.textContent = `Question ${this.currentQuiz.currentQuestion + 1}`;
        questionDiv.appendChild(headerEl);
        
        // Create and set question text
        const questionTextEl = document.createElement('p');
        questionTextEl.className = 'question-text';
        questionTextEl.textContent = question.question;
        questionDiv.appendChild(questionTextEl);
        
        // Create options container
        const optionsDiv = document.createElement('div');
        optionsDiv.className = 'question-options';
        
        if (question.type === 'multiple-choice') {
            question.options.forEach((option, index) => {
                const isSelected = this.currentQuiz.answers[question.id] === index;
                
                const label = document.createElement('label');
                label.className = `option-label ${isSelected ? 'selected' : ''}`;
                
                const input = document.createElement('input');
                input.type = 'radio';
                input.name = `q_${question.id}`;
                input.value = index;
                input.checked = isSelected;
                
                const span = document.createElement('span');
                span.className = 'option-text';
                span.textContent = option;
                
                label.appendChild(input);
                label.appendChild(span);
                optionsDiv.appendChild(label);
            });
        } else if (question.type === 'true-false') {
            const isTrue = this.currentQuiz.answers[question.id] === true;
            const isFalse = this.currentQuiz.answers[question.id] === false;
            
            // True option
            const trueLabel = document.createElement('label');
            trueLabel.className = `option-label ${isTrue ? 'selected' : ''}`;
            
            const trueInput = document.createElement('input');
            trueInput.type = 'radio';
            trueInput.name = `q_${question.id}`;
            trueInput.value = 'true';
            trueInput.checked = isTrue;
            
            const trueSpan = document.createElement('span');
            trueSpan.className = 'option-text';
            trueSpan.textContent = 'True';
            
            trueLabel.appendChild(trueInput);
            trueLabel.appendChild(trueSpan);
            optionsDiv.appendChild(trueLabel);
            
            // False option
            const falseLabel = document.createElement('label');
            falseLabel.className = `option-label ${isFalse ? 'selected' : ''}`;
            
            const falseInput = document.createElement('input');
            falseInput.type = 'radio';
            falseInput.name = `q_${question.id}`;
            falseInput.value = 'false';
            falseInput.checked = isFalse;
            
            const falseSpan = document.createElement('span');
            falseSpan.className = 'option-text';
            falseSpan.textContent = 'False';
            
            falseLabel.appendChild(falseInput);
            falseLabel.appendChild(falseSpan);
            optionsDiv.appendChild(falseLabel);
        }
        
        questionDiv.appendChild(optionsDiv);
        container.appendChild(questionDiv);
        
        this.updateQuizProgress();
        this.bindQuestionEvents();
    }

    bindQuestionEvents() {
        const inputs = document.querySelectorAll(`input[name="q_${this.currentQuiz.questions[this.currentQuiz.currentQuestion].id}"]`);
        inputs.forEach(input => {
            input.addEventListener('change', (e) => {
                const question = this.currentQuiz.questions[this.currentQuiz.currentQuestion];
                let value = e.target.value;
                
                if (question.type === 'multiple-choice') {
                    value = parseInt(value);
                } else if (question.type === 'true-false') {
                    value = value === 'true';
                }
                
                this.currentQuiz.answers[question.id] = value;
                
                // Update visual selection
                document.querySelectorAll('.option-label').forEach(label => label.classList.remove('selected'));
                e.target.closest('.option-label').classList.add('selected');
                
                // Enable next button
                document.getElementById('quiz-next-btn').disabled = false;
            });
        });
    }

    bindQuizEvents() {
        document.getElementById('quiz-prev-btn').addEventListener('click', () => {
            if (this.currentQuiz.currentQuestion > 0) {
                this.currentQuiz.currentQuestion--;
                this.renderCurrentQuestion();
                this.updateNavigationButtons();
            }
        });

        document.getElementById('quiz-next-btn').addEventListener('click', () => {
            if (this.currentQuiz.currentQuestion < this.currentQuiz.questions.length - 1) {
                this.currentQuiz.currentQuestion++;
                this.renderCurrentQuestion();
                this.updateNavigationButtons();
            }
        });

        document.getElementById('quiz-submit-btn').addEventListener('click', () => {
            this.submitQuiz();
        });
    }

    updateQuizProgress() {
        const progressText = document.getElementById('quiz-progress-text');
        const progressFill = document.getElementById('quiz-progress-fill');
        
        const current = this.currentQuiz.currentQuestion + 1;
        const total = this.currentQuiz.questions.length;
        const percentage = (current / total) * 100;
        
        progressText.textContent = `Question ${current} of ${total}`;
        progressFill.style.width = `${percentage}%`;
    }

    updateNavigationButtons() {
        const prevBtn = document.getElementById('quiz-prev-btn');
        const nextBtn = document.getElementById('quiz-next-btn');
        const submitBtn = document.getElementById('quiz-submit-btn');
        
        prevBtn.disabled = this.currentQuiz.currentQuestion === 0;
        
        const isLastQuestion = this.currentQuiz.currentQuestion === this.currentQuiz.questions.length - 1;
        const hasAnswer = this.currentQuiz.answers[this.currentQuiz.questions[this.currentQuiz.currentQuestion].id] !== undefined;
        
        if (isLastQuestion) {
            nextBtn.style.display = 'none';
            submitBtn.style.display = 'inline-block';
            submitBtn.disabled = !hasAnswer;
        } else {
            nextBtn.style.display = 'inline-block';
            submitBtn.style.display = 'none';
            nextBtn.disabled = !hasAnswer;
        }
    }

    submitQuiz() {
        const results = this.calculateResults();
        this.displayResults(results);
        this.saveQuizProgress();
        
        // Track completion
        localStorage.setItem(`quiz_${this.currentQuiz.moduleId}_completed`, 'true');
        trackEvent('quiz_completed', { module: this.currentQuiz.moduleId, score: results.percentage });
    }

    calculateResults() {
        const questions = this.currentQuiz.questions;
        let correct = 0;
        const details = [];

        questions.forEach(question => {
            const userAnswer = this.currentQuiz.answers[question.id];
            const isCorrect = userAnswer === question.correct;
            
            if (isCorrect) correct++;
            
            details.push({
                question: question.question,
                userAnswer,
                correctAnswer: question.correct,
                isCorrect,
                explanation: question.explanation
            });
        });

        return {
            correct,
            total: questions.length,
            percentage: Math.round((correct / questions.length) * 100),
            details
        };
    }

    displayResults(results) {
        const container = document.getElementById('quiz-results');
        const questionsContainer = document.getElementById('quiz-questions-container');
        const controls = document.querySelector('.quiz-controls');
        
        questionsContainer.style.display = 'none';
        controls.style.display = 'none';
        
        let resultClass = 'error-message';
        let resultMessage = 'Keep studying and try again!';
        
        if (results.percentage >= 80) {
            resultClass = 'success-message';
            resultMessage = 'Excellent work! You can proceed to the next module.';
        } else if (results.percentage >= 60) {
            resultClass = 'success-message';
            resultMessage = 'Good job! You can proceed to the next module.';
        }

        // Clear container safely
        container.innerHTML = '';
        
        // Create result summary
        const summaryDiv = document.createElement('div');
        summaryDiv.className = `quiz-result-summary ${resultClass}`;
        
        const titleEl = document.createElement('h3');
        titleEl.textContent = 'Quiz Complete!';
        summaryDiv.appendChild(titleEl);
        
        const scoreEl = document.createElement('p');
        scoreEl.textContent = `You scored ${results.correct} out of ${results.total} (${results.percentage}%)`;
        summaryDiv.appendChild(scoreEl);
        
        const messageEl = document.createElement('p');
        messageEl.textContent = resultMessage;
        summaryDiv.appendChild(messageEl);
        
        container.appendChild(summaryDiv);
        
        // Create review section
        const reviewDiv = document.createElement('div');
        reviewDiv.className = 'quiz-review';
        
        const reviewTitle = document.createElement('h4');
        reviewTitle.textContent = 'Review Your Answers:';
        reviewDiv.appendChild(reviewTitle);
        
        results.details.forEach((detail, index) => {
            const questionDiv = document.createElement('div');
            questionDiv.className = `question-review ${detail.isCorrect ? 'correct' : 'incorrect'}`;
            
            const questionText = document.createElement('p');
            const questionStrong = document.createElement('strong');
            questionStrong.textContent = `Question ${index + 1}: `;
            questionText.appendChild(questionStrong);
            questionText.appendChild(document.createTextNode(detail.question));
            questionDiv.appendChild(questionText);
            
            const resultText = document.createElement('p');
            resultText.className = 'review-result';
            resultText.textContent = detail.isCorrect ? '✓ Correct' : '✗ Incorrect';
            questionDiv.appendChild(resultText);
            
            const explanationText = document.createElement('p');
            explanationText.className = 'explanation';
            explanationText.textContent = detail.explanation;
            questionDiv.appendChild(explanationText);
            
            reviewDiv.appendChild(questionDiv);
        });
        
        container.appendChild(reviewDiv);
        
        // Create actions section
        const actionsDiv = document.createElement('div');
        actionsDiv.className = 'quiz-actions';
        
        const retakeBtn = document.createElement('button');
        retakeBtn.className = 'nav-btn primary';
        retakeBtn.textContent = 'Retake Quiz';
        retakeBtn.onclick = () => location.reload();
        actionsDiv.appendChild(retakeBtn);
        
        const backBtn = document.createElement('button');
        backBtn.className = 'nav-btn secondary';
        backBtn.textContent = 'Back to Course';
        backBtn.onclick = () => window.location.href = '/index.html';
        actionsDiv.appendChild(backBtn);
        
        container.appendChild(actionsDiv);
        
        container.style.display = 'block';
    }

    saveQuizProgress() {
        const moduleId = this.currentQuiz.moduleId;
        const progress = {
            completed: true,
            score: this.calculateResults().percentage,
            answers: this.currentQuiz.answers,
            timestamp: new Date().toISOString()
        };
        
        localStorage.setItem(`quiz_progress_${moduleId}`, JSON.stringify(progress));
        JETState.quizProgress[moduleId] = progress;
    }
}

// AI Tutor System
class AITutor {
    constructor() {
        this.systemPrompt = `You are Naledi, an AI tutor for the Just Energy Transition (JET) 101 course. You are knowledgeable, encouraging, and focused on helping learners understand JET concepts.

Key principles:
- Always relate answers to African contexts and examples
- Be encouraging and supportive
- Use simple, clear language
- Cite specific course content when relevant
- Don't invent statistics - use only factual information from the course
- Help learners apply JET principles to real scenarios

Your knowledge base includes:
- The five pillars of JET (Equitable Access, Environmental Justice, Job Creation, Reducing Inequalities, Community Involvement)
- South Africa's REIPPPP program and lessons learned
- Energy value chains and stakeholder mapping
- Career opportunities in renewable energy
- Policy frameworks supporting just transition`;

        this.conversationHistory = [];
        this.isVisible = false;
    }

    initialize() {
        this.setupEventListeners();
        this.addWelcomeMessage();
    }

    setupEventListeners() {
        const toggle = document.querySelector('.tutor-toggle');
        const input = document.getElementById('chat-input');
        
        if (toggle) {
            toggle.addEventListener('click', () => this.toggleVisibility());
        }
        
        if (input) {
            input.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    this.sendMessage();
                }
            });
        }
    }

    toggleVisibility() {
        const chatContainer = document.getElementById('tutor-chat');
        this.isVisible = !this.isVisible;
        
        if (this.isVisible) {
            chatContainer.style.display = 'flex';
        } else {
            chatContainer.style.display = 'none';
        }
    }

    addWelcomeMessage() {
        this.addMessage('assistant', "Hello! I'm Naledi, your AI tutor for the JET 101 course. I'm here to help you understand Just Energy Transition concepts. Feel free to ask me any questions about the course material!");
    }

    async sendMessage() {
        const input = document.getElementById('chat-input');
        const message = input.value.trim();
        
        if (!message) return;
        
        this.addMessage('user', message);
        input.value = '';
        
        // Show typing indicator
        this.showTypingIndicator();
        
        // Simulate AI response (in a real implementation, this would call an AI API)
        setTimeout(() => {
            this.hideTypingIndicator();
            const response = this.generateResponse(message);
            this.addMessage('assistant', response);
        }, 1500);
    }

    addMessage(role, content) {
        const messagesContainer = document.getElementById('chat-messages');
        const messageDiv = document.createElement('div');
        messageDiv.className = `chat-message ${role}`;
        
        const contentDiv = document.createElement('div');
        contentDiv.className = 'message-content';
        
        const textEl = document.createElement('p');
        textEl.textContent = content;
        contentDiv.appendChild(textEl);
        
        const timeEl = document.createElement('span');
        timeEl.className = 'message-time';
        timeEl.textContent = new Date().toLocaleTimeString();
        contentDiv.appendChild(timeEl);
        
        messageDiv.appendChild(contentDiv);
        
        messagesContainer.appendChild(messageDiv);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
        
        this.conversationHistory.push({ role, content });
    }

    showTypingIndicator() {
        const messagesContainer = document.getElementById('chat-messages');
        const typingDiv = document.createElement('div');
        typingDiv.className = 'chat-message assistant typing';
        typingDiv.id = 'typing-indicator';
        const contentDiv = document.createElement('div');
        contentDiv.className = 'message-content';
        
        const textEl = document.createElement('p');
        textEl.textContent = 'Naledi is typing...';
        contentDiv.appendChild(textEl);
        
        const loadingEl = document.createElement('div');
        loadingEl.className = 'loading';
        contentDiv.appendChild(loadingEl);
        
        typingDiv.appendChild(contentDiv);
        messagesContainer.appendChild(typingDiv);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    hideTypingIndicator() {
        const typingIndicator = document.getElementById('typing-indicator');
        if (typingIndicator) {
            typingIndicator.remove();
        }
    }

    generateResponse(message) {
        // Simple keyword-based responses (in production, this would use a real AI API)
        const lowerMessage = message.toLowerCase();
        
        if (lowerMessage.includes('pillar')) {
            return "The five pillars of JET are: 1) Equitable Access - ensuring everyone has access to clean energy, 2) Environmental Justice - protecting communities from harm, 3) Job Creation & Workforce Transition - creating green jobs while supporting displaced workers, 4) Reducing Inequalities - addressing systemic disparities, and 5) Community Involvement - ensuring meaningful participation in energy decisions. Which pillar would you like to explore more?";
        }
        
        if (lowerMessage.includes('reipppp') || lowerMessage.includes('south africa')) {
            return "South Africa's REIPPPP (Renewable Energy Independent Power Producer Procurement Programme) is a great example of successful renewable energy procurement. Launched in 2011, it achieved dramatic cost reductions (over 70% for solar), attracted R194 billion in investment, and created over 40,000 jobs. Key lessons include the importance of transparent procurement, local content requirements, and community development programs.";
        }
        
        if (lowerMessage.includes('career') || lowerMessage.includes('job')) {
            return "There are many exciting career opportunities in the renewable energy sector! These include technical roles like Solar PV Technician and Wind Turbine Technician, business roles like Project Developer and Energy Analyst, and policy roles like Community Engagement Officer. The key is developing a combination of technical, soft, and digital skills. What type of career interests you most?";
        }
        
        if (lowerMessage.includes('africa') || lowerMessage.includes('african')) {
            return "Africa has tremendous potential for just energy transition! The continent has abundant renewable resources - solar, wind, hydro, and geothermal. Despite having only 4% of global emissions, Africa faces significant climate impacts. JET offers opportunities to leapfrog to clean energy, create millions of jobs, and achieve energy independence while addressing historical inequalities.";
        }
        
        return "That's a great question! Based on the course material, the key to understanding JET is remembering that it's about fairness and inclusion in the energy transition. Every decision should consider the five pillars and ensure no one is left behind. Can you tell me more specifically what aspect you'd like to explore?";
    }
}

// Scenario Response System
function submitScenarioResponse(moduleId, textareaId) {
    const textarea = document.getElementById(textareaId);
    const response = textarea.value.trim();
    
    if (!response) {
        alert('Please provide a response before submitting.');
        return;
    }
    
    // Save response
    const scenarioData = {
        moduleId,
        response,
        timestamp: new Date().toISOString()
    };
    
    localStorage.setItem(`scenario_${moduleId}`, JSON.stringify(scenarioData));
    JETState.scenarioResponses[moduleId] = scenarioData;
    
    // Show success message
    const successMsg = document.createElement('div');
    successMsg.className = 'success-message';
    successMsg.textContent = 'Response submitted successfully! This will be included in your course portfolio.';
    textarea.parentNode.appendChild(successMsg);
    
    // Disable textarea and button
    textarea.disabled = true;
    document.querySelector(`button[onclick*="${textareaId}"]`).disabled = true;
    
    trackEvent('scenario_completed', { module: moduleId });
}

// Progress Tracking
function trackModuleStart(moduleId) {
    const startTime = new Date().toISOString();
    localStorage.setItem(`module_${moduleId}_start`, startTime);
    trackEvent('module_started', { module: moduleId });
}

function trackModuleComplete(moduleId) {
    const endTime = new Date().toISOString();
    localStorage.setItem(`module_${moduleId}_complete`, endTime);
    trackEvent('module_completed', { module: moduleId });
}

function trackEvent(eventType, data) {
    // In production, this would send to analytics service
    console.log('Event tracked:', eventType, data);
    
    // Store locally for now
    const events = JSON.parse(localStorage.getItem('jet_events') || '[]');
    events.push({
        type: eventType,
        data,
        timestamp: new Date().toISOString()
    });
    localStorage.setItem('jet_events', JSON.stringify(events));
}

// Error Reporting
function reportIssue() {
    const logs = {
        userAgent: navigator.userAgent,
        currentUrl: window.location.href,
        localStorage: localStorage,
        console: 'Console logs would be captured here',
        timestamp: new Date().toISOString()
    };
    
    // In production, this would send to error reporting service
    console.log('Issue reported:', logs);
    alert('Issue report generated. In a production system, this would be sent to our support team.');
}

// Final Conversation System
function startFinalJETConversation() {
    // This would load the conversation flow from /ai/conversation/flow.json
    const conversationFlow = {
        steps: [
            {
                type: "knowledge_check",
                question: "What was the most important thing you learned about JET?",
                follow_up: "Can you give a specific example from the course?"
            },
            {
                type: "reflection",
                question: "How do you see JET principles applying in your community or country?",
                follow_up: "What challenges might you face in implementing these ideas?"
            },
            {
                type: "action_planning",
                question: "Based on your action plan, what's your first concrete step?",
                follow_up: "How will you measure success in this step?"
            }
        ]
    };
    
    // Start conversation with Naledi
    alert('Final conversation feature would be implemented here, following the flow defined in /ai/conversation/flow.json');
}

// Utility Functions
function loadModuleProgress(moduleId) {
    const quizProgress = localStorage.getItem(`quiz_progress_${moduleId}`);
    const scenarioResponse = localStorage.getItem(`scenario_${moduleId}`);
    
    if (quizProgress) {
        JETState.quizProgress[moduleId] = JSON.parse(quizProgress);
    }
    
    if (scenarioResponse) {
        JETState.scenarioResponses[moduleId] = JSON.parse(scenarioResponse);
    }
}

function loadQuiz(moduleId) {
    const quizEngine = new QuizEngine();
    quizEngine.renderQuiz(moduleId, 'quiz-container');
}

function initializeTutor() {
    const tutor = new AITutor();
    tutor.initialize();
}

function toggleTutor() {
    if (window.tutorInstance) {
        window.tutorInstance.toggleVisibility();
    } else {
        window.tutorInstance = new AITutor();
        window.tutorInstance.initialize();
        window.tutorInstance.toggleVisibility();
    }
}

function sendMessage() {
    const input = document.getElementById('chat-input');
    if (window.tutorInstance) {
        window.tutorInstance.sendMessage();
    } else {
        window.tutorInstance = new AITutor();
        window.tutorInstance.sendMessage();
    }
}

// Global initialization
document.addEventListener('DOMContentLoaded', function() {
    // Initialize global tutor instance
    window.tutorInstance = new AITutor();
    window.tutorInstance.initialize();
});

// Export functions for use in module pages
window.loadQuiz = loadQuiz;
window.initializeTutor = initializeTutor;
window.trackModuleStart = trackModuleStart;
window.submitScenarioResponse = submitScenarioResponse;
window.reportIssue = reportIssue;
window.startFinalJETConversation = startFinalJETConversation;
window.toggleTutor = toggleTutor;
window.sendMessage = sendMessage;