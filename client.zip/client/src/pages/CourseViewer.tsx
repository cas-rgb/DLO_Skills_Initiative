import { useState, useRef, useEffect } from "react";
import { useParams } from "wouter";
import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  BookOpen, 
  Clock, 
  Users, 
  Play, 
  CheckCircle,
  ChevronDown,
  ChevronRight,
  Award,
  Bot,
  Send,
  Volume2,
  Loader2,
  MessageCircle,
  X,
  Brain,
  HelpCircle,
  Target,
  Eye
} from "lucide-react";
import energyImage from '@assets/generated_images/African_renewable_energy_systems_bd9e4464.png';
import jetPillarsImage from '@assets/generated_images/Five_pillars_JET_framework_161b1cf7.png';
import { CourseAudioNarrator } from "@/components/CourseAudioNarrator";
import { apiRequest } from "@/lib/queryClient";
import type { 
  Course, 
  CourseSection, 
  CourseModule, 
  Enrollment,
  ModuleCompletion 
} from "@shared/schema";

interface CollapsibleSectionProps {
  section: CourseSection;
  modules: CourseModule[];
  completions: ModuleCompletion[];
  onModuleClick: (module: CourseModule) => void;
  currentModule?: CourseModule;
}

function CollapsibleSection({ 
  section, 
  modules, 
  completions, 
  onModuleClick, 
  currentModule 
}: CollapsibleSectionProps) {
  const [isExpanded, setIsExpanded] = useState(true);
  const sectionModules = modules.filter(m => m.sectionId === section.id);

  return (
    <div className="border rounded-lg">
      <div 
        className="p-4 cursor-pointer hover:bg-gray-50 flex items-center justify-between"
        onClick={() => setIsExpanded(!isExpanded)}
        data-testid={`section-header-${section.id}`}
      >
        <div className="flex items-center space-x-3">
          {isExpanded ? (
            <ChevronDown className="w-5 h-5 text-gray-500" />
          ) : (
            <ChevronRight className="w-5 h-5 text-gray-500" />
          )}
          <div>
            <h3 className="font-semibold text-lg">{section.title}</h3>
            {section.description && (
              <p className="text-gray-600 text-sm">{section.description}</p>
            )}
          </div>
        </div>
        <Badge variant="outline">
          {sectionModules.length} module{sectionModules.length !== 1 ? 's' : ''}
        </Badge>
      </div>

      {isExpanded && (
        <div className="border-t">
          {sectionModules.map((module) => {
            const isCompleted = completions.some(c => c.moduleId === module.id);
            const isCurrent = currentModule?.id === module.id;

            return (
              <div
                key={module.id}
                className={`p-4 border-b last:border-b-0 cursor-pointer hover:bg-gray-50 transition-colors ${
                  isCurrent ? 'bg-blue-50 border-l-4 border-l-blue-500' : ''
                }`}
                onClick={() => onModuleClick(module)}
                data-testid={`module-${module.id}`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    {isCompleted ? (
                      <CheckCircle className="w-5 h-5 text-green-500" />
                    ) : (
                      <Play className="w-5 h-5 text-gray-400" />
                    )}
                    <div>
                      <h4 className="font-medium">{module.title}</h4>
                      {module.description && (
                        <p className="text-gray-600 text-sm">{module.description}</p>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    {module.duration && (
                      <div className="flex items-center text-sm text-gray-500">
                        <Clock className="w-4 h-4 mr-1" />
                        {module.duration}m
                      </div>
                    )}
                    {isCompleted && (
                      <Badge className="bg-green-100 text-green-800">
                        Completed
                      </Badge>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// AI Chatbot Interface
interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

function NalediAIChatbot({ courseId, currentModule }: { courseId: string; currentModule?: CourseModule | null }) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      role: 'assistant',
      content: "Hello! I'm Naledi, your AI learning companion. I'm here to help you understand Just Energy Transition concepts. Feel free to ask me anything about the course content, or request clarification on any topic!",
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const sendMessage = useMutation({
    mutationFn: async (message: string) => {
      const response = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        credentials: 'include',
        body: JSON.stringify({
          message,
          context: {
            courseId,
            moduleId: currentModule?.id,
            moduleTitle: currentModule?.title,
            moduleContent: currentModule?.content
          }
        })
      });

      if (!response.ok) {
        throw new Error('Failed to get AI response');
      }

      return response.json();
    },
    onSuccess: (data) => {
      const aiMessage: ChatMessage = {
        id: Date.now().toString(),
        role: 'assistant',
        content: data.response || data.message || 'I understand your question. Let me help you with that.',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, aiMessage]);
      setIsTyping(false);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to get response from Naledi. Please try again.",
        variant: "destructive"
      });
      setIsTyping(false);
    }
  });

  const handleSend = () => {
    if (!input.trim()) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);
    sendMessage.mutate(input);
  };

  useEffect(() => {
    if (scrollAreaRef.current) {
      scrollAreaRef.current.scrollTop = scrollAreaRef.current.scrollHeight;
    }
  }, [messages]);

  if (!isOpen) {
    return (
      <Button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 rounded-full w-14 h-14 shadow-lg bg-[hsl(43,74%,36%)] hover:bg-[hsl(43,74%,30%)]"
        data-testid="button-open-chat"
      >
        <MessageCircle className="h-6 w-6" />
      </Button>
    );
  }

  return (
    <Card className="fixed bottom-6 right-6 w-96 h-[600px] shadow-xl z-50">
      <CardHeader className="bg-gradient-to-r from-[hsl(43,74%,36%)] to-[hsl(43,74%,40%)] text-white">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bot className="h-5 w-5" />
            <CardTitle className="text-white">Naledi - AI Tutor</CardTitle>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsOpen(false)}
            className="text-white hover:bg-white/20 h-8 w-8 p-0"
            data-testid="button-close-chat"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
        {currentModule && (
          <p className="text-sm text-white/80 mt-1">
            Helping with: {currentModule.title}
          </p>
        )}
      </CardHeader>
      <CardContent className="p-0 flex flex-col h-[calc(100%-80px)]">
        <ScrollArea className="flex-1 p-4" ref={scrollAreaRef}>
          <div className="space-y-4">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[80%] rounded-lg p-3 ${
                    msg.role === 'user'
                      ? 'bg-[hsl(43,74%,36%)] text-white'
                      : 'bg-gray-100 text-gray-800'
                  }`}
                >
                  {msg.role === 'assistant' && (
                    <div className="flex items-center gap-1 mb-1">
                      <Bot className="h-3 w-3" />
                      <span className="text-xs font-semibold">Naledi</span>
                    </div>
                  )}
                  <p className="text-sm">{msg.content}</p>
                  <p className="text-xs opacity-70 mt-1">
                    {msg.timestamp.toLocaleTimeString()}
                  </p>
                </div>
              </div>
            ))}
            {isTyping && (
              <div className="flex justify-start">
                <div className="bg-gray-100 rounded-lg p-3">
                  <div className="flex items-center gap-2">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span className="text-sm text-gray-600">Naledi is thinking...</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </ScrollArea>
        <div className="p-4 border-t">
          <div className="flex gap-2">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Ask about the course..."
              className="flex-1"
              data-testid="input-chat-message"
            />
            <Button
              onClick={handleSend}
              disabled={!input.trim() || isTyping}
              className="bg-[hsl(43,74%,36%)] hover:bg-[hsl(43,74%,30%)]"
              data-testid="button-send-message"
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function CourseViewer() {
  const { id } = useParams();
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [currentModule, setCurrentModule] = useState<CourseModule | undefined>(undefined);
  const [isGeneratingAudio, setIsGeneratingAudio] = useState(false);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [audioCompleted, setAudioCompleted] = useState<Record<string, boolean>>({});
  const [quizCompleted, setQuizCompleted] = useState<Record<string, boolean>>({});
  const [showQuiz, setShowQuiz] = useState(false);
  const [quizAnswers, setQuizAnswers] = useState<Record<string, number>>({});


  // Fetch course data
  const { data: course, isLoading: courseLoading } = useQuery<Course>({
    queryKey: ['/api/courses', id],
    enabled: !!id,
  });

  const { data: sections = [] } = useQuery<CourseSection[]>({
    queryKey: ['/api/courses', id, 'sections'],
    enabled: !!id,
  });

  const { data: modules = [] } = useQuery<CourseModule[]>({
    queryKey: ['/api/courses', id, 'modules'],
    enabled: !!id,
  });

  const { data: enrollment } = useQuery({
    queryKey: ['/api/users', (user as any)?.id, 'enrollments'],
    enabled: !!(user as any)?.id,
    select: (data: any) => {
      if (Array.isArray(data)) {
        return data.find((enrollment: Enrollment) => enrollment.courseId === id);
      }
      return null;
    },
  });

  const { data: completions = [] } = useQuery<ModuleCompletion[]>({
    queryKey: ['/api/users', (user as any)?.id, 'completions'],
    enabled: !!(user as any)?.id,
  });

  // Quiz questions for modules
  const moduleQuizzes = {
    'jet-module-1': [
      {
        question: "What does 'Just Energy Transition' primarily focus on?",
        options: [
          "Only reducing carbon emissions",
          "Ensuring equitable access to clean energy while protecting communities",
          "Maximizing renewable energy production",
          "Privatizing energy systems"
        ],
        correct: 1
      },
      {
        question: "Which continent is mentioned as having significant potential for renewable energy?",
        options: ["Europe", "Asia", "Africa", "North America"],
        correct: 2
      },
      {
        question: "What is a key principle of Just Energy Transition?",
        options: [
          "Speed over equity",
          "Community involvement and social justice",
          "Technology-first approach",
          "Market-driven solutions only"
        ],
        correct: 1
      }
    ],
    'jet-module-2': [
      {
        question: "How many pillars does the JET framework have?",
        options: ["3", "4", "5", "6"],
        correct: 2
      },
      {
        question: "Which pillar focuses on ensuring everyone has access to clean energy?",
        options: [
          "Environmental Justice",
          "Equitable Access",
          "Job Creation",
          "Community Involvement"
        ],
        correct: 1
      },
      {
        question: "What does the 'Reducing Inequalities' pillar address?",
        options: [
          "Technical efficiency only",
          "Systemic disparities in energy access",
          "Energy pricing",
          "Technology adoption"
        ],
        correct: 1
      }
    ],
    'jet-module-3': [
      {
        question: "What does REIPPPP stand for?",
        options: [
          "Renewable Energy Investment Program",
          "Renewable Energy Independent Power Producer Procurement Programme",
          "Regional Energy Infrastructure Project",
          "Renewable Energy Innovation Partnership"
        ],
        correct: 1
      },
      {
        question: "When was South Africa's REIPPPP launched?",
        options: ["2009", "2010", "2011", "2012"],
        correct: 2
      },
      {
        question: "What was a key success factor of REIPPPP?",
        options: [
          "Opaque procurement process",
          "Transparent procurement and local content requirements",
          "Foreign-only investments",
          "Government-only funding"
        ],
        correct: 1
      }
    ],
    'jet-module-4': [
      {
        question: "What are energy value chains?",
        options: [
          "Only electricity generation",
          "The complete process from energy production to consumption",
          "Solar panel manufacturing only",
          "Energy trading markets"
        ],
        correct: 1
      },
      {
        question: "Why is stakeholder engagement important in energy projects?",
        options: [
          "It's legally required only",
          "To ensure community support and address local concerns",
          "To reduce costs",
          "To speed up implementation"
        ],
        correct: 1
      },
      {
        question: "What role do communities play in energy value chains?",
        options: [
          "No significant role",
          "Only as energy consumers",
          "As key stakeholders in planning and benefits",
          "Only in maintenance"
        ],
        correct: 2
      }
    ],
    'jet-module-5': [
      {
        question: "What types of skills are important for green jobs?",
        options: [
          "Only technical skills",
          "Only business skills",
          "A combination of technical, soft, and digital skills",
          "Only traditional energy skills"
        ],
        correct: 2
      },
      {
        question: "Which role focuses on community participation in energy projects?",
        options: [
          "Energy Engineer",
          "Community Engagement Officer",
          "Grid Integration Specialist",
          "Financial Analyst"
        ],
        correct: 1
      },
      {
        question: "Are green jobs only available in developed countries?",
        options: [
          "Yes, only in developed countries",
          "No, they are rapidly growing in developing countries including Africa",
          "Only in urban areas",
          "Only in government sectors"
        ],
        correct: 1
      }
    ]
  };

  // Calculate progress
  const completedModules = completions.filter(c => 
    modules.some(m => m.id === c.moduleId)
  ).length;
  const progress = modules.length > 0 ? Math.round((completedModules / modules.length) * 100) : 0;

  const handleEnroll = async () => {
    if (!isAuthenticated) {
      toast({
        title: "Login Required",
        description: "Please log in to enroll in this course.",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }

    try {
      const response = await fetch('/api/enrollments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ courseId: id }),
        credentials: 'include',
      });

      if (!response.ok) {
        const error = await response.text();
        throw new Error(error);
      }

      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      toast({
        title: "Enrolled Successfully",
        description: "You can now start learning!",
      });
    } catch (error: any) {
      toast({
        title: "Enrollment Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleModuleClick = async (module: CourseModule) => {
    setCurrentModule(module);
    setShowQuiz(false); // Reset quiz display when switching modules

    // Auto-generate and play audio for the selected module
    if (enrollment) {
      try {
        // First generate script if not exists
        await fetch('/api/narration/generate-script', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ moduleId: module.id }),
          credentials: 'include',
        });

        // Then generate audio
        await fetch('/api/narration/generate-audio', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ moduleId: module.id }),
          credentials: 'include',
        });

        // Refresh audio data
        queryClient.invalidateQueries({ queryKey: ['/api/narration/module', module.id] });
      } catch (error) {
        console.log("Audio generation handled by CourseAudioNarrator component");
      }
    }
  };

  const handleQuizAnswer = (questionIndex: number, answerIndex: number) => {
    if (!currentModule) return;
    const key = `${currentModule.id}-${questionIndex}`;
    setQuizAnswers(prev => ({ ...prev, [key]: answerIndex }));
  };

  const handleQuizSubmit = async () => {
    if (!currentModule) return;
    
    const moduleQuestions = (moduleQuizzes as any)[currentModule.id] || [];
    let correctCount = 0;
    
    moduleQuestions.forEach((question: any, index: number) => {
      const key = `${currentModule.id}-${index}`;
      if (quizAnswers[key] === question.correct) {
        correctCount++;
      }
    });
    
    const percentage = Math.round((correctCount / moduleQuestions.length) * 100);
    
    if (percentage >= 60) {
      try {
        // Mark quiz as complete in backend
        await fetch(`/api/modules/${currentModule.id}/quiz-complete`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ score: percentage, answers: quizAnswers }),
          credentials: 'include',
        });
        
        setQuizCompleted(prev => ({ ...prev, [currentModule.id]: true }));
        setShowQuiz(false);
        toast({
          title: "Quiz Completed!",
          description: `You scored ${correctCount}/${moduleQuestions.length} (${percentage}%). You can now complete the module.`,
        });
      } catch (error) {
        console.error('Failed to mark quiz complete:', error);
        // Still update local state for UX
        setQuizCompleted(prev => ({ ...prev, [currentModule.id]: true }));
        setShowQuiz(false);
        toast({
          title: "Quiz Completed!",
          description: `You scored ${correctCount}/${moduleQuestions.length} (${percentage}%). You can now complete the module.`,
        });
      }
    } else {
      toast({
        title: "Quiz Score Too Low",
        description: `You scored ${correctCount}/${moduleQuestions.length} (${percentage}%). You need at least 60% to proceed. Please listen to the audio again and retry.`,
        variant: "destructive",
      });
      // Reset progress to allow retrying
      setAudioCompleted(prev => ({ ...prev, [currentModule.id]: false }));
      setShowQuiz(false);
    }
  };

  const handleModuleComplete = async (moduleId: string) => {
    if (!isAuthenticated) return;
    
    // Check prerequisites
    if (!audioCompleted[moduleId]) {
      toast({
        title: "Audio Required",
        description: "Please listen to the complete audio before marking as complete.",
        variant: "destructive",
      });
      return;
    }
    
    if (!quizCompleted[moduleId]) {
      toast({
        title: "Quiz Required",
        description: "Please complete the quiz with at least 60% score before marking as complete.",
        variant: "destructive",
      });
      return;
    }

    try {
      const response = await fetch(`/api/modules/${moduleId}/complete`, {
        method: 'POST',
        credentials: 'include',
      });

      if (!response.ok) {
        throw new Error('Failed to mark module complete');
      }

      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      toast({
        title: "Module Completed",
        description: "Great job! Keep up the good work.",
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handlePlayModuleAudio = async (moduleId: string) => {
    setIsGeneratingAudio(true);
    try {
      // First, check if audio already exists for this module
      const audioResponse = await fetch(`/api/ai/module-audio/${moduleId}`);

      if (audioResponse.ok) {
        // Audio exists, play it
        const audioData = await audioResponse.json();
        setAudioUrl(audioData.audioPath);

        toast({
          title: "Playing Module Audio",
          description: "Teacher narration for this module",
        });
      } else {
        // Generate teacher script and audio
        const scriptResponse = await fetch('/api/ai/generate-teacher-scripts', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ moduleId })
        });

        if (!scriptResponse.ok) {
          throw new Error('Failed to generate teacher script');
        }

        // Generate audio from script
        const audioGenResponse = await fetch('/api/ai/generate-module-audio', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ moduleId })
        });

        if (!audioGenResponse.ok) {
          throw new Error('Failed to generate audio');
        }

        const audioData = await audioGenResponse.json();
        setAudioUrl(audioData.audioPath);

        toast({
          title: "Audio Generated & Playing",
          description: "Generated teacher narration for this module",
        });
      }
    } catch (error) {
      console.error('Audio generation error:', error);
      toast({
        title: "Audio Generation Failed",
        description: error instanceof Error ? error.message : "Could not generate audio",
        variant: "destructive"
      });
    } finally {
      setIsGeneratingAudio(false);
    }
  };

  if (courseLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading course...</p>
        </div>
      </div>
    );
  }

  if (!course) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-2">Course not found</h2>
          <p className="text-gray-600">The course you're looking for doesn't exist.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">

        {/* Course Header */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <div className="flex items-start justify-between mb-4">
            <div className="flex-1">
              <div className="flex items-center mb-2">
                <h1 className="text-3xl font-bold mr-4" data-testid="text-course-title">
                  {course.title}
                </h1>
                <Badge className="bg-green-100 text-green-800">FREE</Badge>
              </div>
              <p className="text-gray-600 text-lg mb-4">{course.description}</p>

              <div className="flex items-center space-x-6 text-sm text-gray-500">
                <div className="flex items-center">
                  <BookOpen className="w-4 h-4 mr-1" />
                  <span>{modules.length} modules</span>
                </div>
                <div className="flex items-center">
                  <Clock className="w-4 h-4 mr-1" />
                  <span>{course.duration} hours</span>
                </div>
                <div className="flex items-center">
                  <Users className="w-4 h-4 mr-1" />
                  <span>{course.level}</span>
                </div>
              </div>
            </div>

            {/* Enrollment Status */}
            <div className="ml-6">
              {!enrollment ? (
                <Button 
                  onClick={handleEnroll}
                  className="bg-blue-600 hover:bg-blue-700"
                  data-testid="button-enroll"
                >
                  Enroll Now
                </Button>
              ) : (
                <div className="text-center">
                  <div className="flex items-center justify-center mb-2">
                    <Award className="w-5 h-5 text-green-500 mr-2" />
                    <span className="font-semibold text-green-700">Enrolled</span>
                  </div>
                  <div className="text-sm text-gray-600">
                    Progress: {progress}%
                  </div>
                  <div className="w-32 bg-gray-200 rounded-full h-2 mt-1">
                    <div 
                      className="bg-blue-600 h-2 rounded-full" 
                      style={{ width: `${progress}%` }}
                    ></div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Visual Module Overview with Progress */}
        <div className="mb-8">
          <Card className="border-2 border-gold/20 shadow-lg">
            <CardHeader className="bg-gradient-to-r from-gold/5 to-transparent">
              <div className="flex items-center justify-center gap-3 mb-2">
                <div className="w-8 h-8 bg-gold/10 rounded-full flex items-center justify-center">
                  <Award className="w-4 h-4 text-gold" />
                </div>
                <CardTitle className="text-2xl font-bold text-center text-gray-800">Course Modules</CardTitle>
              </div>
              <CardDescription className="text-center">Complete interactive learning journey with AI support</CardDescription>
              {/* Progress Bar */}
              <div className="mt-4">
                <div className="flex items-center justify-between text-sm text-gray-600 mb-2">
                  <span>Course Progress</span>
                  <span>{Math.round((completions.length / Math.max(modules.length, 1)) * 100)}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-3">
                  <div 
                    className="bg-gradient-to-r from-gold to-yellow-400 h-3 rounded-full transition-all duration-500 ease-out"
                    style={{ width: `${(completions.length / Math.max(modules.length, 1)) * 100}%` }}
                  ></div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {/* Module 1 */}
                <Card className={`cursor-pointer transition-all duration-300 hover:shadow-xl hover:scale-105 ${
                  currentModule?.id === 'jet-module-1' ? 'border-gold bg-gradient-to-br from-gold/10 to-gold/5 shadow-lg' : 'hover:border-gold/50 hover:bg-gold/5'
                }`} onClick={() => {
                  const module = modules.find(m => m.id === 'jet-module-1');
                  if (module) handleModuleClick(module);
                }}>
                  <CardHeader className="text-center relative overflow-hidden">
                    <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-200 to-blue-400"></div>
                    <div className="w-16 h-16 bg-gradient-to-br from-blue-100 to-blue-200 rounded-full flex items-center justify-center mx-auto mb-3 shadow-md hover:shadow-lg transition-shadow">
                      <span className="text-2xl font-bold text-blue-600">01</span>
                    </div>
                    <CardTitle className="text-lg text-gray-800">Introduction to Just Energy Transition</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 mb-4">Understand JET fundamentals, core principles, and African energy context.</p>
                    <div className="space-y-2 mb-4">
                      <div className="text-xs text-gray-500">⏱️ 1.5 hours</div>
                      <div className="text-xs text-gray-500">📖 Reading + Quiz</div>
                    </div>
                    <div className="space-y-1">
                      <h5 className="text-xs font-semibold text-gray-700">Learning Objectives:</h5>
                      <ul className="text-xs text-gray-600 space-y-1">
                        <li>• Define Just Energy Transition</li>
                        <li>• Understand the five pillars</li>
                        <li>• Explore African energy context</li>
                      </ul>
                    </div>
                    {completions.some(c => c.moduleId === 'jet-module-1') && (
                      <Badge className="mt-2 bg-green-100 text-green-800">✓ Completed</Badge>
                    )}
                  </CardContent>
                </Card>

                {/* Module 2 */}
                <Card className={`cursor-pointer transition-all duration-300 hover:shadow-xl hover:scale-105 ${
                  currentModule?.id === 'jet-module-2' ? 'border-gold bg-gradient-to-br from-gold/10 to-gold/5 shadow-lg' : 'hover:border-gold/50 hover:bg-gold/5'
                }`} onClick={() => {
                  const module = modules.find(m => m.id === 'jet-module-2');
                  if (module) handleModuleClick(module);
                }}>
                  <CardHeader className="text-center">
                    <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-2">
                      <span className="text-2xl font-bold text-green-600">02</span>
                    </div>
                    <CardTitle className="text-lg">South Africa's REIPPPP Success Story</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 mb-4">Deep dive into South Africa's renewable energy program and lessons learned.</p>
                    <div className="space-y-2 mb-4">
                      <div className="text-xs text-gray-500">⏱️ 2 hours</div>
                      <div className="text-xs text-gray-500">📹 Video + Case Study</div>
                    </div>
                    <div className="space-y-1">
                      <h5 className="text-xs font-semibold text-gray-700">Learning Objectives:</h5>
                      <ul className="text-xs text-gray-600 space-y-1">
                        <li>• Analyze REIPPPP success factors</li>
                        <li>• Study bid window outcomes</li>
                        <li>• Evaluate policy framework</li>
                      </ul>
                    </div>
                    {completions.some(c => c.moduleId === 'jet-module-2') && (
                      <Badge className="mt-2 bg-green-100 text-green-800">✓ Completed</Badge>
                    )}
                  </CardContent>
                </Card>

                {/* Module 3 */}
                <Card className={`cursor-pointer transition-all hover:shadow-lg ${
                  currentModule?.id === 'jet-module-3' ? 'border-gold bg-gold/5' : 'hover:border-gold/50'
                }`} onClick={() => {
                  const module = modules.find(m => m.id === 'jet-module-3');
                  if (module) handleModuleClick(module);
                }}>
                  <CardHeader className="text-center">
                    <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-2">
                      <span className="text-2xl font-bold text-purple-600">03</span>
                    </div>
                    <CardTitle className="text-lg">Energy Value Chains & Stakeholders</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 mb-4">Map energy systems and understand stakeholder engagement strategies.</p>
                    <div className="space-y-2 mb-4">
                      <div className="text-xs text-gray-500">⏱️ 1.5 hours</div>
                      <div className="text-xs text-gray-500">🗺️ Interactive + Scenarios</div>
                    </div>
                    <div className="space-y-1">
                      <h5 className="text-xs font-semibold text-gray-700">Learning Objectives:</h5>
                      <ul className="text-xs text-gray-600 space-y-1">
                        <li>• Map renewable energy value chains</li>
                        <li>• Identify key stakeholders</li>
                        <li>• Design engagement strategies</li>
                      </ul>
                    </div>
                    {completions.some(c => c.moduleId === 'jet-module-3') && (
                      <Badge className="mt-2 bg-green-100 text-green-800">✓ Completed</Badge>
                    )}
                  </CardContent>
                </Card>

                {/* Module 4 */}
                <Card className={`cursor-pointer transition-all hover:shadow-lg ${
                  currentModule?.id === 'jet-module-4' ? 'border-gold bg-gold/5' : 'hover:border-gold/50'
                }`} onClick={() => {
                  const module = modules.find(m => m.id === 'jet-module-4');
                  if (module) handleModuleClick(module);
                }}>
                  <CardHeader className="text-center">
                    <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-2">
                      <span className="text-2xl font-bold text-orange-600">04</span>
                    </div>
                    <CardTitle className="text-lg">Community Engagement & Social Impact</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 mb-4">Learn inclusive engagement strategies and community benefit approaches.</p>
                    <div className="space-y-2 mb-4">
                      <div className="text-xs text-gray-500">⏱️ 2 hours</div>
                      <div className="text-xs text-gray-500">👥 Community Focus + Scenarios</div>
                    </div>
                    <div className="space-y-1">
                      <h5 className="text-xs font-semibold text-gray-700">Learning Objectives:</h5>
                      <ul className="text-xs text-gray-600 space-y-1">
                        <li>• Design inclusive engagement</li>
                        <li>• Address mining communities</li>
                        <li>• Create benefit programs</li>
                      </ul>
                    </div>
                    {completions.some(c => c.moduleId === 'jet-module-4') && (
                      <Badge className="mt-2 bg-green-100 text-green-800">✓ Completed</Badge>
                    )}
                  </CardContent>
                </Card>

                {/* Module 5 */}
                <Card className={`cursor-pointer transition-all hover:shadow-lg ${
                  currentModule?.id === 'jet-module-5' ? 'border-gold bg-gold/5' : 'hover:border-gold/50'
                }`} onClick={() => {
                  const module = modules.find(m => m.id === 'jet-module-5');
                  if (module) handleModuleClick(module);
                }}>
                  <CardHeader className="text-center">
                    <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-2">
                      <span className="text-2xl font-bold text-red-600">05</span>
                    </div>
                    <CardTitle className="text-lg">Career Pathways & Action Planning</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 mb-4">Explore career opportunities and create your personalized action plan.</p>
                    <div className="space-y-2 mb-4">
                      <div className="text-xs text-gray-500">⏱️ 1.5 hours</div>
                      <div className="text-xs text-gray-500">🎯 Career Planning + Action</div>
                    </div>
                    <div className="space-y-1">
                      <h5 className="text-xs font-semibold text-gray-700">Learning Objectives:</h5>
                      <ul className="text-xs text-gray-600 space-y-1">
                        <li>• Identify career opportunities</li>
                        <li>• Assess skill requirements</li>
                        <li>• Create personal action plan</li>
                      </ul>
                    </div>
                    {completions.some(c => c.moduleId === 'jet-module-5') && (
                      <Badge className="mt-2 bg-green-100 text-green-800">✓ Completed</Badge>
                    )}
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">

          {/* Course Content - Compact Sidebar */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>Quick Navigation</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {modules.map((module) => {
                    const isCompleted = completions.some(c => c.moduleId === module.id);
                    const isCurrent = currentModule?.id === module.id;
                    
                    return (
                      <div
                        key={module.id}
                        className={`p-3 rounded-lg cursor-pointer transition-all ${
                          isCurrent ? 'bg-gold/10 border border-gold' : 'hover:bg-gray-50'
                        }`}
                        onClick={() => handleModuleClick(module)}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            {isCompleted ? (
                              <CheckCircle className="w-4 h-4 text-green-500" />
                            ) : (
                              <div className="w-4 h-4 rounded-full border-2 border-gray-300" />
                            )}
                            <span className="font-medium text-sm">{module.title}</span>
                          </div>
                          {module.duration && (
                            <span className="text-xs text-gray-500">{module.duration}m</span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Module Content Viewer with AI Features */}
          <div className="lg:col-span-3">
            {currentModule ? (
              <div className="space-y-4">
                {/* Module Content */}
                <Card className="flex-1 border-l-4 border-gold shadow-lg animate-slide-in">
                  <CardHeader className="bg-gradient-to-r from-gold/5 to-transparent">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-gold/10 rounded-full flex items-center justify-center">
                          <BookOpen className="w-5 h-5 text-gold" />
                        </div>
                        <CardTitle className="text-xl font-semibold text-gray-800">
                          {currentModule?.title}
                        </CardTitle>
                      </div>

                      {/* Module Audio Player */}
                      {currentModule && (
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handlePlayModuleAudio(currentModule.id)}
                            disabled={isGeneratingAudio}
                            className="text-blue-600 border-blue-200 hover:bg-blue-50"
                          >
                            {isGeneratingAudio ? (
                              <div className="flex items-center gap-1">
                                <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-blue-600"></div>
                                <span className="text-xs">Loading...</span>
                              </div>
                            ) : (
                              <div className="flex items-center gap-1">
                                <Volume2 className="h-3 w-3" />
                                <span className="text-xs">Listen</span>
                              </div>
                            )}
                          </Button>

                          {audioUrl && (
                            <audio 
                              ref={(audio) => {
                                if (audio && audioUrl) {
                                  audio.src = audioUrl;
                                  audio.play();
                                }
                              }}
                              controls 
                              className="max-w-48" 
                              onEnded={async () => {
                                setAudioUrl(null);
                                if (currentModule && isAuthenticated) {
                                  try {
                                    // Mark audio as complete in backend
                                    await fetch(`/api/modules/${currentModule.id}/audio-complete`, {
                                      method: 'POST',
                                      credentials: 'include',
                                    });
                                    
                                    setAudioCompleted(prev => ({ ...prev, [currentModule.id]: true }));
                                    toast({
                                      title: "Audio Complete",
                                      description: "Now answer the quiz questions to complete this module.",
                                    });
                                    setShowQuiz(true);
                                  } catch (error) {
                                    console.error('Failed to mark audio complete:', error);
                                    // Still update local state for UX
                                    setAudioCompleted(prev => ({ ...prev, [currentModule.id]: true }));
                                    setShowQuiz(true);
                                  }
                                }
                              }}
                            >
                              <source src={audioUrl} type="audio/mpeg" />
                            </audio>
                          )}
                        </div>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent>
                    {/* Video Player */}
                    {currentModule.videoUrl && (
                      <div className="mb-6 bg-gradient-to-br from-gray-50 to-gray-100 p-4 rounded-xl shadow-lg">
                        <div className="flex items-center gap-3 mb-3">
                          <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center">
                            <Play className="w-4 h-4 text-red-600" />
                          </div>
                          <h4 className="text-lg font-semibold text-gray-800">Module Video</h4>
                        </div>
                        <div className="relative pb-[56.25%] h-0 overflow-hidden rounded-lg border-2 border-gray-200 bg-black shadow-md">
                          <iframe
                            src={currentModule.videoUrl.includes('youtube.com') || currentModule.videoUrl.includes('youtu.be') 
                              ? currentModule.videoUrl.replace('youtu.be/', 'www.youtube.com/embed/').replace('watch?v=', 'embed/').replace('https://youtu.be/', 'https://www.youtube.com/embed/')
                              : currentModule.videoUrl}
                            title={currentModule.title}
                            className="absolute top-0 left-0 w-full h-full rounded-lg"
                            allowFullScreen
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                          />
                        </div>
                      </div>
                    )}

                    {/* Add contextual images based on module */}
                    {currentModule.id === 'jet-module-1' && (
                      <div className="mb-6 bg-gradient-to-r from-green-50 to-blue-50 p-4 rounded-xl shadow-lg">
                        <div className="flex items-center gap-3 mb-3">
                          <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                            <Target className="w-4 h-4 text-green-600" />
                          </div>
                          <h4 className="text-lg font-semibold text-gray-800">African Energy Landscape</h4>
                        </div>
                        <img 
                          src={energyImage} 
                          alt="African renewable energy systems including solar panels, wind turbines, and hydroelectric facilities" 
                          className="w-full h-48 object-cover rounded-lg shadow-md mb-3"
                        />
                        <p className="text-sm text-gray-600 italic">Africa's abundant renewable energy potential: solar, wind, and hydro resources across the continent</p>
                      </div>
                    )}

                    {currentModule.id === 'jet-module-2' && (
                      <div className="mb-6 bg-gradient-to-r from-purple-50 to-indigo-50 p-4 rounded-xl shadow-lg">
                        <div className="flex items-center gap-3 mb-3">
                          <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                            <Eye className="w-4 h-4 text-purple-600" />
                          </div>
                          <h4 className="text-lg font-semibold text-gray-800">JET Framework Overview</h4>
                        </div>
                        <img 
                          src={jetPillarsImage} 
                          alt="Five interconnected pillars of just energy transition framework" 
                          className="w-full h-48 object-cover rounded-lg shadow-md mb-3"
                        />
                        <p className="text-sm text-gray-600 italic">The five pillars work together to ensure equitable and sustainable energy transformation</p>
                      </div>
                    )}

                    <div 
                      className="course-content animate-fade-in"
                      dangerouslySetInnerHTML={{ __html: currentModule.content || '' }}
                    />

                    {/* Audio completion status */}
                    {currentModule && audioCompleted[currentModule.id] && (
                      <div className="flex items-center gap-3 my-4 p-4 bg-gradient-to-r from-green-50 to-emerald-50 border-2 border-green-200 rounded-lg shadow-sm animate-fade-in">
                        <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                        <CheckCircle className="w-5 h-5 text-green-600" />
                        <span className="text-sm text-green-700 font-medium">Audio lesson completed! 🎉</span>
                      </div>
                    )}

                    {/* Quiz Indicator */}
                    {currentModule && (moduleQuizzes as any)[currentModule.id] && !showQuiz && (
                      <div className="mt-6 p-4 bg-gradient-to-r from-yellow-50 to-amber-50 border-2 border-yellow-200 rounded-lg shadow-sm">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center animate-pulse">
                            <Brain className="w-4 h-4 text-yellow-600" />
                          </div>
                          <div className="flex-1">
                            <h4 className="font-semibold text-yellow-800">Quiz Available</h4>
                            <p className="text-sm text-yellow-700">Complete the audio lesson to unlock the quiz for this module</p>
                          </div>
                          <div className="text-xs bg-yellow-200 text-yellow-800 px-2 py-1 rounded-full font-medium">
                            {((moduleQuizzes as any)[currentModule.id] || []).length} questions
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Quiz Section */}
                    {currentModule && showQuiz && audioCompleted[currentModule.id] && (moduleQuizzes as any)[currentModule.id] && (
                      <div className="my-6">
                        <Separator className="mb-4" />
                        <div className="bg-gradient-to-br from-blue-50 to-indigo-50 border-2 border-blue-200 rounded-xl p-6 shadow-lg animate-fade-in">
                          <div className="flex items-center gap-3 mb-4">
                            <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                              <CheckCircle className="w-5 h-5 text-blue-600" />
                            </div>
                            <h4 className="text-xl font-bold text-blue-900">Knowledge Check</h4>
                          </div>
                          <p className="text-sm text-blue-700 mb-6 bg-blue-100/50 p-3 rounded-lg border border-blue-200">📝 Answer these questions to complete the module (60% required to pass)</p>
                          
                          <div className="space-y-4">
                            {((moduleQuizzes as any)[currentModule.id] || []).map((question: any, qIndex: number) => (
                              <div key={qIndex} className="bg-white p-5 rounded-lg border-2 border-gray-200 shadow-sm hover:shadow-md transition-all animate-slide-in">
                                <div className="flex items-start gap-3 mb-4">
                                  <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 font-bold text-sm">
                                    {qIndex + 1}
                                  </div>
                                  <p className="font-medium text-gray-800 flex-1">{question.question}</p>
                                </div>
                                <div className="space-y-2">
                                  {question.options.map((option: string, oIndex: number) => {
                                    const isSelected = quizAnswers[`${currentModule.id}-${qIndex}`] === oIndex;
                                    return (
                                      <label 
                                        key={oIndex} 
                                        className={`flex items-center space-x-3 cursor-pointer p-3 rounded-lg border-2 transition-all duration-200 hover:shadow-sm ${
                                          isSelected 
                                            ? 'bg-blue-50 border-blue-300 shadow-sm' 
                                            : 'border-gray-200 hover:border-blue-200 hover:bg-blue-50/30'
                                        }`}
                                      >
                                        <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all ${
                                          isSelected ? 'border-blue-500 bg-blue-500' : 'border-gray-300'
                                        }`}>
                                          {isSelected && <div className="w-2 h-2 bg-white rounded-full"></div>}
                                        </div>
                                        <input
                                          type="radio"
                                          name={`question-${qIndex}`}
                                          value={oIndex}
                                          checked={isSelected}
                                          onChange={() => handleQuizAnswer(qIndex, oIndex)}
                                          className="sr-only"
                                        />
                                        <span className={`text-sm flex-1 ${isSelected ? 'font-medium text-blue-800' : 'text-gray-700'}`}>
                                          {option}
                                        </span>
                                      </label>
                                    );
                                  })}
                                </div>
                              </div>
                            ))}
                          </div>
                          
                          <div className="mt-6 flex gap-3">
                            <Button 
                              onClick={handleQuizSubmit}
                              disabled={Object.keys(quizAnswers).filter(k => k.startsWith(currentModule.id)).length < ((moduleQuizzes as any)[currentModule.id] || []).length}
                              className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white px-6 py-3 rounded-lg shadow-lg hover:shadow-xl transition-all duration-200 transform hover:scale-105 flex items-center gap-2"
                            >
                              <CheckCircle className="w-4 h-4" />
                              Submit Quiz
                            </Button>
                            <Button 
                              variant="outline" 
                              onClick={() => setShowQuiz(false)}
                            >
                              Cancel
                            </Button>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Quiz completion status */}
                    {currentModule && quizCompleted[currentModule.id] && (
                      <div className="flex items-center gap-2 my-4 p-3 bg-green-50 border border-green-200 rounded-lg">
                        <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        <span className="text-sm text-green-700 font-medium">Quiz completed successfully</span>
                      </div>
                    )}

                    <Separator className="my-4" />

                    {enrollment && (
                      <Button
                        onClick={() => handleModuleComplete(currentModule.id)}
                        disabled={
                          completions.some(c => c.moduleId === currentModule.id) ||
                          !audioCompleted[currentModule.id] ||
                          !quizCompleted[currentModule.id]
                        }
                        className="w-full"
                        data-testid={`button-complete-${currentModule.id}`}
                      >
                        {completions.some(c => c.moduleId === currentModule.id) 
                          ? 'Completed' 
                          : (!audioCompleted[currentModule.id] 
                            ? 'Listen to Audio First' 
                            : (!quizCompleted[currentModule.id] 
                              ? 'Complete Quiz First' 
                              : 'Mark as Complete'))
                        }
                      </Button>
                    )}
                  </CardContent>
                </Card>
              </div>
            ) : (
              <Card>
                <CardContent className="pt-6">
                  <div className="text-center text-gray-500">
                    <BookOpen className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                    <p>Select a module from the course content to start learning</p>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

        </div>

        {/* Naledi AI Chatbot */}
        {course && (
          <NalediAIChatbot 
            courseId={course.id} 
            currentModule={currentModule}
          />
        )}
      </div>
    </div>
  );
}