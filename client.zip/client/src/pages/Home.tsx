import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import Layout from "@/components/Layout";
import CourseCard from "@/components/CourseCard";
import ProgressBar from "@/components/ProgressBar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { BookOpen, Award, TrendingUp, Clock } from "lucide-react";
import { Link } from "wouter";

export default function Home() {
  const { user } = useAuth();

  const { data: enrollments = [] } = useQuery({
    queryKey: ['/api/users', (user as any)?.id, 'enrollments'],
    enabled: !!(user as any)?.id,
  });

  const { data: dashboardStats = {} } = useQuery({
    queryKey: ['/api/dashboard/stats'],
    enabled: !!(user as any)?.id,
  });

  const continuelearningCourses = (enrollments as any[]).filter((enrollment: any) => 
    enrollment?.progress < 100
  ).slice(0, 3);

  const completedCourses = (enrollments as any[]).filter((enrollment: any) => 
    enrollment.completedAt
  );

  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2" data-testid="text-welcome">
            Welcome back, {(user as any)?.firstName || 'Learner'}!
          </h1>
          <p className="text-gray-600">Continue your learning journey and explore new opportunities</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">XP Points</p>
                  <p className="text-2xl font-bold text-[hsl(43,74%,36%)]" data-testid="text-xp-points">
                    {(dashboardStats as any)?.totalXP || (user as any)?.xpPoints || 0}
                  </p>
                </div>
                <TrendingUp className="h-8 w-8 text-[hsl(43,74%,36%)]" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Courses Enrolled</p>
                  <p className="text-2xl font-bold" data-testid="text-enrolled-courses">
                    {(dashboardStats as any)?.enrollmentCount || (enrollments as any[]).length}
                  </p>
                </div>
                <BookOpen className="h-8 w-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Completed</p>
                  <p className="text-2xl font-bold text-green-600" data-testid="text-completed-courses">
                    {(dashboardStats as any)?.completedCount || completedCourses.length}
                  </p>
                </div>
                <Award className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Continue Learning */}
          <div>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold" data-testid="text-continue-learning">Continue Learning</h2>
              <Link href="/dashboard">
                <Button variant="outline" size="sm" data-testid="button-view-all">View All</Button>
              </Link>
            </div>

            <div className="space-y-4">
              {continuelearningCourses.length > 0 ? (
                continuelearningCourses.map((enrollment: any) => (
                  <Card key={enrollment.id} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                      <div className="flex items-center space-x-4">
                        <img
                          src="https://images.unsplash.com/photo-1466611653911-95081537e5b7?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100"
                          alt={enrollment.course?.title || 'Course'}
                          className="w-16 h-16 rounded-lg object-cover"
                          data-testid={`img-course-${enrollment.course?.id || enrollment.id}`}
                        />
                        <div className="flex-1">
                          <h3 className="font-semibold mb-1" data-testid={`text-course-title-${enrollment.course?.id || enrollment.id}`}>
                            {enrollment.course?.title || enrollment.courseTitle || 'Course'}
                          </h3>
                          <ProgressBar value={parseFloat(enrollment.progress)} className="mb-2" />
                          <p className="text-sm text-gray-600">
                            {Math.round(parseFloat(enrollment.progress))}% Complete
                          </p>
                        </div>
                        <Link href={`/courses/${enrollment.course?.id || enrollment.courseId}`}>
                          <Button size="sm" className="btn-gold" data-testid={`button-continue-${enrollment.course?.id || enrollment.courseId}`}>
                            Continue
                          </Button>
                        </Link>
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <Card>
                  <CardContent className="p-8 text-center">
                    <BookOpen className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold mb-2">No courses in progress</h3>
                    <p className="text-gray-600 mb-4">Start your learning journey by enrolling in a course</p>
                    <Button className="btn-gold" data-testid="button-browse-courses">
                      Browse Courses
                    </Button>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>


        </div>

        {/* Featured Course - JET 101 */}
        <div className="mt-12">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold" data-testid="text-featured-course">Featured Course</h2>
          </div>
          
          <Card className="bg-gradient-to-r from-[hsl(43,74%,36%)] to-[hsl(43,87%,58%)] text-white border-0">
            <CardContent className="p-8">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
                <div>
                  <h3 className="text-2xl font-bold mb-4" data-testid="text-jet-course-title">
                    Just Energy Transition 101
                  </h3>
                  <p className="text-lg mb-4 opacity-90">
                    Master the fundamentals of equitable energy transformation in Africa. Learn from South Africa's REIPPPP success story and discover career opportunities in renewable energy.
                  </p>
                  <div className="flex flex-wrap gap-4 mb-6 text-sm">
                    <span className="bg-white/20 px-3 py-1 rounded-full">📚 5 Modules</span>
                    <span className="bg-white/20 px-3 py-1 rounded-full">⏱️ 8-10 Hours</span>
                    <span className="bg-white/20 px-3 py-1 rounded-full">🎓 Certificate</span>
                    <span className="bg-white/20 px-3 py-1 rounded-full">🤖 AI Tutor</span>
                  </div>
                  <div className="flex flex-wrap gap-3">
                    <Link 
                      to="/courses/jet-energy-course" 
                      className="inline-block bg-white text-[hsl(43,74%,36%)] px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
                      data-testid="button-start-jet-course"
                    >
                      Start Course
                    </Link>
                    <Link 
                      to="/courses/jet-energy-course" 
                      className="inline-block bg-white/20 text-white px-6 py-3 rounded-lg font-semibold hover:bg-white/30 transition-colors"
                      data-testid="button-course-details"
                    >
                      View Course Details
                    </Link>
                  </div>
                </div>
                <div className="text-center">
                  <img
                    src="https://images.unsplash.com/photo-1466611653911-95081537e5b7?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"
                    alt="Just Energy Transition Course"
                    className="rounded-lg shadow-2xl mx-auto"
                    data-testid="img-jet-course"
                  />
                  <p className="mt-4 text-sm opacity-80">
                    Interactive modules with real South African data
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recent Achievements */}
        {completedCourses.length > 0 && (
          <div className="mt-12">
            <h2 className="text-2xl font-bold mb-6" data-testid="text-recent-achievements">Recent Achievements</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {completedCourses.slice(0, 3).map((enrollment: any) => (
                <Card key={enrollment.id} className="bg-gradient-to-r from-[hsl(43,74%,36%)] to-[hsl(43,87%,58%)] text-white">
                  <CardContent className="p-6 text-center">
                    <Award className="h-8 w-8 mx-auto mb-3" />
                    <h3 className="font-semibold mb-2" data-testid={`text-achievement-title-${enrollment.course.id}`}>
                      {enrollment.course.title}
                    </h3>
                    <p className="text-sm opacity-90">Completed on</p>
                    <p className="text-sm" data-testid={`text-completion-date-${enrollment.course.id}`}>
                      {new Date(enrollment.completedAt).toLocaleDateString()}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
}
