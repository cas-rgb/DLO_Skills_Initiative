import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { useAuth } from "@/hooks/useAuth";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { 
  Brain, 
  Lightbulb, 
  Target, 
  BookOpen, 
  Mic, 
  Image as ImageIcon,
  MessageSquare,
  TrendingUp,
  Sparkles,
  Zap,
  Star,
  Award,
  Trophy
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

interface QuizQuestion {
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

interface ProgressAnalysis {
  comprehensionLevel: number;
  strengths: string[];
  improvements: string[];
  feedback: string;
}

interface Recommendation {
  courseTitle: string;
  reason: string;
  difficulty: string;
}

export default function AIAssistant() {
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  
  const [activeTab, setActiveTab] = useState("quiz");
  const [moduleContent, setModuleContent] = useState("");
  const [questionCount, setQuestionCount] = useState(5);
  const [submissionText, setSubmissionText] = useState("");
  const [topic, setTopic] = useState("");
  const [level, setLevel] = useState("beginner");
  const [voiceoverText, setVoiceoverText] = useState("");
  const [voiceoverFilename, setVoiceoverFilename] = useState("");

  // Generate Quiz Questions
  const generateQuizMutation = useMutation({
    mutationFn: async ({ moduleContent, questionCount }: { moduleContent: string; questionCount: number }) => {
      return apiRequest(`/api/ai/generate-quiz`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ moduleContent, questionCount }),
      });
    },
    onSuccess: () => {
      toast({
        title: "Quiz Generated!",
        description: "Your personalized quiz questions are ready.",
      });
    },
    onError: () => {
      toast({
        title: "Generation Failed",
        description: "Unable to generate quiz questions. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Analyze Student Progress
  const analyzeProgressMutation = useMutation({
    mutationFn: async ({ submissionText }: { submissionText: string }) => {
      return apiRequest(`/api/ai/analyze-progress`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ submissionText }),
      });
    },
    onSuccess: () => {
      toast({
        title: "Analysis Complete!",
        description: "Your learning progress has been analyzed.",
      });
    },
    onError: () => {
      toast({
        title: "Analysis Failed",
        description: "Unable to analyze your progress. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Get Recommendations
  const getRecommendationsMutation = useMutation({
    mutationFn: async ({ completedCourses, interests }: { completedCourses: string[]; interests: string[] }) => {
      return apiRequest(`/api/ai/recommendations`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ completedCourses, interests }),
      });
    },
    onSuccess: () => {
      toast({
        title: "Recommendations Ready!",
        description: "Personalized course recommendations generated for you.",
      });
    },
    onError: () => {
      toast({
        title: "Recommendation Failed",
        description: "Unable to generate recommendations. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Generate Content
  const generateContentMutation = useMutation({
    mutationFn: async ({ topic, level }: { topic: string; level: string }) => {
      return apiRequest(`/api/ai/generate-content`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ topic, level }),
      });
    },
    onSuccess: () => {
      toast({
        title: "Content Generated!",
        description: "Educational content has been created for your topic.",
      });
    },
    onError: () => {
      toast({
        title: "Generation Failed",
        description: "Unable to generate content. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Generate Voiceover
  const generateVoiceoverMutation = useMutation({
    mutationFn: async ({ text, filename }: { text: string; filename: string }) => {
      return apiRequest(`/api/ai/voiceover`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text, filename }),
      });
    },
    onSuccess: () => {
      toast({
        title: "Voiceover Generated!",
        description: "Audio narration has been created for your content.",
      });
    },
    onError: () => {
      toast({
        title: "Generation Failed",
        description: "Unable to generate voiceover. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleGenerateQuiz = () => {
    if (!moduleContent.trim()) {
      toast({
        title: "Content Required",
        description: "Please provide module content to generate questions.",
        variant: "destructive",
      });
      return;
    }
    generateQuizMutation.mutate({ moduleContent, questionCount });
  };

  const handleAnalyzeProgress = () => {
    if (!submissionText.trim()) {
      toast({
        title: "Submission Required",
        description: "Please provide your work for analysis.",
        variant: "destructive",
      });
      return;
    }
    analyzeProgressMutation.mutate({ submissionText });
  };

  const handleGetRecommendations = () => {
    getRecommendationsMutation.mutate({ 
      completedCourses: ["JET 101"],
      interests: ["renewable energy", "just transition", "policy"] 
    });
  };

  const handleGenerateContent = () => {
    if (!topic.trim()) {
      toast({
        title: "Topic Required",
        description: "Please specify a topic for content generation.",
        variant: "destructive",
      });
      return;
    }
    generateContentMutation.mutate({ topic, level });
  };

  const handleGenerateVoiceover = () => {
    if (!voiceoverText.trim() || !voiceoverFilename.trim()) {
      toast({
        title: "Input Required",
        description: "Please provide both text and filename for voiceover generation.",
        variant: "destructive",
      });
      return;
    }
    generateVoiceoverMutation.mutate({ text: voiceoverText, filename: voiceoverFilename });
  };

  if (!isAuthenticated) {
    return (
      <div className="container max-w-4xl mx-auto p-6">
        <Card>
          <CardContent className="text-center py-12">
            <Brain className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
            <h2 className="text-2xl font-bold mb-2">AI Learning Assistant</h2>
            <p className="text-muted-foreground mb-6">
              Please log in to access personalized AI-powered learning features.
            </p>
            <Button 
              onClick={() => window.location.href = '/api/login'}
              className="bg-[#FFD700] text-black hover:bg-[#FFD700]/90"
            >
              Log In to Continue
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container max-w-6xl mx-auto p-6">
      {/* Header */}
      <div className="text-center mb-8">
        <div className="flex items-center justify-center gap-2 mb-4">
          <Sparkles className="h-8 w-8 text-[#FFD700]" />
          <h1 className="text-4xl font-bold">AI Learning Assistant</h1>
          <Sparkles className="h-8 w-8 text-[#FFD700]" />
        </div>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Your intelligent companion for mastering Just Energy Transition concepts with personalized learning support
        </p>
        <div className="flex items-center justify-center gap-4 mt-4">
          <Badge variant="secondary" className="text-sm">
            <Trophy className="h-4 w-4 mr-1" />
            Harvard-Level Quality
          </Badge>
          <Badge variant="secondary" className="text-sm">
            <Zap className="h-4 w-4 mr-1" />
            AI-Powered
          </Badge>
          <Badge variant="secondary" className="text-sm">
            <Star className="h-4 w-4 mr-1" />
            Personalized Learning
          </Badge>
        </div>
      </div>

      {/* AI Features Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="quiz" className="flex items-center gap-2">
            <Brain className="h-4 w-4" />
            Smart Quizzes
          </TabsTrigger>
          <TabsTrigger value="progress" className="flex items-center gap-2">
            <TrendingUp className="h-4 w-4" />
            Progress Analysis
          </TabsTrigger>
          <TabsTrigger value="recommendations" className="flex items-center gap-2">
            <Target className="h-4 w-4" />
            Recommendations
          </TabsTrigger>
          <TabsTrigger value="content" className="flex items-center gap-2">
            <BookOpen className="h-4 w-4" />
            Content Generator
          </TabsTrigger>
          <TabsTrigger value="voiceover" className="flex items-center gap-2">
            <Mic className="h-4 w-4" />
            Audio Narration
          </TabsTrigger>
        </TabsList>

        {/* Smart Quiz Generator */}
        <TabsContent value="quiz" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="h-5 w-5 text-[#FFD700]" />
                AI Quiz Generator
              </CardTitle>
              <p className="text-muted-foreground">
                Generate personalized quiz questions from any course content to test your understanding.
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Course Content or Topic</label>
                <Textarea
                  placeholder="Paste your course content, notes, or specify a topic you want to be quizzed on..."
                  value={moduleContent}
                  onChange={(e) => setModuleContent(e.target.value)}
                  className="min-h-[120px]"
                  data-testid="input-module-content"
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Number of Questions</label>
                <Input
                  type="number"
                  min="3"
                  max="15"
                  value={questionCount}
                  onChange={(e) => setQuestionCount(parseInt(e.target.value) || 5)}
                  className="w-32"
                  data-testid="input-question-count"
                />
              </div>
              <Button
                onClick={handleGenerateQuiz}
                disabled={generateQuizMutation.isPending}
                className="w-full bg-[#FFD700] text-black hover:bg-[#FFD700]/90"
                data-testid="button-generate-quiz"
              >
                {generateQuizMutation.isPending ? (
                  <>
                    <div className="animate-spin h-4 w-4 mr-2 border-2 border-current border-t-transparent rounded-full" />
                    Generating Questions...
                  </>
                ) : (
                  <>
                    <Lightbulb className="h-4 w-4 mr-2" />
                    Generate Quiz Questions
                  </>
                )}
              </Button>
              
              {generateQuizMutation.data && (
                <div className="mt-6 space-y-4">
                  <h3 className="text-lg font-semibold">Generated Quiz Questions</h3>
                  {generateQuizMutation.data.questions?.map((q: QuizQuestion, index: number) => (
                    <Card key={index} className="border-l-4 border-l-[#FFD700]">
                      <CardContent className="pt-6">
                        <h4 className="font-semibold mb-3">Question {index + 1}: {q.question}</h4>
                        <div className="grid grid-cols-1 gap-2 mb-3">
                          {q.options?.map((option: string, optIndex: number) => (
                            <div key={optIndex} className={cn(
                              "p-2 rounded border",
                              optIndex === q.correctAnswer 
                                ? "bg-green-50 border-green-200 text-green-800" 
                                : "bg-gray-50 border-gray-200"
                            )}>
                              {String.fromCharCode(65 + optIndex)}. {option}
                              {optIndex === q.correctAnswer && <Badge className="ml-2 bg-green-500">Correct</Badge>}
                            </div>
                          ))}
                        </div>
                        <div className="bg-blue-50 border border-blue-200 rounded p-3">
                          <p className="text-sm text-blue-800"><strong>Explanation:</strong> {q.explanation}</p>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Progress Analysis */}
        <TabsContent value="progress" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-[#FFD700]" />
                AI Progress Analyzer
              </CardTitle>
              <p className="text-muted-foreground">
                Get detailed feedback on your assignments and learning progress with personalized recommendations.
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Your Assignment or Response</label>
                <Textarea
                  placeholder="Paste your assignment, essay, or response for AI analysis and feedback..."
                  value={submissionText}
                  onChange={(e) => setSubmissionText(e.target.value)}
                  className="min-h-[120px]"
                  data-testid="input-submission-text"
                />
              </div>
              <Button
                onClick={handleAnalyzeProgress}
                disabled={analyzeProgressMutation.isPending}
                className="w-full bg-[#FFD700] text-black hover:bg-[#FFD700]/90"
                data-testid="button-analyze-progress"
              >
                {analyzeProgressMutation.isPending ? (
                  <>
                    <div className="animate-spin h-4 w-4 mr-2 border-2 border-current border-t-transparent rounded-full" />
                    Analyzing Progress...
                  </>
                ) : (
                  <>
                    <MessageSquare className="h-4 w-4 mr-2" />
                    Analyze My Progress
                  </>
                )}
              </Button>
              
              {analyzeProgressMutation.data && (
                <div className="mt-6 space-y-4">
                  <h3 className="text-lg font-semibold">Progress Analysis Results</h3>
                  <Card className="border-l-4 border-l-[#FFD700]">
                    <CardContent className="pt-6 space-y-4">
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-medium">Comprehension Level</span>
                          <Badge variant="outline">{analyzeProgressMutation.data.comprehensionLevel}/10</Badge>
                        </div>
                        <Progress 
                          value={analyzeProgressMutation.data.comprehensionLevel * 10} 
                          className="w-full"
                        />
                      </div>
                      
                      <div className="grid md:grid-cols-2 gap-4">
                        <div className="bg-green-50 border border-green-200 rounded p-4">
                          <h4 className="font-semibold text-green-800 mb-2">Strengths</h4>
                          <ul className="list-disc list-inside text-sm text-green-700 space-y-1">
                            {analyzeProgressMutation.data.strengths?.map((strength: string, index: number) => (
                              <li key={index}>{strength}</li>
                            ))}
                          </ul>
                        </div>
                        
                        <div className="bg-orange-50 border border-orange-200 rounded p-4">
                          <h4 className="font-semibold text-orange-800 mb-2">Areas for Improvement</h4>
                          <ul className="list-disc list-inside text-sm text-orange-700 space-y-1">
                            {analyzeProgressMutation.data.improvements?.map((improvement: string, index: number) => (
                              <li key={index}>{improvement}</li>
                            ))}
                          </ul>
                        </div>
                      </div>
                      
                      <div className="bg-blue-50 border border-blue-200 rounded p-4">
                        <h4 className="font-semibold text-blue-800 mb-2">Personalized Feedback</h4>
                        <p className="text-sm text-blue-700">{analyzeProgressMutation.data.feedback}</p>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Personalized Recommendations */}
        <TabsContent value="recommendations" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5 text-[#FFD700]" />
                Personalized Course Recommendations
              </CardTitle>
              <p className="text-muted-foreground">
                Get AI-powered recommendations for your next learning journey based on your progress and interests.
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button
                onClick={handleGetRecommendations}
                disabled={getRecommendationsMutation.isPending}
                className="w-full bg-[#FFD700] text-black hover:bg-[#FFD700]/90"
                data-testid="button-get-recommendations"
              >
                {getRecommendationsMutation.isPending ? (
                  <>
                    <div className="animate-spin h-4 w-4 mr-2 border-2 border-current border-t-transparent rounded-full" />
                    Generating Recommendations...
                  </>
                ) : (
                  <>
                    <Award className="h-4 w-4 mr-2" />
                    Get My Recommendations
                  </>
                )}
              </Button>
              
              {getRecommendationsMutation.data && (
                <div className="mt-6 space-y-4">
                  <h3 className="text-lg font-semibold">Recommended for You</h3>
                  <div className="grid gap-4">
                    {getRecommendationsMutation.data.recommendations?.map((rec: Recommendation, index: number) => (
                      <Card key={index} className="border-l-4 border-l-[#FFD700]">
                        <CardContent className="pt-6">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <h4 className="font-semibold text-lg mb-2">{rec.courseTitle}</h4>
                              <p className="text-muted-foreground mb-3">{rec.reason}</p>
                              <Badge variant="outline">{rec.difficulty}</Badge>
                            </div>
                            <Button variant="outline" size="sm">
                              <BookOpen className="h-4 w-4 mr-1" />
                              Learn More
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Content Generator */}
        <TabsContent value="content" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="h-5 w-5 text-[#FFD700]" />
                AI Content Generator
              </CardTitle>
              <p className="text-muted-foreground">
                Generate comprehensive educational content on any energy transition topic tailored to your learning level.
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Topic</label>
                  <Input
                    placeholder="e.g., Solar PV technology, Wind energy economics..."
                    value={topic}
                    onChange={(e) => setTopic(e.target.value)}
                    data-testid="input-topic"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">Learning Level</label>
                  <select 
                    value={level} 
                    onChange={(e) => setLevel(e.target.value)}
                    className="w-full p-2 border border-gray-300 rounded-md"
                    data-testid="select-level"
                  >
                    <option value="beginner">Beginner</option>
                    <option value="intermediate">Intermediate</option>
                    <option value="advanced">Advanced</option>
                  </select>
                </div>
              </div>
              <Button
                onClick={handleGenerateContent}
                disabled={generateContentMutation.isPending}
                className="w-full bg-[#FFD700] text-black hover:bg-[#FFD700]/90"
                data-testid="button-generate-content"
              >
                {generateContentMutation.isPending ? (
                  <>
                    <div className="animate-spin h-4 w-4 mr-2 border-2 border-current border-t-transparent rounded-full" />
                    Generating Content...
                  </>
                ) : (
                  <>
                    <Sparkles className="h-4 w-4 mr-2" />
                    Generate Educational Content
                  </>
                )}
              </Button>
              
              {generateContentMutation.data && (
                <div className="mt-6">
                  <h3 className="text-lg font-semibold mb-4">Generated Content</h3>
                  <Card className="border-l-4 border-l-[#FFD700]">
                    <CardContent className="pt-6">
                      <pre className="whitespace-pre-wrap text-sm">{generateContentMutation.data.content}</pre>
                    </CardContent>
                  </Card>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Voiceover Generator */}
        <TabsContent value="voiceover" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Mic className="h-5 w-5 text-[#FFD700]" />
                AI Audio Narration
              </CardTitle>
              <p className="text-muted-foreground">
                Convert any text content into professional audio narration for enhanced accessibility and learning.
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Text to Convert</label>
                <Textarea
                  placeholder="Enter the text you want to convert to audio narration..."
                  value={voiceoverText}
                  onChange={(e) => setVoiceoverText(e.target.value)}
                  className="min-h-[120px]"
                  data-testid="input-voiceover-text"
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Audio Filename</label>
                <Input
                  placeholder="e.g., chapter-1-intro"
                  value={voiceoverFilename}
                  onChange={(e) => setVoiceoverFilename(e.target.value)}
                  data-testid="input-voiceover-filename"
                />
              </div>
              <Button
                onClick={handleGenerateVoiceover}
                disabled={generateVoiceoverMutation.isPending}
                className="w-full bg-[#FFD700] text-black hover:bg-[#FFD700]/90"
                data-testid="button-generate-voiceover"
              >
                {generateVoiceoverMutation.isPending ? (
                  <>
                    <div className="animate-spin h-4 w-4 mr-2 border-2 border-current border-t-transparent rounded-full" />
                    Generating Audio...
                  </>
                ) : (
                  <>
                    <Mic className="h-4 w-4 mr-2" />
                    Generate Audio Narration
                  </>
                )}
              </Button>
              
              {generateVoiceoverMutation.data && (
                <div className="mt-6">
                  <h3 className="text-lg font-semibold mb-4">Audio Generated</h3>
                  <Card className="border-l-4 border-l-[#FFD700]">
                    <CardContent className="pt-6">
                      <p className="text-sm text-muted-foreground mb-2">
                        Audio file generated: {generateVoiceoverMutation.data.filename}
                      </p>
                      <Badge variant="outline" className="bg-green-50 text-green-700">
                        ✓ Audio ready for download
                      </Badge>
                    </CardContent>
                  </Card>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}