import { useAuth } from "@/hooks/useAuth";
import Layout from "@/components/Layout";
import RoleBasedDashboard from "@/components/RoleBasedDashboard";
import { Link } from "wouter";

export default function Dashboard() {
  const { user } = useAuth();

  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2" data-testid="text-dashboard-title">
            {user?.role === 'admin' ? 'Admin Dashboard' : 
             user?.role === 'facilitator' ? 'Facilitator Dashboard' : 
             'Learning Dashboard'}
          </h1>
          <p className="text-gray-600">
            {user?.role === 'admin' ? 'Manage platform users, courses, and analytics' :
             user?.role === 'facilitator' ? 'Manage your courses and track student progress' :
             'Track your learning progress and achievements'}
          </p>
        </div>

        <RoleBasedDashboard />
        
        {/* Quick Access to JET Course */}
        <div className="mt-8">
          <div className="bg-[hsl(43,74%,36%)] text-white p-6 rounded-lg">
            <h3 className="text-xl font-semibold mb-2" data-testid="text-quick-access-title">
              Quick Access: JET 101 Course
            </h3>
            <p className="mb-4 opacity-90">
              Access the comprehensive Just Energy Transition course directly
            </p>
            <div className="flex flex-wrap gap-4">
              <Link 
                to="/courses/jet-energy-course" 
                className="bg-white text-[hsl(43,74%,36%)] px-4 py-2 rounded font-semibold hover:bg-gray-100 transition-colors inline-block"
                data-testid="button-view-course-ai"
              >
                View Course with AI Features
              </Link>
              <a 
                href="/course" 
                className="bg-white/20 text-white px-4 py-2 rounded font-semibold hover:bg-white/30 transition-colors"
                data-testid="button-course-overview"
              >
                Static Course Overview
              </a>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
