import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { BookOpen, Users, Settings, CheckCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import logoDark from "@assets/cropped-ENERGY-SKILLS-LOGO-2-3-768x219_1756645623163.png";

type UserRole = 'learner' | 'facilitator' | 'admin';

interface RoleOption {
  id: UserRole;
  title: string;
  description: string;
  icon: React.ElementType;
  features: string[];
}

const roleOptions: RoleOption[] = [
  {
    id: 'learner',
    title: 'Learner',
    description: 'Access courses, track progress, and earn certificates',
    icon: BookOpen,
    features: [
      'Access to all published courses',
      'Progress tracking and analytics',
      'Interactive quizzes and assessments',
      'Digital certificates upon completion',
      'Mobile-first learning experience'
    ]
  },
  {
    id: 'facilitator',
    title: 'Facilitator',
    description: 'Create courses, manage content, and track student progress',
    icon: Users,
    features: [
      'Create and publish courses',
      'Upload videos, documents, and materials',
      'Design quizzes and assessments',
      'Monitor student progress',
      'Grade assignments and provide feedback'
    ]
  },
  {
    id: 'admin',
    title: 'Tech Administrator',
    description: 'Manage the platform, analyze data, and oversee system health',
    icon: Settings,
    features: [
      'System health monitoring',
      'User management and analytics',
      'Platform-wide data visualization',
      'Course and user moderation',
      'Advanced reporting and insights'
    ]
  }
];

export default function RoleSelection() {
  const [selectedRole, setSelectedRole] = useState<UserRole | null>(null);
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const updateRoleMutation = useMutation({
    mutationFn: async (role: UserRole) => {
      await apiRequest('/api/auth/update-role', 'PUT', { role });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/auth/user'] });
      toast({
        title: "Role Updated",
        description: "Your account has been configured successfully!",
      });
      setLocation('/dashboard');
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update your role. Please try again.",
        variant: "destructive",
      });
      console.error('Role update error:', error);
    },
  });

  const handleContinue = () => {
    if (selectedRole) {
      updateRoleMutation.mutate(selectedRole);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-white flex items-center justify-center p-4">
      <div className="w-full max-w-4xl">
        {/* Header */}
        <div className="text-center mb-8">
          <img
            src={logoDark}
            alt="DLO Skills Initiative"
            className="h-16 mx-auto mb-6"
            data-testid="logo-role-selection"
          />
          <h1 className="text-3xl font-bold text-gray-900 mb-2" data-testid="title-role-selection">
            Welcome to DLO Skills Initiative
          </h1>
          <p className="text-lg text-gray-600" data-testid="description-role-selection">
            Please select your role to get started with the right dashboard and features
          </p>
        </div>

        {/* Role Selection Cards */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          {roleOptions.map((role) => (
            <Card
              key={role.id}
              className={`cursor-pointer transition-all duration-200 hover:shadow-lg border-2 ${
                selectedRole === role.id
                  ? 'border-gold bg-gold/5 shadow-lg'
                  : 'border-gray-200 hover:border-gold/50'
              }`}
              onClick={() => setSelectedRole(role.id)}
              data-testid={`card-role-${role.id}`}
            >
              <CardHeader className="text-center">
                <div className={`mx-auto w-12 h-12 rounded-full flex items-center justify-center mb-3 ${
                  selectedRole === role.id ? 'bg-gold text-white' : 'bg-gray-100 text-gray-600'
                }`}>
                  <role.icon className="w-6 h-6" />
                </div>
                <CardTitle className="text-xl font-semibold">{role.title}</CardTitle>
                <CardDescription className="text-sm text-gray-600">
                  {role.description}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {role.features.map((feature, index) => (
                    <li key={index} className="flex items-start gap-2 text-sm">
                      <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Continue Button */}
        <div className="text-center">
          <Button
            size="lg"
            className="btn-gold px-8 py-3 text-lg font-semibold"
            onClick={handleContinue}
            disabled={!selectedRole || updateRoleMutation.isPending}
            data-testid="button-continue-role"
          >
            {updateRoleMutation.isPending ? 'Setting up your account...' : 'Continue to Dashboard'}
          </Button>
          {!selectedRole && (
            <p className="text-sm text-gray-500 mt-2">
              Please select a role above to continue
            </p>
          )}
        </div>

        {/* Info Note */}
        <div className="mt-8 bg-blue-50 border border-blue-200 rounded-lg p-4">
          <p className="text-sm text-blue-800 text-center">
            <strong>Note:</strong> You can change your role later through your account settings if needed.
          </p>
        </div>
      </div>
    </div>
  );
}