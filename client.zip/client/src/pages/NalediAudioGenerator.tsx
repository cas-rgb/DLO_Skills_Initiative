
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Volume2, Download, Play, Pause, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function NalediAudioGenerator() {
  const [selectedModule, setSelectedModule] = useState<string>("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [audioData, setAudioData] = useState<string | null>(null);
  const [audioPath, setAudioPath] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [generationResults, setGenerationResults] = useState<any[]>([]);
  const { toast } = useToast();

  const modules = [
    { value: "1", label: "Module 1: What is Just Energy Transition?" },
    { value: "2", label: "Module 2: The Five Pillars of Just Energy Transition" },
    { value: "3", label: "Module 3: Pillar 1 - Equitable Access to Clean Energy" },
    { value: "4", label: "Module 4: Pillar 2 - Environmental Justice" },
    { value: "5", label: "Module 5: Career Pathways in Renewable Energy" },
  ];

  const generateSingleModuleAudio = async () => {
    if (!selectedModule) {
      toast({
        title: "Module Required",
        description: "Please select a module to generate audio for.",
        variant: "destructive",
      });
      return;
    }

    setIsGenerating(true);
    try {
      const response = await fetch('/api/ai/generate-naledi-audio', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ moduleNumber: parseInt(selectedModule) }),
        credentials: 'include',
      });

      if (!response.ok) {
        throw new Error('Failed to generate Naledi audio');
      }

      const result = await response.json();
      setAudioData(result.audioData);
      setAudioPath(result.audioPath);

      toast({
        title: "Audio Generated!",
        description: `Naledi's narration for Module ${selectedModule} is ready.`,
      });
    } catch (error) {
      console.error('Error generating audio:', error);
      toast({
        title: "Generation Failed",
        description: "Unable to generate Naledi audio. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const generateAllModulesAudio = async () => {
    setIsGenerating(true);
    setGenerationResults([]);
    
    try {
      const response = await fetch('/api/ai/generate-all-naledi-audio', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
      });

      if (!response.ok) {
        throw new Error('Failed to generate all Naledi audio files');
      }

      const result = await response.json();
      setGenerationResults(result.results);

      const successCount = result.results.filter(r => r.success).length;
      toast({
        title: "Batch Generation Complete!",
        description: `Successfully generated ${successCount}/5 Naledi audio files.`,
      });
    } catch (error) {
      console.error('Error generating all audio:', error);
      toast({
        title: "Batch Generation Failed",
        description: "Unable to generate all Naledi audio files.",
        variant: "destructive",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const playAudio = () => {
    if (audioData) {
      const audio = new Audio(`data:audio/mpeg;base64,${audioData}`);
      audio.play();
      setIsPlaying(true);
      
      audio.onended = () => {
        setIsPlaying(false);
      };
    }
  };

  const downloadAudio = () => {
    if (audioData) {
      const link = document.createElement('a');
      link.href = `data:audio/mpeg;base64,${audioData}`;
      link.download = `naledi-module-${selectedModule}.mp3`;
      link.click();
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold mb-4">Naledi AI Audio Generator</h1>
        <p className="text-lg text-gray-600">
          Generate South African AI narration from facilitator scripts
        </p>
      </div>

      <div className="grid gap-6">
        {/* Single Module Generation */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Volume2 className="w-5 h-5" />
              Generate Single Module Audio
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Select value={selectedModule} onValueChange={setSelectedModule}>
              <SelectTrigger>
                <SelectValue placeholder="Select a module" />
              </SelectTrigger>
              <SelectContent>
                {modules.map((module) => (
                  <SelectItem key={module.value} value={module.value}>
                    {module.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <div className="flex gap-2">
              <Button
                onClick={generateSingleModuleAudio}
                disabled={isGenerating || !selectedModule}
                className="flex-1"
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Generating Naledi Audio...
                  </>
                ) : (
                  <>
                    <Volume2 className="w-4 h-4 mr-2" />
                    Generate Audio
                  </>
                )}
              </Button>
            </div>

            {audioData && (
              <div className="flex gap-2 mt-4">
                <Button onClick={playAudio} variant="outline" disabled={isPlaying}>
                  {isPlaying ? <Pause className="w-4 h-4 mr-2" /> : <Play className="w-4 h-4 mr-2" />}
                  {isPlaying ? "Playing..." : "Play Audio"}
                </Button>
                <Button onClick={downloadAudio} variant="outline">
                  <Download className="w-4 h-4 mr-2" />
                  Download MP3
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Batch Generation */}
        <Card>
          <CardHeader>
            <CardTitle>Generate All Modules Audio</CardTitle>
          </CardHeader>
          <CardContent>
            <Button
              onClick={generateAllModulesAudio}
              disabled={isGenerating}
              className="w-full mb-4"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Generating All Naledi Audio Files...
                </>
              ) : (
                <>
                  <Volume2 className="w-4 h-4 mr-2" />
                  Generate All 5 Modules
                </>
              )}
            </Button>

            {generationResults.length > 0 && (
              <div className="space-y-2">
                <h4 className="font-semibold">Generation Results:</h4>
                {generationResults.map((result, index) => (
                  <div
                    key={index}
                    className={`p-2 rounded ${result.success ? 'bg-green-50 text-green-800' : 'bg-red-50 text-red-800'}`}
                  >
                    Module {result.moduleNumber}: {result.success ? `✓ Generated (${result.audioPath})` : `✗ Failed (${result.error})`}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
