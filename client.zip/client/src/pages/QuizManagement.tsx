import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, Edit, Trash2, Eye, Users, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { Quiz, Course } from "@shared/schema";
import QuizCreator from "@/components/QuizCreator";
import QuizGrading from "@/components/QuizGrading";

export default function QuizManagement() {
  const [selectedCourse, setSelectedCourse] = useState<string>("");
  const [editingQuiz, setEditingQuiz] = useState<Quiz | null>(null);
  const [showCreator, setShowCreator] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch courses for filter
  const { data: courses = [] } = useQuery<Course[]>({
    queryKey: ["/api/courses"],
  });

  // Fetch quizzes
  const { data: quizzes = [], isLoading } = useQuery<Quiz[]>({
    queryKey: ["/api/quizzes", selectedCourse],
    queryFn: () => {
      const params = selectedCourse ? `?courseId=${selectedCourse}` : "";
      return apiRequest(`/api/quizzes${params}`) as Promise<Quiz[]>;
    },
  });

  // Delete quiz mutation
  const deleteQuizMutation = useMutation({
    mutationFn: (quizId: string) => apiRequest(`/api/quizzes/${quizId}`, "DELETE"),
    onSuccess: () => {
      toast({
        title: "Quiz deleted successfully",
        description: "The quiz has been removed from the course.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/quizzes"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete quiz. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleDeleteQuiz = (quizId: string) => {
    if (confirm("Are you sure you want to delete this quiz? This action cannot be undone.")) {
      deleteQuizMutation.mutate(quizId);
    }
  };

  const handleQuizCreated = () => {
    setShowCreator(false);
    setEditingQuiz(null);
    queryClient.invalidateQueries({ queryKey: ["/api/quizzes"] });
    toast({
      title: "Quiz saved successfully",
      description: "Your quiz has been created and is ready for students.",
    });
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Quiz Management</h1>
          <p className="text-gray-600 mt-2">Create, edit, and manage quizzes for your courses</p>
        </div>
        <Button
          onClick={() => {
            setEditingQuiz(null);
            setShowCreator(true);
          }}
          className="bg-yellow-600 hover:bg-yellow-700"
          data-testid="button-create-quiz"
        >
          <Plus className="w-4 h-4 mr-2" />
          Create Quiz
        </Button>
      </div>

      <Tabs defaultValue="quizzes" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="quizzes" data-testid="tab-quizzes">My Quizzes</TabsTrigger>
          <TabsTrigger value="grading" data-testid="tab-grading">Grading</TabsTrigger>
        </TabsList>

        <TabsContent value="quizzes" className="space-y-6">
          {/* Course Filter */}
          <div className="flex gap-4 items-center">
            <label className="text-sm font-medium">Filter by Course:</label>
            <select
              value={selectedCourse}
              onChange={(e) => setSelectedCourse(e.target.value)}
              className="border rounded-md px-3 py-2 text-sm min-w-[200px]"
              data-testid="select-course-filter"
            >
              <option value="">All Courses</option>
              {courses.map((course) => (
                <option key={course.id} value={course.id}>
                  {course.title}
                </option>
              ))}
            </select>
          </div>

          {/* Quiz List */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {isLoading ? (
              <div className="col-span-full text-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-yellow-600 mx-auto"></div>
                <p className="mt-2 text-gray-600">Loading quizzes...</p>
              </div>
            ) : quizzes.length === 0 ? (
              <div className="col-span-full text-center py-12">
                <div className="text-gray-400 mb-4">
                  <Users className="w-16 h-16 mx-auto" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">No quizzes found</h3>
                <p className="text-gray-600 mb-4">Create your first quiz to get started</p>
                <Button
                  onClick={() => setShowCreator(true)}
                  className="bg-yellow-600 hover:bg-yellow-700"
                  data-testid="button-create-first-quiz"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Create Quiz
                </Button>
              </div>
            ) : (
              quizzes.map((quiz) => (
                <Card key={quiz.id} className="hover:shadow-md transition-shadow" data-testid={`card-quiz-${quiz.id}`}>
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <CardTitle className="text-lg" data-testid={`text-quiz-title-${quiz.id}`}>
                          {quiz.title}
                        </CardTitle>
                        <CardDescription className="mt-1" data-testid={`text-quiz-description-${quiz.id}`}>
                          {quiz.description || "No description"}
                        </CardDescription>
                      </div>
                      <Badge variant={quiz.isPublished ? "default" : "secondary"} data-testid={`badge-quiz-status-${quiz.id}`}>
                        {quiz.isPublished ? "Published" : "Draft"}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-center gap-4 text-sm text-gray-600">
                      <div className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        <span data-testid={`text-quiz-time-${quiz.id}`}>
                          {quiz.timeLimit ? `${quiz.timeLimit} min` : "No limit"}
                        </span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Users className="w-4 h-4" />
                        <span data-testid={`text-quiz-attempts-${quiz.id}`}>
                          {quiz.maxAttempts ? `${quiz.maxAttempts} attempts` : "Unlimited"}
                        </span>
                      </div>
                    </div>
                    
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          setEditingQuiz(quiz);
                          setShowCreator(true);
                        }}
                        data-testid={`button-edit-quiz-${quiz.id}`}
                      >
                        <Edit className="w-4 h-4 mr-1" />
                        Edit
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        data-testid={`button-preview-quiz-${quiz.id}`}
                      >
                        <Eye className="w-4 h-4 mr-1" />
                        Preview
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleDeleteQuiz(quiz.id)}
                        className="text-red-600 hover:text-red-700 hover:border-red-200"
                        data-testid={`button-delete-quiz-${quiz.id}`}
                      >
                        <Trash2 className="w-4 h-4 mr-1" />
                        Delete
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </TabsContent>

        <TabsContent value="grading">
          <QuizGrading />
        </TabsContent>
      </Tabs>

      {/* Quiz Creator Dialog */}
      <Dialog open={showCreator} onOpenChange={setShowCreator}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingQuiz ? "Edit Quiz" : "Create New Quiz"}
            </DialogTitle>
          </DialogHeader>
          <QuizCreator
            quiz={editingQuiz}
            onSave={handleQuizCreated}
            onCancel={() => setShowCreator(false)}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}