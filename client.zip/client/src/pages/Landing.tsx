import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Star, Clock, Users, CheckCircle, Shield, Link as LinkIcon } from "lucide-react";
import { Link } from "wouter";
import CourseCard from "@/components/CourseCard";
import Navbar from "@/components/Navbar";
import heroBackgroundImage from "@assets/1_1756648020541.jpg";
import dloInstructor from "@assets/DLO 7_1756648227130.jpg";
import dloTeamTraining from "@assets/DLO 6_1756648227131.jpg";
import dloSolarExpert from "@assets/DLO6_1756648227131.jpg";
import dloGraduation from "@assets/DLO5_1756648227132.jpg";
import dloFieldWork from "@assets/DLO4_1756648227133.jpg";
import dloGraduates from "@assets/DLO 3_1756648227134.jpg";
import dloEnergyPros from "@assets/dlo2_1756648227134.jpg";
import dloSuccessStory from "@assets/0G9A0722-1-1536x1024_1756648231455.jpg";

export default function Landing() {



  const { data: courses = [] } = useQuery({
    queryKey: ['/api/courses?limit=6'],
  });

  const handleAuthRedirect = () => {
    window.location.href = "/api/login";
  };

  const scrollToSection = (sectionId: string) => {
    document.getElementById(sectionId)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-white">
      <Navbar onAuthClick={handleAuthRedirect} />

      {/* Hero Section */}
      <section id="home" className="relative gradient-hero text-white overflow-hidden">
        <div
          className="absolute inset-0 z-10"
          style={{
            backgroundImage: `url(${heroBackgroundImage})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center'
          }}
        />
        <div className="absolute inset-0 bg-white/30 z-15"></div>

        <div className="relative z-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 lg:py-32">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 drop-shadow-xl text-black" style={{textShadow: '2px 2px 4px rgba(255,255,255,0.9), 1px 1px 2px rgba(255,255,255,0.7)'}} data-testid="hero-title">
              Africa's First AI-Powered
              <span className="text-gold"> Energy Skills Platform</span>
            </h1>
            <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto drop-shadow-lg text-black" style={{textShadow: '1px 1px 3px rgba(255,255,255,0.9), 0px 0px 10px rgba(255,255,255,0.6)'}} data-testid="hero-description">
              Born from our acclaimed workshop series, now evolved into an intelligent digital learning app. Master renewable energy skills with AI-enhanced support, anytime, anywhere.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                className="btn-gold px-8 py-4 text-lg font-semibold transform hover:scale-105"
                onClick={handleAuthRedirect}
                data-testid="button-start-learning"
              >
                Launch Your Energy Career
              </Button>
              <Button
                variant="outline"
                size="lg"
                className="border-2 border-white text-black bg-white hover:bg-gray-100 hover:text-black px-8 py-4 text-lg font-semibold"
                onClick={() => scrollToSection('courses')}
                data-testid="button-view-courses"
              >
                View Courses
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* 2025 Solar Training Programme Section */}
      <section className="py-16 bg-gradient-to-r from-green-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="flex items-center justify-center gap-2 mb-4">
              <span className="text-4xl">🤖</span>
              <h2 className="text-3xl md:text-4xl font-bold text-green-800" data-testid="solar-programme-title">
                AI-Enhanced Solar Skills Training
              </h2>
            </div>
            <p className="text-lg text-gray-700 max-w-4xl mx-auto mb-6">
              <strong>From Workshop to Smartphone:</strong> After delivering transformative in-person solar training workshops across South Africa, 
              we've digitized our expertise into an intelligent learning app. Our enhanced platform brings the same quality training 
              that industry leaders praised - now accessible 24/7 from any smartphone.
            </p>
            <p className="text-lg text-gray-700 max-w-4xl mx-auto">
              Experience enhanced learning with our intelligent features, interactive simulations, and real-time progress tracking. 
              Whether you're starting your energy career or scaling your green enterprise, our app supports your learning journey and pace.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 items-stretch mb-12">
            <div className="bg-white p-8 rounded-xl shadow-lg flex flex-col">
              <div className="mb-6">
                <img
                  src={dloInstructor}
                  alt="DLO Energy instructor leading workshop training session"
                  className="w-full rounded-lg shadow-md"
                />
              </div>
              <h3 className="text-2xl font-bold mb-6 text-green-800">Revolutionary Learning Technology</h3>
              <ul className="space-y-3 flex-grow">
                <li className="flex items-start">
                  <CheckCircle className="text-green-500 w-5 h-5 mr-3 mt-1" />
                  <span><strong>Smart Learning Support</strong> - Intelligent assistance available 24/7</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="text-green-500 w-5 h-5 mr-3 mt-1" />
                  <span><strong>Smart Mobile Learning</strong> - Optimized for African smartphone usage patterns</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="text-green-500 w-5 h-5 mr-3 mt-1" />
                  <span><strong>Workshop-to-App Evolution</strong> - All our proven training methods now digital</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="text-green-500 w-5 h-5 mr-3 mt-1" />
                  <span><strong>Interactive Learning Experience</strong> - Engaging content with multimedia support</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="text-green-500 w-5 h-5 mr-3 mt-1" />
                  <span><strong>Instant Progress Tracking</strong> - See your growth in real-time</span>
                </li>
              </ul>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-lg flex flex-col">
              <div className="mb-6">
                <img
                  src={dloTeamTraining}
                  alt="DLO Energy team at solar field training"
                  className="w-full rounded-lg shadow-md"
                />
              </div>
              <h3 className="text-2xl font-bold mb-6 text-green-800">From Workshops to Smartphone Learning</h3>
              <div className="flex-grow">
                <p className="text-gray-700 mb-4">
                  <strong>The Digital Evolution:</strong> DLO Energy Skills Initiative pioneered hands-on green skills workshops that 
                  earned acclaim from industry leaders at Eskom, Sasol, and Duke CE. Now we've transformed this proven methodology 
                  into an intelligent mobile app that brings expert training directly to your phone.
                </p>
                <p className="text-gray-700 mb-6">
                  Our intelligent learning app combines 20+ years of energy sector expertise with enhanced digital coaching. 
                  Every lesson, quiz, and career guidance feature is designed for African learners - making world-class energy 
                  education accessible whether you're in Johannesburg, Lagos, or rural communities across the continent.
                </p>
              </div>
            </div>
          </div>

          {/* Testimonials */}
          <div className="bg-white rounded-xl shadow-lg p-8">
            <div className="mb-8">
              <img
                src={dloFieldWork}
                alt="DLO Energy field training and hands-on learning"
                className="w-full rounded-lg shadow-md"
              />
            </div>
            <h3 className="text-2xl font-bold mb-8 text-center text-green-800">From Acclaimed Workshops to Digital Innovation</h3>
            <p className="text-center text-lg text-gray-700 mb-8 italic">
              "These testimonials from industry leaders validate our workshop expertise - the same quality content now enhanced with smart technology in our mobile app:"
            </p>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 text-center">
              <div className="text-center">
                <p className="text-sm text-gray-600 mb-2 italic">
                  "A truly informative workshop unpacking issues and challenges seldom spoken about regarding the just energy transition."
                </p>
                <p className="font-semibold text-green-800">Pindi Mabena</p>
                <p className="text-xs text-gray-500">General Manager, Eskom Transmission</p>
              </div>
              <div className="text-center">
                <p className="text-sm text-gray-600 mb-2 italic">
                  "This is a well curated and insightful workshop hugely beneficial to our SMMEs."
                </p>
                <p className="font-semibold text-green-800">Jabulile Ratsibe</p>
                <p className="text-xs text-gray-500">Head of ESD, Sasol</p>
              </div>
              <div className="text-center">
                <p className="text-sm text-gray-600 mb-2 italic">
                  "Detail-oriented workshop with practical insights and gave participants a different viewpoint and approach."
                </p>
                <p className="font-semibold text-green-800">Natasha Mahlati</p>
                <p className="text-xs text-gray-500">Programme Manager, Duke CE</p>
              </div>
              <div className="text-center">
                <p className="text-sm text-gray-600 mb-2 italic">
                  "A practical workshop on financial modelling which we found useful. The facilitators were patient with explaining new concepts."
                </p>
                <p className="font-semibold text-green-800">Tshegofatso Mahuma</p>
                <p className="text-xs text-gray-500">CEO, MGIRAS</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      

      {/* Certification Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4" data-testid="certification-title">Earn Recognized Certificates</h2>
            <p className="text-lg text-gray-700 max-w-2xl mx-auto">Industry-recognized credentials to advance your career</p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <img
                src={dloGraduates}
                alt="DLO Energy graduates celebrating achievement"
                className="w-full rounded-xl shadow-lg"
                data-testid="img-certificate"
              />
            </div>
            <div>
              <h3 className="text-2xl font-bold mb-6">Digital Certificates You Can Trust</h3>
              <div className="space-y-4">
                <div className="flex items-start">
                  <CheckCircle className="text-gold w-6 h-6 mr-4 mt-1" />
                  <div>
                    <h4 className="font-semibold mb-1">Industry Recognition</h4>
                    <p className="text-gray-700">Certificates accepted by employers across Africa and globally</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <Shield className="text-gold w-6 h-6 mr-4 mt-1" />
                  <div>
                    <h4 className="font-semibold mb-1">Blockchain Verified</h4>
                    <p className="text-gray-700">Tamper-proof digital certificates with blockchain technology</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <LinkIcon className="text-gold w-6 h-6 mr-4 mt-1" />
                  <div>
                    <h4 className="font-semibold mb-1">Easy Sharing</h4>
                    <p className="text-gray-700">Share your achievements on LinkedIn, CV, or portfolio</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* DLO Services Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4" data-testid="services-title">Digital Learning Programmes</h2>
            <p className="text-lg text-gray-700 max-w-3xl mx-auto">
              Our proven workshop expertise now delivered through intelligent mobile learning - same expert content, enhanced with smart technology for better education
            </p>
          </div>

          {/* Real DLO Success Stories */}
          <div className="mb-12">
            <img
              src={dloSuccessStory}
              alt="DLO Energy success stories - proud graduates"
              style={{maxHeight: '400px', objectFit: 'cover'}}
              className="w-full rounded-xl shadow-lg"
            />
          </div>

          <div className="grid md:grid-cols-1 gap-6 mb-12">
            <Card className="text-center p-8 bg-white shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="flex flex-col">
                <div className="w-20 h-20 bg-gradient-to-r from-green-100 to-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <span className="text-3xl">🎓</span>
                </div>
                <h3 className="text-2xl font-bold mb-4 text-green-800">Complete Learning Experience</h3>
                <p className="text-gray-600 mb-6 text-lg">
                  Interactive mobile courses combining solar technology, renewable energy systems, and green entrepreneurship - all enhanced with intelligent AI learning support and personalized guidance
                </p>
                <div className="flex justify-center gap-4">
                  <Button 
                    size="lg"
                    className="btn-gold px-8 py-3 text-lg font-semibold"
                    onClick={handleAuthRedirect}
                  >
                    Start Learning Now
                  </Button>
                  <Button 
                    variant="outline" 
                    size="lg"
                    className="border-green-600 text-green-600 hover:bg-green-50 px-8 py-3 text-lg font-semibold"
                    onClick={() => scrollToSection('courses')}
                  >
                    Preview Course
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Digital Learning CTA */}
          <div className="bg-gradient-to-r from-green-600 to-blue-600 text-white p-8 rounded-xl text-center">
            <h3 className="text-2xl font-bold mb-4">Access Our Digital Classroom</h3>
            <h4 className="text-xl mb-4">Just Energy Transition 101: Enhanced Mobile Learning</h4>
            <p className="mb-6 max-w-4xl mx-auto">
              Transform your career with Africa's most innovative energy education app. Our proven Just Energy Transition curriculum, 
              previously delivered through acclaimed workshops, is now available as an intelligent, interactive mobile experience with enhanced learning support.
            </p>
            <div className="grid md:grid-cols-2 gap-4 max-w-4xl mx-auto mb-6 text-left">
              <ul className="space-y-2">
                <li className="flex items-start">
                  <CheckCircle className="text-green-300 w-5 h-5 mr-2 mt-0.5" />
                  <span>What is the Just Energy Transition</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="text-green-300 w-5 h-5 mr-2 mt-0.5" />
                  <span>South Africa's decarbonization strategy</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="text-green-300 w-5 h-5 mr-2 mt-0.5" />
                  <span>Technical introduction to renewable energy projects</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="text-green-300 w-5 h-5 mr-2 mt-0.5" />
                  <span>Legal and commercial structuring of projects</span>
                </li>
              </ul>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <CheckCircle className="text-green-300 w-5 h-5 mr-2 mt-0.5" />
                  <span>Deep dive into the solar industry value chain</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="text-green-300 w-5 h-5 mr-2 mt-0.5" />
                  <span>How to access tender opportunities</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="text-green-300 w-5 h-5 mr-2 mt-0.5" />
                  <span>How to fund your solar startup</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="text-green-300 w-5 h-5 mr-2 mt-0.5" />
                  <span>Deep dive into funding solutions</span>
                </li>
              </ul>
            </div>
            <Button
              size="lg"
              className="bg-white text-green-600 hover:bg-gray-100 px-8 py-3 text-lg font-semibold"
              onClick={handleAuthRedirect}
              data-testid="button-register-workshop"
            >
              Access Digital Platform
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <span className="text-lg font-bold">DLO Skills Initiative</span>
              </div>
              <p className="text-gray-400 mb-4">Powering Africa's Future with Skills</p>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">Courses</h4>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-400 hover:text-gold transition-colors">Energy Transition</a></li>
                <li><a href="#" className="text-gray-400 hover:text-gold transition-colors">Digital Skills</a></li>
                <li><a href="#" className="text-gray-400 hover:text-gold transition-colors">Entrepreneurship</a></li>
                <li><a href="#" className="text-gray-400 hover:text-gold transition-colors">Certification</a></li>
              </ul>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">Support</h4>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-400 hover:text-gold transition-colors">Help Center</a></li>
                <li><a href="#" className="text-gray-400 hover:text-gold transition-colors">Contact Us</a></li>
                <li><a href="#" className="text-gray-400 hover:text-gold transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="text-gray-400 hover:text-gold transition-colors">Terms of Service</a></li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-8 pt-8 text-center">
            <p className="text-gray-400">&copy; 2025 DLO Skills Initiative. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}