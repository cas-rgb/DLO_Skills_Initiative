import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Polyfill for Node.js global variable in browser environment
if (typeof global === 'undefined') {
  (window as any).global = globalThis;
}

createRoot(document.getElementById("root")!).render(<App />);
