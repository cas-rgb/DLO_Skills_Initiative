import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Menu, X, User, LogOut, BarChart3, Sparkles } from "lucide-react";
import dloEnergyLogo from "@assets/cropped-ENERGY-SKILLS-LOGO-2-3-768x219_1756645623163.png";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface NavbarProps {
  onAuthClick?: () => void;
  onLogout?: () => void;
}

export default function Navbar({ onAuthClick, onLogout }: NavbarProps) {
  const { user, isAuthenticated } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => setIsMobileMenuOpen(!isMobileMenuOpen);

  return (
    <nav className="bg-white shadow-lg border-b-2 border-[hsl(43,74%,36%)] sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link href="/">
            <div className="flex items-center cursor-pointer gap-3" data-testid="link-logo">
              <img
                src={dloEnergyLogo}
                alt="DLO Energy Skills Initiative Logo"
                className="h-8 w-auto"
                data-testid="img-dlo-logo"
              />
              <span className="text-xl font-bold text-black">DLO Skills Initiative</span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <Link href="/" className="text-black hover:text-[hsl(43,74%,36%)] transition-colors font-medium" data-testid="link-home">
              Home
            </Link>
            {isAuthenticated && (
              <>
                <Link href="/dashboard" className="text-black hover:text-[hsl(43,74%,36%)] transition-colors font-medium" data-testid="link-dashboard">
                  Dashboard
                </Link>

                {((user as any)?.role === 'facilitator' || (user as any)?.role === 'admin') && (
                  <Link href="/ai-assistant" className="text-black hover:text-[hsl(43,74%,36%)] transition-colors font-medium flex items-center gap-1" data-testid="link-ai-assistant">
                    <Sparkles className="w-4 h-4" />
                    AI Assistant
                  </Link>
                )}
              </>
            )}

            {isAuthenticated && user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" className="flex items-center space-x-2" data-testid="button-user-menu">
                    <User className="w-4 h-4" />
                    <span>{(user as any)?.firstName || 'User'}</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem asChild>
                    <Link href="/dashboard">
                      <div className="flex items-center cursor-pointer" data-testid="dropdown-dashboard">
                        <BarChart3 className="w-4 h-4 mr-2" />
                        Dashboard
                      </div>
                    </Link>
                  </DropdownMenuItem>
                  {((user as any)?.role === 'facilitator' || (user as any)?.role === 'admin') && (
                    <DropdownMenuItem asChild>
                      <Link href="/ai-assistant">
                        <div className="flex items-center cursor-pointer" data-testid="dropdown-ai-assistant">
                          <Sparkles className="w-4 h-4 mr-2" />
                          AI Assistant
                        </div>
                      </Link>
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={onLogout} data-testid="dropdown-logout">
                    <LogOut className="w-4 h-4 mr-2" />
                    Logout
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Button
                onClick={onAuthClick}
                className="btn-gold font-medium"
                data-testid="button-login"
              >
                Login / Register
              </Button>
            )}
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <Button variant="ghost" onClick={toggleMobileMenu} data-testid="button-mobile-menu">
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-white border-t border-gray-200" data-testid="mobile-menu">
          <div className="px-4 py-2 space-y-2">
            <Link href="/" className="block py-2 text-black hover:text-[hsl(43,74%,36%)]" data-testid="mobile-link-home">
              Home
            </Link>
            {isAuthenticated && (
              <>
                <Link href="/dashboard" className="block py-2 text-black hover:text-[hsl(43,74%,36%)]" data-testid="mobile-link-dashboard">
                  Dashboard
                </Link>

                {((user as any)?.role === 'facilitator' || (user as any)?.role === 'admin') && (
                  <Link href="/ai-assistant" className="block py-2 text-black hover:text-[hsl(43,74%,36%)] flex items-center gap-1" data-testid="mobile-link-ai-assistant">
                    <Sparkles className="w-4 h-4" />
                    AI Assistant
                  </Link>
                )}
              </>
            )}
            {isAuthenticated && user ? (
              <Button
                variant="ghost"
                onClick={onLogout}
                className="w-full text-left justify-start py-2 text-[hsl(43,74%,36%)] font-medium"
                data-testid="mobile-button-logout"
              >
                Logout
              </Button>
            ) : (
              <Button
                onClick={onAuthClick}
                className="w-full text-left py-2 text-[hsl(43,74%,36%)] font-medium"
                variant="ghost"
                data-testid="mobile-button-login"
              >
                Login / Register
              </Button>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}