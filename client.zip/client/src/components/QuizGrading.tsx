import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { CheckCircle, Clock, User, FileText, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { QuizAttempt } from "@shared/schema";

interface AttemptDetails extends QuizAttempt {
  responses: any[];
  quiz: any;
  questions: any[];
  user?: any;
}

export default function QuizGrading() {
  const [selectedAttempt, setSelectedAttempt] = useState<string | null>(null);
  const [feedback, setFeedback] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch attempts to grade
  const { data: attempts = [], isLoading } = useQuery<QuizAttempt[]>({
    queryKey: ["/api/grading/attempts"],
  });

  // Fetch attempt details
  const { data: attemptDetails } = useQuery<AttemptDetails>({
    queryKey: ["/api/quiz-attempts", selectedAttempt, "details"],
    enabled: !!selectedAttempt,
  });

  // Grade attempt mutation
  const gradeAttemptMutation = useMutation({
    mutationFn: ({ attemptId, feedback }: { attemptId: string; feedback: string }) =>
      apiRequest(`/api/quiz-attempts/${attemptId}/grade`, {
        method: "POST",
        body: JSON.stringify({ feedback }),
      }),
    onSuccess: () => {
      toast({
        title: "Quiz graded successfully",
        description: "The student has been notified of their grade.",
      });
      setSelectedAttempt(null);
      setFeedback("");
      queryClient.invalidateQueries({ queryKey: ["/api/grading/attempts"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to grade quiz. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleGradeAttempt = () => {
    if (!selectedAttempt) return;
    gradeAttemptMutation.mutate({ attemptId: selectedAttempt, feedback });
  };

  const formatDuration = (seconds: number) => {
    if (!seconds) return "N/A";
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}m ${remainingSeconds}s`;
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Quiz Grading</h2>
          <p className="text-gray-600 mt-1">Review and grade student quiz submissions</p>
        </div>
        <Badge variant="secondary" className="px-3 py-1">
          {attempts.length} pending
        </Badge>
      </div>

      {/* Attempts List */}
      <div className="space-y-4">
        {isLoading ? (
          <div className="text-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-yellow-600 mx-auto"></div>
            <p className="mt-2 text-gray-600">Loading submissions...</p>
          </div>
        ) : attempts.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-gray-400 mb-4">
              <CheckCircle className="w-16 h-16 mx-auto" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">All caught up!</h3>
            <p className="text-gray-600">No quiz submissions waiting for grading.</p>
          </div>
        ) : (
          attempts.map((attempt) => (
            <Card key={attempt.id} className="hover:shadow-md transition-shadow" data-testid={`card-attempt-${attempt.id}`}>
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <CardTitle className="text-lg" data-testid={`text-quiz-title-${attempt.id}`}>
                      Quiz Submission
                    </CardTitle>
                    <CardDescription className="mt-1">
                      Submitted {new Date(attempt.submittedAt!).toLocaleDateString()}
                    </CardDescription>
                  </div>
                  <Badge 
                    variant={attempt.isPassed ? "default" : "destructive"}
                    data-testid={`badge-attempt-status-${attempt.id}`}
                  >
                    {attempt.score}% {attempt.isPassed ? "Passed" : "Failed"}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                  <div className="flex items-center gap-2">
                    <User className="w-4 h-4 text-gray-500" />
                    <span data-testid={`text-student-${attempt.id}`}>Student #{attempt.userId}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-gray-500" />
                    <span data-testid={`text-duration-${attempt.id}`}>
                      {formatDuration(attempt.timeSpent || 0)}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Star className="w-4 h-4 text-gray-500" />
                    <span data-testid={`text-points-${attempt.id}`}>
                      {attempt.earnedPoints}/{attempt.totalPoints} points
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <FileText className="w-4 h-4 text-gray-500" />
                    <span>Attempt #{attempt.attemptNumber}</span>
                  </div>
                </div>

                <div className="flex justify-end">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button
                        variant="outline"
                        onClick={() => {
                          setSelectedAttempt(attempt.id);
                          setFeedback("");
                        }}
                        data-testid={`button-review-${attempt.id}`}
                      >
                        Review & Grade
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                      <DialogHeader>
                        <DialogTitle>Grade Quiz Submission</DialogTitle>
                      </DialogHeader>
                      
                      {attemptDetails && (
                        <div className="space-y-6">
                          {/* Quiz Info */}
                          <Card>
                            <CardHeader>
                              <CardTitle>Quiz Information</CardTitle>
                            </CardHeader>
                            <CardContent>
                              <div className="grid grid-cols-2 gap-4 text-sm">
                                <div>
                                  <span className="font-medium">Quiz:</span> {attemptDetails.quiz?.title}
                                </div>
                                <div>
                                  <span className="font-medium">Student:</span> #{attemptDetails.userId}
                                </div>
                                <div>
                                  <span className="font-medium">Score:</span> {attemptDetails.score}%
                                </div>
                                <div>
                                  <span className="font-medium">Time Spent:</span> {formatDuration(attemptDetails.timeSpent || 0)}
                                </div>
                              </div>
                            </CardContent>
                          </Card>

                          {/* Responses */}
                          <Card>
                            <CardHeader>
                              <CardTitle>Student Responses</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-4">
                              {attemptDetails.questions?.map((question, index) => {
                                const response = attemptDetails.responses?.find(r => r.questionId === question.id);
                                return (
                                  <div key={question.id} className="border-l-4 border-l-gray-200 pl-4" data-testid={`response-${question.id}`}>
                                    <h4 className="font-medium mb-2">Question {index + 1}</h4>
                                    <p className="text-gray-700 mb-2">{question.question}</p>
                                    
                                    {question.type === "multiple_choice" && (
                                      <div className="space-y-1">
                                        <p><span className="font-medium">Student Answer:</span> {response?.response || "No answer"}</p>
                                        <p><span className="font-medium">Correct Answer:</span> {question.correctAnswer}</p>
                                        <Badge variant={response?.isCorrect ? "default" : "destructive"}>
                                          {response?.isCorrect ? "Correct" : "Incorrect"}
                                        </Badge>
                                      </div>
                                    )}
                                    
                                    {(question.type === "short_answer" || question.type === "essay") && (
                                      <div className="space-y-2">
                                        <div>
                                          <span className="font-medium">Student Answer:</span>
                                          <div className="bg-gray-50 p-2 rounded mt-1">
                                            {response?.response || "No answer provided"}
                                          </div>
                                        </div>
                                        {question.correctAnswer && (
                                          <div>
                                            <span className="font-medium">Expected Answer:</span>
                                            <div className="bg-blue-50 p-2 rounded mt-1">
                                              {question.correctAnswer}
                                            </div>
                                          </div>
                                        )}
                                        <div className="flex items-center gap-2">
                                          <span className="font-medium">Points:</span>
                                          <span>{response?.pointsEarned || 0} / {question.points}</span>
                                        </div>
                                      </div>
                                    )}
                                    
                                    {question.explanation && (
                                      <div className="mt-2">
                                        <span className="font-medium">Explanation:</span>
                                        <p className="text-gray-600 text-sm mt-1">{question.explanation}</p>
                                      </div>
                                    )}
                                  </div>
                                );
                              })}
                            </CardContent>
                          </Card>

                          {/* Feedback */}
                          <Card>
                            <CardHeader>
                              <CardTitle>Teacher Feedback</CardTitle>
                            </CardHeader>
                            <CardContent>
                              <Textarea
                                value={feedback}
                                onChange={(e) => setFeedback(e.target.value)}
                                placeholder="Provide feedback for the student..."
                                rows={4}
                                data-testid="textarea-feedback"
                              />
                            </CardContent>
                          </Card>

                          {/* Actions */}
                          <div className="flex justify-end gap-3">
                            <Button
                              variant="outline"
                              onClick={() => setSelectedAttempt(null)}
                              data-testid="button-cancel-grading"
                            >
                              Cancel
                            </Button>
                            <Button
                              onClick={handleGradeAttempt}
                              disabled={gradeAttemptMutation.isPending}
                              className="bg-yellow-600 hover:bg-yellow-700"
                              data-testid="button-submit-grade"
                            >
                              {gradeAttemptMutation.isPending ? "Grading..." : "Submit Grade"}
                            </Button>
                          </div>
                        </div>
                      )}
                    </DialogContent>
                  </Dialog>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}