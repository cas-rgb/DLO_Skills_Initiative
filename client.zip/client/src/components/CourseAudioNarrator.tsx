import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Volume2, VolumeX, Pause, Play, RotateCcw, Settings, Loader2, Download } from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface CourseAudioNarratorProps {
  text: string;
  moduleId?: string;
  sectionId?: string;
  sectionType?: "introduction" | "content" | "conclusion" | "quiz" | "explanation";
  autoPlay?: boolean;
  showControls?: boolean;
  className?: string;
  voiceType?: "male" | "female";
  onStart?: () => void;
  onEnd?: () => void;
  onError?: (error: string) => void;
}

export function CourseAudioNarrator({
  text,
  moduleId,
  sectionId,
  sectionType = "content",
  autoPlay = false,
  showControls = true,
  className,
  voiceType = "female",
  onStart,
  onEnd,
  onError,
}: CourseAudioNarratorProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [audioData, setAudioData] = useState<string | null>(null);
  const [audioDuration, setAudioDuration] = useState<number>(0);
  const [progress, setProgress] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [showSettings, setShowSettings] = useState(false);
  const [speed, setSpeed] = useState([1]);
  const [volume, setVolume] = useState([0.8]);
  
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const progressIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    if (autoPlay && text && !audioData) {
      generateAudio();
    }
  }, [autoPlay, text]);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.playbackRate = speed[0];
      audioRef.current.volume = volume[0];
    }
  }, [speed, volume]);

  const generateAudio = async () => {
    if (!text && !moduleId) return;

    setIsGenerating(true);
    try {
      // First, try to fetch pre-generated audio for the module
      if (moduleId) {
        try {
          const narrationData = await apiRequest(`/api/narration/module/${moduleId}`, "GET");
          
          if (narrationData && narrationData.audioFilePath) {
            // Pre-generated audio exists, use it
            setAudioData(narrationData.audioFilePath);
            setIsGenerating(false);
            
            // Create audio element and set it up
            const audio = new Audio(narrationData.audioFilePath);
            audioRef.current = audio;
            
            audio.addEventListener('loadedmetadata', () => {
              setAudioDuration(audio.duration);
            });
            
            audio.addEventListener('ended', () => {
              setIsPlaying(false);
              setProgress(0);
              onEnd?.();
            });
            
            if (autoPlay) {
              audio.play();
              setIsPlaying(true);
              onStart?.();
            }
            
            return;
          }
        } catch (fetchError) {
          console.log("No pre-generated audio found, generating new audio...");
        }
      }

      // If no pre-generated audio, generate new audio
      const options = {
        voiceType,
        speed: 0.9, // Optimal for educational content
        sectionType,
        useSSML: true
      };

      const response = await apiRequest(`/api/ai/course-narration`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ text, options }),
      });

      if (response.success && response.audioData) {
        const audioBlob = new Blob([
          Uint8Array.from(atob(response.audioData), c => c.charCodeAt(0))
        ], { type: 'audio/mpeg' });
        
        const audioUrl = URL.createObjectURL(audioBlob);
        setAudioData(audioUrl);
        setAudioDuration(response.duration || 0);

        // Create audio element
        if (audioRef.current) {
          audioRef.current.src = audioUrl;
          audioRef.current.load();
        }

        toast({
          title: "Audio Generated",
          description: "Course narration is ready to play",
        });

        // Auto-play the audio after generation
        setTimeout(() => playAudio(), 500);
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Failed to generate audio";
      onError?.(errorMessage);
      toast({
        title: "Audio Generation Failed",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleListenClick = async () => {
    // If no audio data exists, generate it first, then play
    if (!audioData) {
      await generateAudio();
      // generateAudio will handle autoplay if successful
      return;
    }
    
    // If audio exists, just play it
    playAudio();
  };

  const playAudio = () => {
    if (!audioRef.current || !audioData) return;

    audioRef.current.play()
      .then(() => {
        setIsPlaying(true);
        setIsPaused(false);
        onStart?.();
        startProgressTracking();
      })
      .catch((error) => {
        console.error("Error playing audio:", error);
        toast({
          title: "Playback Error",
          description: "Failed to play audio",
          variant: "destructive",
        });
      });
  };

  const pauseAudio = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      setIsPaused(true);
      stopProgressTracking();
    }
  };

  const resumeAudio = () => {
    if (audioRef.current) {
      audioRef.current.play();
      setIsPaused(false);
      startProgressTracking();
    }
  };

  const stopAudio = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
      setIsPlaying(false);
      setIsPaused(false);
      setProgress(0);
      setCurrentTime(0);
      stopProgressTracking();
      onEnd?.();
    }
  };

  const startProgressTracking = () => {
    progressIntervalRef.current = setInterval(() => {
      if (audioRef.current) {
        const current = audioRef.current.currentTime;
        const duration = audioRef.current.duration;
        setCurrentTime(current);
        setProgress(duration > 0 ? (current / duration) * 100 : 0);
      }
    }, 100);
  };

  const stopProgressTracking = () => {
    if (progressIntervalRef.current) {
      clearInterval(progressIntervalRef.current);
      progressIntervalRef.current = null;
    }
  };

  const handleAudioEnded = () => {
    setIsPlaying(false);
    setIsPaused(false);
    setProgress(100);
    stopProgressTracking();
    onEnd?.();
  };

  const downloadAudio = () => {
    if (audioData) {
      const link = document.createElement('a');
      link.href = audioData;
      link.download = `course-audio-${sectionId || 'section'}.mp3`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  if (!text) {
    return (
      <Card className={cn("border-muted", className)}>
        <CardContent className="p-4 text-center">
          <Volume2 className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
          <p className="text-sm text-muted-foreground">
            No content available for narration.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <audio
        ref={audioRef}
        onEnded={handleAudioEnded}
        onLoadedMetadata={() => {
          if (audioRef.current) {
            setAudioDuration(audioRef.current.duration);
          }
        }}
        preload="metadata"
      />
      
      <Card className={cn("border-2", isPlaying ? "border-[hsl(43,74%,36%)]" : "border-gray-200", className)}>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2">
              <Volume2 className="h-4 w-4 text-[hsl(43,74%,36%)]" />
              AI Course Narrator
              {isPlaying && (
                <Badge variant="secondary" className="bg-green-100 text-green-800">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse mr-1" />
                  Playing
                </Badge>
              )}
              {isGenerating && (
                <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                  <Loader2 className="w-3 h-3 animate-spin mr-1" />
                  Generating
                </Badge>
              )}
            </div>
            {showControls && (
              <div className="flex items-center gap-1">
                {audioData && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={downloadAudio}
                    data-testid="button-download-audio"
                  >
                    <Download className="h-4 w-4" />
                  </Button>
                )}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowSettings(!showSettings)}
                  data-testid="button-toggle-settings"
                >
                  <Settings className="h-4 w-4" />
                </Button>
              </div>
            )}
          </CardTitle>
        </CardHeader>

        <CardContent className="space-y-4">
          {showControls && (
            <div className="flex items-center gap-2">
              <Button
                onClick={isGenerating ? undefined : (isPlaying ? (isPaused ? resumeAudio : pauseAudio) : handleListenClick)}
                disabled={isGenerating}
                variant="default"
                size="sm"
                className="bg-[hsl(43,74%,36%)] hover:bg-[hsl(43,74%,30%)] text-white"
                data-testid="button-listen"
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Generating...
                  </>
                ) : isPlaying ? (
                  isPaused ? (
                    <>
                      <Play className="h-4 w-4 mr-2" />
                      Resume
                    </>
                  ) : (
                    <>
                      <Pause className="h-4 w-4 mr-2" />
                      Pause
                    </>
                  )
                ) : (
                  <>
                    <Volume2 className="h-4 w-4 mr-2" />
                    Listen
                  </>
                )}
              </Button>

              {isPlaying && (
                <Button
                  onClick={stopAudio}
                  variant="outline"
                  size="sm"
                  data-testid="button-stop"
                >
                  <RotateCcw className="h-4 w-4 mr-2" />
                  Stop
                </Button>
              )}

              {(audioData || isPlaying) && (
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <span>{formatTime(currentTime)} / {formatTime(audioDuration)}</span>
                  <div className="w-24 h-1 bg-gray-200 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-[hsl(43,74%,36%)] transition-all duration-300"
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                </div>
              )}
            </div>
          )}

          {showSettings && audioData && (
            <div className="space-y-4 p-4 bg-gray-50 rounded border">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Voice Type</label>
                  <Select value={voiceType} disabled>
                    <SelectTrigger className="w-full">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="female">Female Voice</SelectItem>
                      <SelectItem value="male">Male Voice</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground mt-1">
                    Voice type is set when generating audio
                  </p>
                </div>

                <div>
                  <label className="text-sm font-medium mb-2 block">Speed: {speed[0].toFixed(1)}x</label>
                  <Slider
                    value={speed}
                    onValueChange={setSpeed}
                    min={0.5}
                    max={2}
                    step={0.1}
                    className="w-full"
                  />
                </div>

                <div>
                  <label className="text-sm font-medium mb-2 block">Volume: {Math.round(volume[0] * 100)}%</label>
                  <Slider
                    value={volume}
                    onValueChange={setVolume}
                    min={0}
                    max={1}
                    step={0.1}
                    className="w-full"
                  />
                </div>

                <div>
                  <label className="text-sm font-medium mb-2 block">Section Type</label>
                  <Badge variant="outline" className="text-xs">
                    {sectionType.charAt(0).toUpperCase() + sectionType.slice(1)}
                  </Badge>
                  <p className="text-xs text-muted-foreground mt-1">
                    Optimized voice settings for {sectionType} content
                  </p>
                </div>
              </div>
            </div>
          )}

          <div className="text-sm text-gray-600 bg-gray-50 p-3 rounded border max-h-32 overflow-y-auto">
            <p className="font-medium mb-1">Content Preview:</p>
            {text.split(' ').slice(0, 30).join(' ')}
            {text.split(' ').length > 30 && '...'}
          </div>
        </CardContent>
      </Card>
    </>
  );
}