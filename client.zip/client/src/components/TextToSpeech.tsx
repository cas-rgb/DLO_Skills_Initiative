import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Volume2, VolumeX, Pause, Play, RotateCcw, Settings } from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

interface TextToSpeechProps {
  text: string;
  autoPlay?: boolean;
  showControls?: boolean;
  className?: string;
  voiceType?: "male" | "female" | "auto";
  onStart?: () => void;
  onEnd?: () => void;
  onError?: (error: string) => void;
}

export function TextToSpeech({
  text,
  autoPlay = false,
  showControls = true,
  className,
  voiceType = "female",
  onStart,
  onEnd,
  onError,
}: TextToSpeechProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [isSupported, setIsSupported] = useState(false);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [selectedVoice, setSelectedVoice] = useState<SpeechSynthesisVoice | null>(null);
  const [rate, setRate] = useState([1]);
  const [pitch, setPitch] = useState([1]);
  const [volume, setVolume] = useState([0.8]);
  const [progress, setProgress] = useState(0);
  const [showSettings, setShowSettings] = useState(false);
  
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      setIsSupported(true);
      
      const loadVoices = () => {
        const availableVoices = window.speechSynthesis.getVoices();
        setVoices(availableVoices);
        
        // Auto-select best voice based on preference
        if (availableVoices.length > 0 && !selectedVoice) {
          let preferredVoice;
          
          if (voiceType === "female") {
            preferredVoice = availableVoices.find(voice => 
              voice.name.toLowerCase().includes("female") ||
              voice.name.toLowerCase().includes("zira") ||
              voice.name.toLowerCase().includes("samantha") ||
              voice.name.toLowerCase().includes("karen")
            );
          } else if (voiceType === "male") {
            preferredVoice = availableVoices.find(voice => 
              voice.name.toLowerCase().includes("male") ||
              voice.name.toLowerCase().includes("david") ||
              voice.name.toLowerCase().includes("mark")
            );
          }
          
          // Fallback to first English voice or first available voice
          if (!preferredVoice) {
            preferredVoice = availableVoices.find(voice => voice.lang.startsWith("en")) || availableVoices[0];
          }
          
          setSelectedVoice(preferredVoice);
        }
      };

      loadVoices();
      window.speechSynthesis.onvoiceschanged = loadVoices;
    }
  }, [voiceType, selectedVoice]);

  useEffect(() => {
    if (autoPlay && text && isSupported) {
      speak();
    }
  }, [autoPlay, text, isSupported]);

  const speak = () => {
    if (!text || !isSupported) return;

    // Stop any ongoing speech
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utteranceRef.current = utterance;

    if (selectedVoice) {
      utterance.voice = selectedVoice;
    }
    
    utterance.rate = rate[0];
    utterance.pitch = pitch[0];
    utterance.volume = volume[0];

    utterance.onstart = () => {
      setIsPlaying(true);
      setIsPaused(false);
      onStart?.();
    };

    utterance.onend = () => {
      setIsPlaying(false);
      setIsPaused(false);
      setProgress(0);
      onEnd?.();
    };

    utterance.onerror = (event) => {
      const errorMessage = `Speech synthesis error: ${event.error}`;
      setIsPlaying(false);
      setIsPaused(false);
      onError?.(errorMessage);
      toast({
        title: "Speech Error",
        description: errorMessage,
        variant: "destructive",
      });
    };

    utterance.onboundary = (event) => {
      if (event.name === "word") {
        const wordsSpoken = text.substring(0, event.charIndex).split(' ').length;
        const totalWords = text.split(' ').length;
        setProgress((wordsSpoken / totalWords) * 100);
      }
    };

    window.speechSynthesis.speak(utterance);
  };

  const pause = () => {
    if (window.speechSynthesis.speaking && !window.speechSynthesis.paused) {
      window.speechSynthesis.pause();
      setIsPaused(true);
    }
  };

  const resume = () => {
    if (window.speechSynthesis.paused) {
      window.speechSynthesis.resume();
      setIsPaused(false);
    }
  };

  const stop = () => {
    window.speechSynthesis.cancel();
    setIsPlaying(false);
    setIsPaused(false);
    setProgress(0);
  };

  if (!isSupported) {
    return (
      <Card className={cn("border-destructive", className)}>
        <CardContent className="p-4 text-center">
          <VolumeX className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
          <p className="text-sm text-muted-foreground">
            Text-to-speech is not supported in your browser.
          </p>
        </CardContent>
      </Card>
    );
  }

  if (!text) {
    return (
      <Card className={cn("border-muted", className)}>
        <CardContent className="p-4 text-center">
          <Volume2 className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
          <p className="text-sm text-muted-foreground">
            No text provided for speech synthesis.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={cn("border-2", isPlaying ? "border-[hsl(43,74%,36%)]" : "border-gray-200", className)}>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center justify-between text-sm">
          <div className="flex items-center gap-2">
            <Volume2 className="h-4 w-4 text-[hsl(43,74%,36%)]" />
            AI Narration
            {isPlaying && (
              <Badge variant="secondary" className="bg-green-100 text-green-800">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse mr-1" />
                Playing
              </Badge>
            )}
          </div>
          {showControls && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowSettings(!showSettings)}
              data-testid="button-toggle-settings"
            >
              <Settings className="h-4 w-4" />
            </Button>
          )}
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-4">
        {showControls && (
          <div className="flex items-center gap-2">
            <Button
              onClick={isPlaying ? (isPaused ? resume : pause) : speak}
              variant="default"
              size="sm"
              className="bg-[hsl(43,74%,36%)] hover:bg-[hsl(43,74%,30%)] text-white"
              data-testid="button-play-pause"
            >
              {isPlaying ? (
                isPaused ? (
                  <>
                    <Play className="h-4 w-4 mr-2" />
                    Resume
                  </>
                ) : (
                  <>
                    <Pause className="h-4 w-4 mr-2" />
                    Pause
                  </>
                )
              ) : (
                <>
                  <Volume2 className="h-4 w-4 mr-2" />
                  Listen
                </>
              )}
            </Button>

            {isPlaying && (
              <Button
                onClick={stop}
                variant="outline"
                size="sm"
                data-testid="button-stop"
              >
                <RotateCcw className="h-4 w-4 mr-2" />
                Stop
              </Button>
            )}

            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <span>{Math.round(progress)}%</span>
              <div className="w-20 h-1 bg-gray-200 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-[hsl(43,74%,36%)] transition-all duration-300"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          </div>
        )}

        {showSettings && (
          <div className="space-y-4 p-4 bg-gray-50 rounded border">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Voice</label>
                <Select
                  value={selectedVoice?.name || ""}
                  onValueChange={(value) => {
                    const voice = voices.find(v => v.name === value);
                    setSelectedVoice(voice || null);
                  }}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select voice..." />
                  </SelectTrigger>
                  <SelectContent>
                    {voices.map((voice) => (
                      <SelectItem key={voice.name} value={voice.name}>
                        {voice.name} ({voice.lang})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Speed: {rate[0].toFixed(1)}x</label>
                <Slider
                  value={rate}
                  onValueChange={setRate}
                  min={0.5}
                  max={2}
                  step={0.1}
                  className="w-full"
                />
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Pitch: {pitch[0].toFixed(1)}</label>
                <Slider
                  value={pitch}
                  onValueChange={setPitch}
                  min={0.5}
                  max={2}
                  step={0.1}
                  className="w-full"
                />
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Volume: {Math.round(volume[0] * 100)}%</label>
                <Slider
                  value={volume}
                  onValueChange={setVolume}
                  min={0}
                  max={1}
                  step={0.1}
                  className="w-full"
                />
              </div>
            </div>
          </div>
        )}

        <div className="text-sm text-gray-600 bg-gray-50 p-3 rounded border max-h-32 overflow-y-auto">
          {text.split(' ').slice(0, 50).join(' ')}
          {text.split(' ').length > 50 && '...'}
        </div>
      </CardContent>
    </Card>
  );
}