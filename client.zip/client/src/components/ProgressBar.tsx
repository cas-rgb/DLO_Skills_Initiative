import { cn } from "@/lib/utils";

interface ProgressBarProps {
  value: number; // 0-100
  className?: string;
  showLabel?: boolean;
}

export default function ProgressBar({ value, className, showLabel = false }: ProgressBarProps) {
  const clampedValue = Math.max(0, Math.min(100, value));
  
  return (
    <div className={cn("w-full", className)} data-testid="progress-bar">
      <div className="w-full bg-gray-200 rounded-full h-2">
        <div 
          className="bg-[hsl(43,74%,36%)] h-2 rounded-full transition-all duration-300 ease-in-out"
          style={{ width: `${clampedValue}%` }}
          data-testid="progress-bar-fill"
        />
      </div>
      {showLabel && (
        <p className="text-sm text-gray-600 mt-1" data-testid="progress-bar-label">
          {Math.round(clampedValue)}% Complete
        </p>
      )}
    </div>
  );
}
