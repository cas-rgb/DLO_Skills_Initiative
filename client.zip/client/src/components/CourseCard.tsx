import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Star, Clock, Users } from "lucide-react";
import { Link } from "wouter";

interface Course {
  id: string;
  title: string;
  description: string;
  category: string;
  price: string;
  duration: number;
  level: string;
  thumbnailUrl?: string;
  enrollmentCount: number;
  rating: string;
  ratingCount: number;
}

interface CourseCardProps {
  course: Course;
}

export default function CourseCard({ course }: CourseCardProps) {
  const getCategoryBadgeColor = (category: string) => {
    switch (category) {
      case 'energy_transition':
        return 'bg-green-100 text-green-800';
      case 'digital_skills':
        return 'bg-blue-100 text-blue-800';
      case 'entrepreneurship':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getCategoryLabel = (category: string) => {
    switch (category) {
      case 'energy_transition':
        return 'Energy Transition';
      case 'digital_skills':
        return 'Digital Skills';
      case 'entrepreneurship':
        return 'Entrepreneurship';
      default:
        return 'Other';
    }
  };

  const getDefaultImage = (category: string) => {
    switch (category) {
      case 'energy_transition':
        return 'https://images.unsplash.com/photo-1573164713714-d95e436ab8d6?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250';
      case 'digital_skills':
        return 'https://images.unsplash.com/photo-1491975474562-1f4e30bc9468?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250';
      case 'entrepreneurship':
        return 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250';
      default:
        return 'https://images.unsplash.com/photo-1573164713714-d95e436ab8d6?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250';
    }
  };

  return (
    <Card className="overflow-hidden border border-gray-200 hover:shadow-xl transition-shadow card-hover">
      <img 
        src={course.thumbnailUrl || getDefaultImage(course.category)} 
        alt={course.title}
        className="w-full h-48 object-cover"
        data-testid={`img-course-${course.id}`}
      />
      <CardContent className="p-6">
        <div className="flex items-center mb-3">
          <Badge 
            className={getCategoryBadgeColor(course.category)}
            data-testid={`badge-category-${course.id}`}
          >
            {getCategoryLabel(course.category)}
          </Badge>
        </div>
        
        <h3 className="text-xl font-bold mb-3" data-testid={`text-course-title-${course.id}`}>
          {course.title}
        </h3>
        
        <p className="text-gray-700 mb-4" data-testid={`text-course-description-${course.id}`}>
          {course.description?.substring(0, 100)}...
        </p>
        
        <div className="flex items-center justify-between mb-4">
          <span className="text-[hsl(43,74%,36%)] font-bold text-lg" data-testid={`text-course-price-${course.id}`}>
            {course.price === '0' ? 'FREE' : `$${course.price}`}
          </span>
          <div className="flex items-center">
            <Star className="text-[hsl(43,74%,36%)] w-4 h-4 mr-1" />
            <span className="text-sm" data-testid={`text-course-rating-${course.id}`}>
              {course.rating && parseFloat(course.rating) > 0 
                ? `${parseFloat(course.rating).toFixed(1)} (${course.ratingCount})`
                : 'No ratings'
              }
            </span>
          </div>
        </div>
        
        <div className="flex items-center justify-between mb-4 text-sm text-gray-500">
          <div className="flex items-center">
            <Clock className="w-4 h-4 mr-1" />
            <span data-testid={`text-course-duration-${course.id}`}>{course.duration}h</span>
          </div>
          <div className="flex items-center">
            <Users className="w-4 h-4 mr-1" />
            <span data-testid={`text-course-students-${course.id}`}>{course.enrollmentCount} students</span>
          </div>
        </div>
        
        <Link href={`/course/${course.id}`}>
          <Button className="w-full bg-black text-white hover:bg-gray-800 transition-colors" data-testid={`button-view-course-${course.id}`}>
            View Course
          </Button>
        </Link>
      </CardContent>
    </Card>
  );
}
