import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Mic, MicOff, Square, Play, RotateCcw } from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

interface SpeechToTextProps {
  onTranscript?: (transcript: string) => void;
  onFinalTranscript?: (transcript: string) => void;
  autoStart?: boolean;
  continuous?: boolean;
  className?: string;
  placeholder?: string;
  language?: string;
}

export function SpeechToText({
  onTranscript,
  onFinalTranscript,
  autoStart = false,
  continuous = true,
  className,
  placeholder = "Click the microphone to start speaking...",
  language = "en-US",
}: SpeechToTextProps) {
  const [isListening, setIsListening] = useState(false);
  const [isSupported, setIsSupported] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [interimTranscript, setInterimTranscript] = useState("");
  const [error, setError] = useState<string | null>(null);
  
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    // Check for speech recognition support
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    
    if (SpeechRecognition) {
      setIsSupported(true);
      
      const recognition = new SpeechRecognition();
      recognition.continuous = continuous;
      recognition.interimResults = true;
      recognition.lang = language;
      recognition.maxAlternatives = 1;

      recognition.onstart = () => {
        setIsListening(true);
        setError(null);
      };

      recognition.onresult = (event) => {
        let finalTranscript = "";
        let interimTranscript = "";

        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcript = event.results[i][0].transcript;
          
          if (event.results[i].isFinal) {
            finalTranscript += transcript;
          } else {
            interimTranscript += transcript;
          }
        }

        if (finalTranscript) {
          setTranscript(prev => prev + finalTranscript);
          onTranscript?.(transcript + finalTranscript);
          onFinalTranscript?.(finalTranscript);
        }

        setInterimTranscript(interimTranscript);
      };

      recognition.onerror = (event) => {
        console.error("Speech recognition error:", event.error);
        
        let errorMessage = "Speech recognition error occurred";
        switch (event.error) {
          case 'no-speech':
            errorMessage = "No speech detected. Please try speaking again.";
            break;
          case 'audio-capture':
            errorMessage = "Microphone access denied or not available.";
            break;
          case 'not-allowed':
            errorMessage = "Microphone permission denied. Please allow microphone access.";
            break;
          case 'network':
            errorMessage = "Network error occurred during speech recognition.";
            break;
          case 'service-not-allowed':
            errorMessage = "Speech recognition service not available.";
            break;
          default:
            errorMessage = `Speech recognition error: ${event.error}`;
        }
        
        setError(errorMessage);
        setIsListening(false);
        
        toast({
          title: "Speech Recognition Error",
          description: errorMessage,
          variant: "destructive",
        });
      };

      recognition.onend = () => {
        setIsListening(false);
        setInterimTranscript("");
      };

      recognitionRef.current = recognition;

      if (autoStart) {
        startListening();
      }
    } else {
      setError("Speech recognition is not supported in this browser.");
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, [autoStart, continuous, language]);

  const startListening = () => {
    if (!recognitionRef.current || isListening) return;

    try {
      recognitionRef.current.start();
    } catch (error) {
      console.error("Error starting speech recognition:", error);
      toast({
        title: "Microphone Error",
        description: "Failed to start speech recognition. Please check your microphone permissions.",
        variant: "destructive",
      });
    }
  };

  const stopListening = () => {
    if (!recognitionRef.current || !isListening) return;
    recognitionRef.current.stop();
  };

  const clearTranscript = () => {
    setTranscript("");
    setInterimTranscript("");
    setError(null);
  };

  const getDisplayText = () => {
    const baseText = transcript + interimTranscript;
    return baseText || placeholder;
  };

  if (!isSupported) {
    return (
      <Card className={cn("border-destructive", className)}>
        <CardContent className="p-4 text-center">
          <MicOff className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
          <p className="text-sm text-muted-foreground">
            Speech recognition is not supported in your browser.
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            Try using Chrome, Edge, or Safari for the best experience.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={cn("border-2", isListening ? "border-red-400 shadow-lg" : "border-gray-200", className)}>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center justify-between text-sm">
          <div className="flex items-center gap-2">
            <Mic className="h-4 w-4 text-blue-600" />
            Speech to Text
            {isListening && (
              <Badge variant="secondary" className="bg-red-100 text-red-800">
                <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse mr-1" />
                Listening
              </Badge>
            )}
          </div>
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="sm"
              onClick={clearTranscript}
              disabled={!transcript && !interimTranscript}
              data-testid="button-clear-transcript"
            >
              <RotateCcw className="h-4 w-4" />
            </Button>
          </div>
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-4">
        <div className="flex items-center gap-2">
          <Button
            onClick={isListening ? stopListening : startListening}
            variant={isListening ? "destructive" : "default"}
            size="sm"
            className={isListening ? "" : "bg-blue-600 hover:bg-blue-700 text-white"}
            data-testid="button-toggle-listening"
          >
            {isListening ? (
              <>
                <Square className="h-4 w-4 mr-2" />
                Stop Listening
              </>
            ) : (
              <>
                <Mic className="h-4 w-4 mr-2" />
                Start Listening
              </>
            )}
          </Button>

          {transcript && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                navigator.clipboard.writeText(transcript);
                toast({
                  title: "Copied",
                  description: "Transcript copied to clipboard",
                });
              }}
              data-testid="button-copy-transcript"
            >
              Copy Text
            </Button>
          )}
        </div>

        <div className="space-y-2">
          <Textarea
            value={getDisplayText()}
            readOnly
            className={cn(
              "min-h-32 resize-none",
              isListening && "border-red-200 bg-red-50",
              interimTranscript && "text-gray-600 italic"
            )}
            placeholder={placeholder}
          />
          
          {error && (
            <div className="text-sm text-red-600 bg-red-50 p-2 rounded border border-red-200">
              {error}
            </div>
          )}

          {isListening && (
            <div className="text-xs text-blue-600 bg-blue-50 p-2 rounded border border-blue-200">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse" />
                Listening for speech... Speak clearly into your microphone.
              </div>
            </div>
          )}

          {transcript && (
            <div className="text-xs text-green-600 bg-green-50 p-2 rounded border border-green-200">
              <strong>Final transcript:</strong> {transcript.split(' ').length} words captured
            </div>
          )}
        </div>

        <div className="text-xs text-muted-foreground">
          <p>
            <strong>Language:</strong> {language} | 
            <strong> Status:</strong> {isListening ? "Listening" : "Ready"} |
            <strong> Words:</strong> {transcript.split(' ').filter(w => w.length > 0).length}
          </p>
          <p className="mt-1">
            Tips: Speak clearly, ensure your microphone is working, and allow browser permissions.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}

// Extend Window interface for TypeScript
declare global {
  interface Window {
    SpeechRecognition: typeof SpeechRecognition;
    webkitSpeechRecognition: typeof SpeechRecognition;
  }
}

interface SpeechRecognition extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  maxAlternatives: number;
  start(): void;
  stop(): void;
  onstart: ((this: SpeechRecognition, ev: Event) => any) | null;
  onresult: ((this: SpeechRecognition, ev: SpeechRecognitionEvent) => any) | null;
  onerror: ((this: SpeechRecognition, ev: SpeechRecognitionErrorEvent) => any) | null;
  onend: ((this: SpeechRecognition, ev: Event) => any) | null;
}

interface SpeechRecognitionEvent extends Event {
  resultIndex: number;
  results: SpeechRecognitionResultList;
}

interface SpeechRecognitionErrorEvent extends Event {
  error: string;
  message: string;
}

interface SpeechRecognitionResultList {
  length: number;
  item(index: number): SpeechRecognitionResult;
  [index: number]: SpeechRecognitionResult;
}

interface SpeechRecognitionResult {
  length: number;
  item(index: number): SpeechRecognitionAlternative;
  [index: number]: SpeechRecognitionAlternative;
  isFinal: boolean;
}

interface SpeechRecognitionAlternative {
  transcript: string;
  confidence: number;
}

declare var SpeechRecognition: {
  prototype: SpeechRecognition;
  new(): SpeechRecognition;
};