import { useAuth } from "@/hooks/useAuth";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { ObjectUploader } from "./ObjectUploader";
import CourseCard from "./CourseCard";
import ProgressBar from "./ProgressBar";
import { 
  BookOpen, 
  Users, 
  TrendingUp, 
  Award, 
  Clock,
  Plus,
  Edit,
  BarChart3,
  FileText,
  Star
} from "lucide-react";
import { Link } from "wouter";

export default function RoleBasedDashboard() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isCreateCourseOpen, setIsCreateCourseOpen] = useState(false);
  const [newCourse, setNewCourse] = useState({
    title: '',
    description: '',
    category: 'energy_transition',
    price: '0',
    duration: 1,
    level: 'beginner'
  });

  const { data: dashboardStats } = useQuery({
    queryKey: ['/api/dashboard/stats'],
    enabled: !!user?.id,
  });

  const { data: userEnrollments = [] } = useQuery({
    queryKey: ['/api/users', user?.id, 'enrollments'],
    enabled: !!user?.id && user?.role === 'learner',
  });

  const { data: facilitatorCourses = [] } = useQuery({
    queryKey: ['/api/facilitator/courses'],
    enabled: !!user?.id && (user?.role === 'facilitator' || user?.role === 'admin'),
  });

  const { data: allCourses = [] } = useQuery({
    queryKey: ['/api/courses'],
    enabled: !!user?.id && user?.role === 'admin',
  });

  const createCourseMutation = useMutation({
    mutationFn: async (courseData: any) => {
      const response = await fetch('/api/courses', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(courseData),
        credentials: 'include',
      });
      if (!response.ok) {
        const error = await response.text();
        throw new Error(error);
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/facilitator/courses'] });
      setIsCreateCourseOpen(false);
      setNewCourse({
        title: '',
        description: '',
        category: 'energy_transition',
        price: '0',
        duration: 1,
        level: 'beginner'
      });
      toast({
        title: "Course Created",
        description: "Your course has been created successfully!",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Creation Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const enrollmentMutation = useMutation({
    mutationFn: async (courseId: string) => {
      return apiRequest(`/api/enrollments`, {
        method: 'POST',
        body: JSON.stringify({ courseId }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/users/${user?.id}/enrollments`] });
      toast({
        title: "Success",
        description: "Successfully enrolled in JET 101 course!",
      });
    },
    onError: (error) => {
      toast({
        title: "Error", 
        description: "Failed to enroll in course",
        variant: "destructive",
      });
    },
  });

  const enrollInJETCourse = () => {
    enrollmentMutation.mutate('jet-energy-course');
  };

  const handleCreateCourse = () => {
    if (!newCourse.title || !newCourse.description) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }
    createCourseMutation.mutate(newCourse);
  };

  const handleFileUpload = async () => {
    try {
      const response = await fetch('/api/objects/upload', {
        method: 'POST',
        credentials: 'include',
      });
      if (!response.ok) throw new Error('Failed to get upload URL');
      const { uploadURL } = await response.json();
      return { method: 'PUT' as const, url: uploadURL };
    } catch (error) {
      toast({
        title: "Upload Error",
        description: "Failed to get upload URL",
        variant: "destructive",
      });
      throw error;
    }
  };

  const handleUploadComplete = async (result: any) => {
    if (result.successful && result.successful.length > 0) {
      const uploadURL = result.successful[0].uploadURL;
      try {
        const response = await fetch('/api/course-materials', {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ materialURL: uploadURL }),
          credentials: 'include',
        });
        if (!response.ok) throw new Error('Failed to save material');
        toast({
          title: "Upload Successful",
          description: "Course material uploaded successfully!",
        });
      } catch (error) {
        toast({
          title: "Save Error",
          description: "Failed to save uploaded material",
          variant: "destructive",
        });
      }
    }
  };

  if (user?.role === 'learner') {
    const inProgressCourses = userEnrollments.filter((enrollment: any) => 
      parseFloat(enrollment.progress) < 100
    );
    const completedCourses = userEnrollments.filter((enrollment: any) => 
      enrollment.completedAt
    );

    return (
      <div className="space-y-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">XP Points</p>
                  <p className="text-2xl font-bold text-[hsl(43,74%,36%)]" data-testid="learner-xp-points">
                    {dashboardStats?.totalXP || user?.xpPoints || 0}
                  </p>
                </div>
                <TrendingUp className="h-8 w-8 text-[hsl(43,74%,36%)]" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Courses Enrolled</p>
                  <p className="text-2xl font-bold" data-testid="learner-enrolled-count">
                    {dashboardStats?.enrollmentCount || userEnrollments.length}
                  </p>
                </div>
                <BookOpen className="h-8 w-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Completed</p>
                  <p className="text-2xl font-bold text-green-600" data-testid="learner-completed-count">
                    {dashboardStats?.completedCount || completedCourses.length}
                  </p>
                </div>
                <Award className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Learning Streak</p>
                  <p className="text-2xl font-bold text-orange-600" data-testid="learner-streak">
                    {dashboardStats?.learningStreak || user?.learningStreak || 0} days
                  </p>
                </div>
                <Clock className="h-8 w-8 text-orange-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* In Progress Courses */}
        <Card>
          <CardHeader>
            <CardTitle>Continue Learning</CardTitle>
          </CardHeader>
          <CardContent>
            {inProgressCourses.length > 0 ? (
              <div className="space-y-4">
                {inProgressCourses.map((enrollment: any) => (
                  <div key={enrollment.id} className="flex items-center space-x-4 p-4 border rounded-lg">
                    <img
                      src="https://images.unsplash.com/photo-1466611653911-95081537e5b7?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100"
                      alt={enrollment.course.title}
                      className="w-16 h-16 rounded-lg object-cover"
                      data-testid={`img-progress-course-${enrollment.course.id}`}
                    />
                    <div className="flex-1">
                      <h3 className="font-semibold mb-2" data-testid={`text-progress-title-${enrollment.course.id}`}>
                        {enrollment.course.title}
                      </h3>
                      <ProgressBar value={parseFloat(enrollment.progress)} className="mb-2" />
                      <p className="text-sm text-gray-600">
                        {Math.round(parseFloat(enrollment.progress))}% Complete
                      </p>
                    </div>
                    <Link href={`/course/${enrollment.course.id}`}>
                      <Button className="btn-gold" data-testid={`button-continue-${enrollment.course.id}`}>
                        Continue
                      </Button>
                    </Link>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <BookOpen className="h-12 w-12 text-[hsl(43,74%,36%)] mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-4">Ready to Start Learning?</h3>
                <p className="text-gray-600 mb-6">Join our flagship Just Energy Transition course to begin your journey</p>
                <Button 
                  onClick={() => enrollInJETCourse()}
                  className="bg-[hsl(43,74%,36%)] hover:bg-[hsl(43,74%,30%)] text-white"
                  data-testid="button-enroll-jet"
                >
                  Enroll in JET 101 Course
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Completed Courses */}
        {completedCourses.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Completed Courses</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {completedCourses.map((enrollment: any) => (
                  <div key={enrollment.id} className="bg-gradient-to-r from-[hsl(43,74%,36%)] to-[hsl(43,87%,58%)] text-white p-4 rounded-lg text-center">
                    <Award className="h-8 w-8 mx-auto mb-2" />
                    <h4 className="font-semibold" data-testid={`text-completed-title-${enrollment.course.id}`}>
                      {enrollment.course.title}
                    </h4>
                    <p className="text-sm opacity-90">
                      Completed on {new Date(enrollment.completedAt).toLocaleDateString()}
                    </p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    );
  }

  if (user?.role === 'facilitator' || user?.role === 'admin') {
    return (
      <div className="space-y-8">
        {/* Create Course Button */}
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold">My Courses</h2>
          <Dialog open={isCreateCourseOpen} onOpenChange={setIsCreateCourseOpen}>
            <DialogTrigger asChild>
              <Button className="btn-gold" data-testid="button-create-course">
                <Plus className="w-4 h-4 mr-2" />
                Create Course
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Create New Course</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="title">Course Title</Label>
                  <Input
                    id="title"
                    value={newCourse.title}
                    onChange={(e) => setNewCourse(prev => ({ ...prev, title: e.target.value }))}
                    placeholder="Enter course title"
                    data-testid="input-course-title"
                  />
                </div>
                
                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={newCourse.description}
                    onChange={(e) => setNewCourse(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Course description"
                    rows={3}
                    data-testid="textarea-course-description"
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="category">Category</Label>
                    <Select value={newCourse.category} onValueChange={(value) => setNewCourse(prev => ({ ...prev, category: value }))}>
                      <SelectTrigger data-testid="select-course-category">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="energy_transition">Energy Transition</SelectItem>
                        <SelectItem value="digital_skills">Digital Skills</SelectItem>
                        <SelectItem value="entrepreneurship">Entrepreneurship</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label htmlFor="duration">Duration (hours)</Label>
                    <Input
                      id="duration"
                      type="number"
                      value={newCourse.duration}
                      onChange={(e) => setNewCourse(prev => ({ ...prev, duration: parseInt(e.target.value) || 1 }))}
                      min="1"
                      data-testid="input-course-duration"
                    />
                  </div>
                </div>

                <div>
                  <Label>Course Materials</Label>
                  <ObjectUploader
                    maxNumberOfFiles={5}
                    maxFileSize={104857600} // 100MB
                    onGetUploadParameters={handleFileUpload}
                    onComplete={handleUploadComplete}
                    buttonClassName="w-full"
                  >
                    <FileText className="w-4 h-4 mr-2" />
                    Upload Course Materials
                  </ObjectUploader>
                </div>
                
                <div className="flex space-x-4">
                  <Button 
                    variant="outline" 
                    onClick={() => setIsCreateCourseOpen(false)}
                    className="flex-1"
                    data-testid="button-cancel-course"
                  >
                    Cancel
                  </Button>
                  <Button 
                    onClick={handleCreateCourse}
                    disabled={createCourseMutation.isPending}
                    className="flex-1 btn-gold"
                    data-testid="button-save-course"
                  >
                    {createCourseMutation.isPending ? 'Creating...' : 'Create Course'}
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Facilitator Courses */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {facilitatorCourses.map((course: any) => (
            <Card key={course.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold text-lg" data-testid={`text-facilitator-course-${course.id}`}>
                    {course.title}
                  </h3>
                  <Badge variant={course.isPublished ? "default" : "secondary"}>
                    {course.isPublished ? "Published" : "Draft"}
                  </Badge>
                </div>
                
                <div className="space-y-2 mb-4">
                  <div className="flex justify-between">
                    <span>Enrolled Students:</span>
                    <span className="font-semibold" data-testid={`text-enrollment-count-${course.id}`}>
                      {course.enrollmentCount}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Rating:</span>
                    <div className="flex items-center">
                      <Star className="w-4 h-4 text-yellow-500 mr-1" />
                      <span className="font-semibold" data-testid={`text-course-rating-${course.id}`}>
                        {course.rating && parseFloat(course.rating) > 0 ? parseFloat(course.rating).toFixed(1) : 'No ratings'}
                      </span>
                    </div>
                  </div>
                  <div className="flex justify-between">
                    <span>Price:</span>
                    <span className="font-semibold text-[hsl(43,74%,36%)]" data-testid={`text-course-price-${course.id}`}>
                      {course.price === '0' ? 'FREE' : `$${course.price}`}
                    </span>
                  </div>
                </div>
                
                <div className="flex space-x-2">
                  <Link href={`/course/${course.id}`}>
                    <Button variant="outline" size="sm" className="flex-1" data-testid={`button-view-course-${course.id}`}>
                      <Edit className="w-4 h-4 mr-1" />
                      Edit
                    </Button>
                  </Link>
                  <Button variant="outline" size="sm" className="flex-1" data-testid={`button-analytics-${course.id}`}>
                    <BarChart3 className="w-4 h-4 mr-1" />
                    Analytics
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {facilitatorCourses.length === 0 && (
          <Card>
            <CardContent className="p-8 text-center">
              <BookOpen className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">No courses created yet</h3>
              <p className="text-gray-600 mb-4">Start sharing your knowledge by creating your first course</p>
              <Button className="btn-gold" onClick={() => setIsCreateCourseOpen(true)} data-testid="button-create-first-course">
                Create Your First Course
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    );
  }

  if (user?.role === 'admin') {
    return (
      <div className="space-y-8">
        {/* Platform Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Users</p>
                  <p className="text-2xl font-bold text-blue-600" data-testid="admin-total-users">
                    {dashboardStats?.totalUsers || 0}
                  </p>
                </div>
                <Users className="h-8 w-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Courses</p>
                  <p className="text-2xl font-bold text-green-600" data-testid="admin-total-courses">
                    {dashboardStats?.totalCourses || 0}
                  </p>
                </div>
                <BookOpen className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Enrollments</p>
                  <p className="text-2xl font-bold text-[hsl(43,74%,36%)]" data-testid="admin-total-enrollments">
                    {dashboardStats?.totalEnrollments || 0}
                  </p>
                </div>
                <TrendingUp className="h-8 w-8 text-[hsl(43,74%,36%)]" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Certificates Issued</p>
                  <p className="text-2xl font-bold text-purple-600" data-testid="admin-total-certificates">
                    {dashboardStats?.totalCertificates || 0}
                  </p>
                </div>
                <Award className="h-8 w-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* All Courses */}
        <Card>
          <CardHeader>
            <CardTitle>All Courses</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {allCourses.map((course: any) => (
                <CourseCard key={course.id} course={course} />
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="text-center py-8">
      <h3 className="text-lg font-semibold mb-2">Dashboard Loading...</h3>
      <p className="text-gray-600">Setting up your personalized dashboard</p>
    </div>
  );
}
