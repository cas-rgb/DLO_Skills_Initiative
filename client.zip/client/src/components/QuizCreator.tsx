import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Plus, Trash2, ArrowUp, ArrowDown, Save } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { Quiz, Course, CourseModule, QuizQuestion as SchemaQuizQuestion } from "@shared/schema";

const quizSchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().optional(),
  courseId: z.string().min(1, "Course is required"),
  moduleId: z.string().optional(),
  instructions: z.string().optional(),
  timeLimit: z.number().optional(),
  passingScore: z.number().min(0).max(100).default(70),
  maxAttempts: z.number().min(1).optional(),
  shuffleQuestions: z.boolean().default(false),
  showCorrectAnswers: z.boolean().default(true),
  isPublished: z.boolean().default(false),
});

type QuizFormData = z.infer<typeof quizSchema>;

interface QuizQuestion {
  id?: string;
  type: "multiple_choice" | "true_false" | "short_answer" | "essay";
  question: string;
  options?: string[];
  correctAnswer?: string;
  explanation?: string;
  points: number;
  orderIndex: number;
}

interface QuizCreatorProps {
  quiz?: Quiz | null;
  onSave: () => void;
  onCancel: () => void;
}

export default function QuizCreator({ quiz, onSave, onCancel }: QuizCreatorProps) {
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [selectedCourse, setSelectedCourse] = useState<string>("");
  const { toast } = useToast();

  const form = useForm<QuizFormData>({
    resolver: zodResolver(quizSchema),
    defaultValues: {
      title: "",
      description: "",
      courseId: "",
      moduleId: "",
      instructions: "",
      passingScore: 70,
      shuffleQuestions: false,
      showCorrectAnswers: true,
      isPublished: false,
    },
  });

  // Fetch courses
  const { data: courses = [] } = useQuery<Course[]>({
    queryKey: ["/api/courses"],
  });

  // Fetch modules for selected course
  const { data: modules = [] } = useQuery<CourseModule[]>({
    queryKey: ["/api/courses", selectedCourse, "modules"],
    enabled: !!selectedCourse,
  });

  // Fetch existing quiz data if editing
  useEffect(() => {
    if (quiz) {
      form.reset({
        title: quiz.title,
        description: quiz.description || "",
        courseId: quiz.courseId || "",
        moduleId: quiz.moduleId || "",
        instructions: quiz.instructions || "",
        timeLimit: quiz.timeLimit || undefined,
        passingScore: quiz.passingScore || 70,
        maxAttempts: quiz.maxAttempts || undefined,
        shuffleQuestions: quiz.shuffleQuestions || false,
        showCorrectAnswers: quiz.showCorrectAnswers || true,
        isPublished: quiz.isPublished || false,
      });
      setSelectedCourse(quiz.courseId || "");

      // Fetch quiz questions
      apiRequest(`/api/quizzes/${quiz.id}`)
        .then((quizData: Quiz & { questions: SchemaQuizQuestion[] }) => {
          const questions = quizData.questions || [];
          setQuestions(questions.sort((a, b) => a.orderIndex - b.orderIndex));
        })
        .catch((error) => {
          console.error("Error fetching quiz questions:", error);
        });
    }
  }, [quiz, form]);

  // Watch courseId changes
  const watchedCourseId = form.watch("courseId");
  useEffect(() => {
    setSelectedCourse(watchedCourseId);
    if (watchedCourseId !== selectedCourse) {
      form.setValue("moduleId", "");
    }
  }, [watchedCourseId, selectedCourse, form]);

  // Save quiz mutation
  const saveQuizMutation = useMutation({
    mutationFn: async (data: QuizFormData) => {
      const quizData = {
        ...data,
        timeLimit: data.timeLimit || null,
        maxAttempts: data.maxAttempts || null,
        moduleId: data.moduleId || null,
      };

      let savedQuiz: Quiz;
      if (quiz) {
        savedQuiz = await apiRequest(`/api/quizzes/${quiz.id}`, "PUT", quizData);
      } else {
        savedQuiz = await apiRequest("/api/quizzes", "POST", quizData);
      }

      // Save questions
      for (let index = 0; index < questions.length; index++) {
        const question = questions[index];
        const questionData = {
          ...question,
          orderIndex: index,
          quizId: savedQuiz.id,
        };

        if (question.id) {
          await apiRequest(`/api/quizzes/${savedQuiz.id}/questions/${question.id}`, "PUT", questionData);
        } else {
          await apiRequest(`/api/quizzes/${savedQuiz.id}/questions`, "POST", questionData);
        }
      }

      return savedQuiz;
    },
    onSuccess: () => {
      onSave();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to save quiz",
        variant: "destructive",
      });
    },
  });

  const addQuestion = () => {
    const newQuestion: QuizQuestion = {
      type: "multiple_choice",
      question: "",
      options: ["", "", "", ""],
      correctAnswer: "",
      explanation: "",
      points: 1,
      orderIndex: questions.length,
    };
    setQuestions([...questions, newQuestion]);
  };

  const updateQuestion = (index: number, updatedQuestion: Partial<QuizQuestion>) => {
    const newQuestions = [...questions];
    newQuestions[index] = { ...newQuestions[index], ...updatedQuestion };
    setQuestions(newQuestions);
  };

  const deleteQuestion = (index: number) => {
    setQuestions(questions.filter((_, i) => i !== index));
  };

  const moveQuestion = (index: number, direction: "up" | "down") => {
    const newQuestions = [...questions];
    const targetIndex = direction === "up" ? index - 1 : index + 1;
    
    if (targetIndex >= 0 && targetIndex < questions.length) {
      [newQuestions[index], newQuestions[targetIndex]] = [newQuestions[targetIndex], newQuestions[index]];
      setQuestions(newQuestions);
    }
  };

  const onSubmit = (data: QuizFormData) => {
    if (questions.length === 0) {
      toast({
        title: "Error",
        description: "Please add at least one question to the quiz",
        variant: "destructive",
      });
      return;
    }
    saveQuizMutation.mutate(data);
  };

  return (
    <div className="space-y-6">
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          {/* Basic Quiz Information */}
          <Card>
            <CardHeader>
              <CardTitle>Quiz Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Quiz Title *</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter quiz title" {...field} data-testid="input-quiz-title" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="courseId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Course *</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-quiz-course">
                            <SelectValue placeholder="Select a course" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {courses.map((course) => (
                            <SelectItem key={course.id} value={course.id}>
                              {course.title}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Brief description of the quiz"
                        {...field}
                        data-testid="textarea-quiz-description"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="instructions"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Instructions</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Instructions for students taking the quiz"
                        {...field}
                        data-testid="textarea-quiz-instructions"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-3 gap-4">
                <FormField
                  control={form.control}
                  name="timeLimit"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Time Limit (minutes)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number"
                          placeholder="No limit"
                          {...field}
                          value={field.value || ""}
                          onChange={(e) => field.onChange(e.target.value ? parseInt(e.target.value) : undefined)}
                          data-testid="input-quiz-time-limit"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="passingScore"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Passing Score (%)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number"
                          min="0"
                          max="100"
                          {...field}
                          onChange={(e) => field.onChange(parseInt(e.target.value))}
                          data-testid="input-quiz-passing-score"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="maxAttempts"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Max Attempts</FormLabel>
                      <FormControl>
                        <Input 
                          type="number"
                          min="1"
                          placeholder="Unlimited"
                          {...field}
                          value={field.value || ""}
                          onChange={(e) => field.onChange(e.target.value ? parseInt(e.target.value) : undefined)}
                          data-testid="input-quiz-max-attempts"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="flex gap-6">
                <FormField
                  control={form.control}
                  name="shuffleQuestions"
                  render={({ field }) => (
                    <FormItem className="flex items-center space-x-2">
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                          data-testid="switch-shuffle-questions"
                        />
                      </FormControl>
                      <FormLabel>Shuffle Questions</FormLabel>
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="showCorrectAnswers"
                  render={({ field }) => (
                    <FormItem className="flex items-center space-x-2">
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                          data-testid="switch-show-correct-answers"
                        />
                      </FormControl>
                      <FormLabel>Show Correct Answers</FormLabel>
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="isPublished"
                  render={({ field }) => (
                    <FormItem className="flex items-center space-x-2">
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                          data-testid="switch-publish-quiz"
                        />
                      </FormControl>
                      <FormLabel>Publish Quiz</FormLabel>
                    </FormItem>
                  )}
                />
              </div>
            </CardContent>
          </Card>

          {/* Questions Section */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Questions ({questions.length})</CardTitle>
              <Button 
                type="button" 
                onClick={addQuestion}
                variant="outline"
                data-testid="button-add-question"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Question
              </Button>
            </CardHeader>
            <CardContent className="space-y-4">
              {questions.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <p>No questions added yet. Click "Add Question" to get started.</p>
                </div>
              ) : (
                questions.map((question, index) => (
                  <QuestionEditor
                    key={index}
                    question={question}
                    index={index}
                    totalQuestions={questions.length}
                    onUpdate={(updatedQuestion) => updateQuestion(index, updatedQuestion)}
                    onDelete={() => deleteQuestion(index)}
                    onMove={(direction) => moveQuestion(index, direction)}
                  />
                ))
              )}
            </CardContent>
          </Card>

          {/* Action Buttons */}
          <div className="flex justify-end gap-3">
            <Button type="button" variant="outline" onClick={onCancel} data-testid="button-cancel-quiz">
              Cancel
            </Button>
            <Button 
              type="submit" 
              className="bg-yellow-600 hover:bg-yellow-700"
              disabled={saveQuizMutation.isPending}
              data-testid="button-save-quiz"
            >
              <Save className="w-4 h-4 mr-2" />
              {saveQuizMutation.isPending ? "Saving..." : "Save Quiz"}
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
}

// Question Editor Component
interface QuestionEditorProps {
  question: QuizQuestion;
  index: number;
  totalQuestions: number;
  onUpdate: (question: Partial<QuizQuestion>) => void;
  onDelete: () => void;
  onMove: (direction: "up" | "down") => void;
}

function QuestionEditor({ question, index, totalQuestions, onUpdate, onDelete, onMove }: QuestionEditorProps) {
  const updateOption = (optionIndex: number, value: string) => {
    const newOptions = [...(question.options || [])];
    newOptions[optionIndex] = value;
    onUpdate({ options: newOptions });
  };

  const addOption = () => {
    const newOptions = [...(question.options || []), ""];
    onUpdate({ options: newOptions });
  };

  const removeOption = (optionIndex: number) => {
    const newOptions = (question.options || []).filter((_, i) => i !== optionIndex);
    onUpdate({ options: newOptions });
  };

  return (
    <Card className="border-l-4 border-l-yellow-500" data-testid={`card-question-${index}`}>
      <CardHeader className="pb-3">
        <div className="flex justify-between items-center">
          <Badge variant="secondary">Question {index + 1}</Badge>
          <div className="flex gap-1">
            <Button
              type="button"
              size="sm"
              variant="outline"
              onClick={() => onMove("up")}
              disabled={index === 0}
              data-testid={`button-move-up-${index}`}
            >
              <ArrowUp className="w-4 h-4" />
            </Button>
            <Button
              type="button"
              size="sm"
              variant="outline"
              onClick={() => onMove("down")}
              disabled={index === totalQuestions - 1}
              data-testid={`button-move-down-${index}`}
            >
              <ArrowDown className="w-4 h-4" />
            </Button>
            <Button
              type="button"
              size="sm"
              variant="outline"
              onClick={onDelete}
              className="text-red-600 hover:text-red-700"
              data-testid={`button-delete-question-${index}`}
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label>Question Type</Label>
            <Select
              value={question.type}
              onValueChange={(value: any) => onUpdate({ type: value })}
            >
              <SelectTrigger data-testid={`select-question-type-${index}`}>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="multiple_choice">Multiple Choice</SelectItem>
                <SelectItem value="true_false">True/False</SelectItem>
                <SelectItem value="short_answer">Short Answer</SelectItem>
                <SelectItem value="essay">Essay</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Points</Label>
            <Input
              type="number"
              min="1"
              value={question.points}
              onChange={(e) => onUpdate({ points: parseInt(e.target.value) || 1 })}
              data-testid={`input-question-points-${index}`}
            />
          </div>
        </div>

        <div>
          <Label>Question Text *</Label>
          <Textarea
            value={question.question}
            onChange={(e) => onUpdate({ question: e.target.value })}
            placeholder="Enter your question"
            data-testid={`textarea-question-text-${index}`}
          />
        </div>

        {(question.type === "multiple_choice" || question.type === "true_false") && (
          <div>
            <Label>Answer Options</Label>
            <div className="space-y-2 mt-2">
              {question.type === "true_false" ? (
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <input
                      type="radio"
                      name={`correct-${index}`}
                      checked={question.correctAnswer === "true"}
                      onChange={() => onUpdate({ correctAnswer: "true" })}
                      data-testid={`radio-true-${index}`}
                    />
                    <span>True</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                      type="radio"
                      name={`correct-${index}`}
                      checked={question.correctAnswer === "false"}
                      onChange={() => onUpdate({ correctAnswer: "false" })}
                      data-testid={`radio-false-${index}`}
                    />
                    <span>False</span>
                  </div>
                </div>
              ) : (
                <>
                  {(question.options || []).map((option, optionIndex) => (
                    <div key={optionIndex} className="flex items-center gap-2">
                      <input
                        type="radio"
                        name={`correct-${index}`}
                        checked={question.correctAnswer === option}
                        onChange={() => onUpdate({ correctAnswer: option })}
                        data-testid={`radio-option-${index}-${optionIndex}`}
                      />
                      <Input
                        value={option}
                        onChange={(e) => updateOption(optionIndex, e.target.value)}
                        placeholder={`Option ${optionIndex + 1}`}
                        className="flex-1"
                        data-testid={`input-option-${index}-${optionIndex}`}
                      />
                      {(question.options?.length || 0) > 2 && (
                        <Button
                          type="button"
                          size="sm"
                          variant="outline"
                          onClick={() => removeOption(optionIndex)}
                          data-testid={`button-remove-option-${index}-${optionIndex}`}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  ))}
                  <Button
                    type="button"
                    size="sm"
                    variant="outline"
                    onClick={addOption}
                    data-testid={`button-add-option-${index}`}
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Option
                  </Button>
                </>
              )}
            </div>
          </div>
        )}

        {(question.type === "short_answer" || question.type === "essay") && (
          <div>
            <Label>Sample/Expected Answer</Label>
            <Textarea
              value={question.correctAnswer || ""}
              onChange={(e) => onUpdate({ correctAnswer: e.target.value })}
              placeholder="Enter sample or expected answer for grading reference"
              data-testid={`textarea-expected-answer-${index}`}
            />
          </div>
        )}

        <div>
          <Label>Explanation (optional)</Label>
          <Textarea
            value={question.explanation || ""}
            onChange={(e) => onUpdate({ explanation: e.target.value })}
            placeholder="Explanation shown to students after answering"
            data-testid={`textarea-question-explanation-${index}`}
          />
        </div>
      </CardContent>
    </Card>
  );
}