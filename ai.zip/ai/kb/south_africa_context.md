# South Africa's Energy Context and REIPPPP

## Historical Energy Landscape

### Coal Dependency
- **Historical reliance**: 80%+ of electricity generation from coal
- **Eskom dominance**: State-owned utility controlling 95% of generation
- **Aging infrastructure**: Coal plants built in 1970s-1980s reaching end of life
- **Economic importance**: Coal mining employs ~80,000 workers directly
- **Export revenue**: Significant coal exports to Asia and Europe

### Energy Crisis Context
- **Load shedding**: Rolling blackouts since 2007, intensifying after 2019
- **Economic impact**: GDP losses estimated at 2-3% annually
- **Investment uncertainty**: Business confidence affected by unreliable supply
- **Social impact**: Disrupted education, healthcare, and daily life
- **Energy poverty**: 3.5 million households without electricity access

## REIPPPP Program Overview

### Program Launch and Objectives
- **Launch date**: August 2011
- **Primary goal**: Diversify energy mix and reduce dependency on coal
- **Secondary objectives**: 
  - Attract private investment
  - Create jobs and local economic development
  - Build renewable energy industry
  - Reduce greenhouse gas emissions

### Program Structure
- **Procurement approach**: Competitive bidding rounds (Bid Windows)
- **Technology focus**: Solar PV, wind, concentrated solar power (CSP), biomass, small hydro
- **Contract model**: 20-year Power Purchase Agreements (PPAs) with Eskom
- **Evaluation criteria**: 70% price, 30% economic development

## Bid Window Results

### Bid Window 1 (November 2011)
- **Capacity**: 1,416 MW (28 projects)
- **Investment**: R47 billion
- **Average tariffs**: Solar PV R3.65/kWh, Wind R1.14/kWh
- **Jobs**: 13,900 during construction, 1,240 operational
- **Key achievement**: Successful program launch and proof of concept

### Bid Window 2 (March 2012)
- **Capacity**: 1,363 MW (19 projects)
- **Investment**: R43 billion
- **Average tariffs**: Solar PV R2.18/kWh, Wind R0.89/kWh
- **Cost reduction**: 40% reduction in solar tariffs from BW1
- **Jobs**: 12,100 during construction, 1,370 operational

### Bid Window 3 (October 2013)
- **Capacity**: 1,473 MW (17 projects)
- **Investment**: R58 billion
- **Average tariffs**: Solar PV R1.17/kWh, Wind R0.66/kWh
- **Innovation**: Introduction of storage requirements for CSP
- **Jobs**: 15,960 during construction, 1,750 operational

### Bid Window 4 (April 2015)
- **Capacity**: 1,980 MW (26 projects)
- **Investment**: R62 billion
- **Average tariffs**: Solar PV R0.62/kWh, Wind R0.62/kWh
- **Record achievement**: Lowest renewable energy prices globally at the time
- **Delayed signing**: Political and regulatory challenges delayed implementation

### Later Rounds
- **BW4 Expedited (2018)**: Emergency procurement, 2,300 MW
- **RMIPPPP**: Risk Mitigation Independent Power Producer Programme
- **BW5 & BW6**: Recent rounds focusing on grid stability and storage

## Economic Development Requirements

### Local Content
- **Solar PV**: 25-35% local content requirements
- **Wind**: 25-45% local content requirements
- **Tower manufacturing**: Localized wind tower production
- **Challenges**: Limited local manufacturing capacity, import dependency

### Community Ownership
- **Requirement**: Minimum community ownership levels
- **Structure**: Community trusts and shareholding arrangements
- **Benefits**: Revenue sharing, skill development, local economic growth
- **Challenges**: Complex legal structures, capacity building needs

### Skills Development
- **Training programs**: Technical and artisan skills development
- **Beneficiaries**: 40,000+ people trained through REIPPPP projects
- **Institutions**: Partnerships with universities and technical colleges
- **Focus areas**: Operations and maintenance, project development

## Economic and Social Impacts

### Investment Attraction
- **Total investment**: R194 billion across all bid windows
- **Foreign investment**: 60%+ from international investors
- **Leverage effect**: Additional private sector investment in manufacturing

### Job Creation
- **Construction phase**: 40,000+ peak employment
- **Operational phase**: 5,000+ permanent jobs
- **Indirect jobs**: Estimated 100,000+ in supply chains
- **Skills transfer**: Technology transfer and capacity building

### Community Development
- **Total commitments**: R15+ billion in community development over 20 years
- **Focus areas**: Education, healthcare, enterprise development
- **Rural impact**: Significant investment in rural and farming communities
- **Gender inclusion**: Women's economic empowerment programs

## Technology Cost Reductions

### Solar PV
- **BW1 (2011)**: R3.65/kWh average
- **BW4 (2015)**: R0.62/kWh average
- **Cost reduction**: 83% reduction over four bid windows
- **Global comparison**: Among world's lowest solar tariffs

### Wind
- **BW1 (2011)**: R1.14/kWh average  
- **BW4 (2015)**: R0.62/kWh average
- **Cost reduction**: 46% reduction over four bid windows
- **Capacity factors**: 30-45% due to excellent wind resources

## Policy Framework

### Integrated Resource Plan (IRP)
- **2010 IRP**: 17.8 GW renewable energy by 2030
- **2019 IRP Update**: 28 GW renewable energy by 2030
- **Coal phase-down**: Retirement of aging coal plants
- **Flexibility**: Regular updates to reflect technology cost changes

### Regulatory Environment
- **NERSA**: National Energy Regulator of South Africa oversight
- **DMRE**: Department of Mineral Resources and Energy coordination
- **IPP Office**: Dedicated procurement entity
- **Grid codes**: Technical standards for grid connection

## Challenges and Lessons Learned

### Implementation Challenges
- **Grid connection delays**: Eskom transmission constraints
- **PPA signing delays**: Political interference and legal challenges
- **Policy uncertainty**: Stop-start nature affecting investor confidence
- **Skills shortages**: Limited local technical expertise initially

### Financial Challenges
- **Eskom financial crisis**: Utility's financial difficulties affecting payments
- **Currency risk**: Exchange rate volatility affecting project economics
- **Financing costs**: Higher costs due to emerging market risks
- **Bankability**: Complex risk allocation in PPAs

### Manufacturing Limitations
- **Local content challenges**: Limited manufacturing capacity
- **Import dependency**: Continued reliance on imported technology
- **Skills gaps**: Shortage of specialized manufacturing skills
- **Market size**: Small domestic market limiting economies of scale

## Success Factors

### Institutional Design
- **Independent procurement**: IPP Office independence from Eskom
- **Transparent process**: Clear, competitive, and fair procurement
- **Risk allocation**: Balanced risk sharing between public and private sectors
- **Standardized contracts**: Simplified and bankable PPA terms

### Political Support
- **Cross-party consensus**: Support across political spectrum initially
- **International backing**: Development finance institution support
- **Business community**: Strong private sector engagement
- **Civil society**: Environmental groups and communities supportive

## Lessons for Other African Countries

### Replicable Elements
- **Competitive procurement**: Transparent bidding processes drive down costs
- **Economic development**: Local content and community requirements
- **Institutional capacity**: Dedicated procurement entities
- **International cooperation**: Learning from global best practices

### Context-Specific Adaptations
- **Grid capacity**: Transmission infrastructure requirements
- **Financial markets**: Local capital market development needs
- **Regulatory frameworks**: Appropriate legal and regulatory systems
- **Political economy**: Managing transition politics and vested interests

### Regional Applications
- **Nigeria**: Power sector reform and renewable energy potential
- **Kenya**: Geothermal and solar development programs
- **Ghana**: Solar and wind procurement initiatives
- **Morocco**: Concentrated solar power and wind programs

## Future Outlook

### Just Energy Transition Partnership
- **Financing**: $8.5 billion international climate finance commitment
- **Focus areas**: Coal region transition, green hydrogen, electric vehicles
- **Social components**: Worker retraining and community development
- **Timeline**: 2022-2027 implementation period

### Technology Evolution
- **Storage integration**: Battery storage requirements in new rounds
- **Grid flexibility**: Demand response and smart grid technologies
- **Green hydrogen**: Renewable energy for hydrogen production
- **Electric vehicles**: Charging infrastructure development

### Social Transition
- **Coal communities**: Support for mining-dependent regions
- **Skills transition**: Retraining programs for coal workers
- **Regional development**: Diversifying local economies
- **Gender inclusion**: Women's participation in new energy economy