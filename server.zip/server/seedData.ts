import { storage } from "./storage";

export async function seedDatabase() {
  try {
    // Create sample course (or get existing)
    let course = await storage.getCourse("jet-energy-course");
    if (!course) {
      course = await storage.createCourse({
        id: "jet-energy-course",
        title: "Just Energy Transition Fundamentals",
        shortName: "JET-101",
        description: "Learn the fundamentals of Just Energy Transition - a comprehensive introduction to sustainable energy systems and equitable transition strategies.",
        category: "Energy Transition",
        level: "beginner",
        duration: 20,
        isPublished: true,
        facilitatorId: null,
      });
    }

    // Create course sections (Moodle-style) - skip if already exist
    const existingSections = await storage.getCourseSections(course.id);
    if (existingSections.length === 0) {
      const section1 = await storage.createSection({
        id: "jet-intro-section",
        courseId: course.id,
        title: "Introduction to Just Energy Transition",
        description: "Understanding the basics of energy transition and why it matters for our future.",
        orderIndex: 1,
        visible: true,
      });

      const section2 = await storage.createSection({
        id: "jet-pillars-section", 
        courseId: course.id,
        title: "The Five Pillars of JET",
        description: "Deep dive into the five fundamental pillars that define a just energy transition.",
        orderIndex: 2,
        visible: true,
      });

      const section3 = await storage.createSection({
        id: "jet-implementation-section",
        courseId: course.id,
        title: "Implementation and Case Studies",
        description: "Real-world examples and practical approaches to implementing energy transition.",
        orderIndex: 3,
        visible: true,
      });
    }

    // Get existing sections for module creation
    const sections = await storage.getCourseSections(course.id);
    const section1 = sections.find(s => s.id === "jet-intro-section");
    const section2 = sections.find(s => s.id === "jet-pillars-section");  
    const section3 = sections.find(s => s.id === "jet-implementation-section");

    // Create modules within sections if they don't exist
    const existingModules = await storage.getCourseModules(course.id);
    if (existingModules.length === 0 && section1 && section2 && section3) {
    await storage.createModule({
      id: "jet-module-1",
      courseId: course.id,
      sectionId: section1.id,
      title: "What is Just Energy Transition?",
      description: "Understanding the concept and importance of just energy transition in the African context.",
      content: `
        <div class="module-header">
          <h1>Understanding Just Energy Transition</h1>
          <div class="learning-objectives">
            <h3>🎯 Learning Objectives</h3>
            <ul>
              <li>Define Just Energy Transition and its core principles</li>
              <li>Understand the African energy context and challenges</li>
              <li>Identify opportunities for equitable energy transformation</li>
              <li>Recognize the importance of social justice in energy policy</li>
            </ul>
          </div>
        </div>

        <section class="content-section">
          <h2>🌍 What is Just Energy Transition?</h2>
          <p class="definition">A Just Energy Transition (JET) refers to a framework that ensures the shift to sustainable energy is fair and inclusive, leaving no one behind. It encompasses social, economic, and environmental considerations to create an equitable energy transformation.</p>

          <div class="key-principles">
            <h3>🔑 Core Principles of JET:</h3>
            <div class="principles-grid">
              <div class="principle-card">
                <h4>⚖️ Equity</h4>
                <p>Ensuring benefits and burdens are shared fairly across all communities, with priority given to historically disadvantaged groups.</p>
              </div>
              <div class="principle-card">
                <h4>🤝 Inclusivity</h4>
                <p>Involving all stakeholders in decision-making processes, especially affected communities and workers.</p>
              </div>
              <div class="principle-card">
                <h4>🌱 Sustainability</h4>
                <p>Long-term environmental and economic viability that protects future generations.</p>
              </div>
              <div class="principle-card">
                <h4>🏛️ Social Justice</h4>
                <p>Protecting vulnerable communities and addressing historical inequalities in energy access.</p>
              </div>
            </div>
          </div>

          <h3>📊 African Energy Context</h3>
          <div class="stats-highlight">
            <div class="stat-item">
              <span class="stat-number">600M+</span>
              <span class="stat-label">Africans lack electricity access</span>
            </div>
            <div class="stat-item">
              <span class="stat-number">40%</span>
              <span class="stat-label">Of global renewable potential in Africa</span>
            </div>
            <div class="stat-item">
              <span class="stat-number">$3T</span>
              <span class="stat-label">Investment needed by 2050</span>
            </div>
          </div>

          <h3>🚀 Why JET Matters for Africa</h3>
          <ul class="benefits-list">
            <li><strong>Leapfrogging Opportunity:</strong> Africa can skip dirty energy infrastructure and move directly to clean technologies</li>
            <li><strong>Job Creation:</strong> Renewable energy sector could create millions of jobs across the continent</li>
            <li><strong>Energy Independence:</strong> Reduced dependence on fossil fuel imports</li>
            <li><strong>Climate Resilience:</strong> Building adaptive capacity for climate change impacts</li>
            <li><strong>Economic Development:</strong> Reliable energy access drives industrialization and growth</li>
          </ul>

          <h3>🏭 The Challenge of Transition</h3>
          <p>The transition to renewable energy affects millions of jobs, communities, and economies worldwide. Without proper planning, this transition could worsen existing inequalities. Key challenges include:</p>
          <ul>
            <li>Workers in fossil fuel industries facing job displacement</li>
            <li>Communities dependent on coal mining or oil extraction</li>
            <li>Ensuring rural and marginalized populations benefit from clean energy</li>
            <li>Balancing environmental goals with economic development needs</li>
          </ul>

          <h3>🌟 Global Examples</h3>
          <p>Many countries are implementing Just Energy Transition policies:</p>
          <ul>
            <li><strong>South Africa:</strong> $8.5 billion JET Partnership for coal transition</li>
            <li><strong>Poland:</strong> EU-funded transition for coal regions</li>
            <li><strong>Colombia:</strong> Peace and energy transition programs</li>
            <li><strong>India:</strong> Solar missions with rural employment focus</li>
          </ul>

          <div class="action-box">
            <h4>🎯 Reflection Question</h4>
            <p>Think about your community or country. What are the main energy challenges you observe? How could JET principles help address these challenges?</p>
          </div>
        </section>
      `,
      type: "lesson",
      orderIndex: 1,
      duration: 45,
      isAvailable: true,
    });

    await storage.createModule({
      id: "jet-module-2",
      courseId: course.id,
      sectionId: section1.id,
      title: "The Five Pillars of Just Energy Transition",
      description: "Understanding the comprehensive framework for equitable energy transformation through five interconnected pillars.",
      content: `
          <h2>Video Lesson: Understanding Energy Systems</h2>
          <div style="margin-bottom: 2rem;">
            <iframe 
              width="100%" 
              height="400" 
              src="https://www.youtube.com/embed/ipOeH7GW0M8" 
              title="Understanding Energy Systems - Educational Video"
              frameborder="0" 
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
              allowfullscreen
              style="border-radius: 8px;">
            </iframe>
            <p style="margin-top: 1rem; font-style: italic; color: #666;">⏰ Watch this video to understand the foundations of energy systems before learning about the JET pillars.</p>
          </div>

          <h2>The Five Pillars Framework</h2>
          <p>The Just Energy Transition framework is built on five interconnected pillars that ensure a comprehensive approach to energy transformation:</p>

          <div class="pillars-overview">
            <h3>1. Equitable Access</h3>
            <p>Ensuring all people have access to affordable, reliable, sustainable energy services.</p>

            <h3>2. Environmental Justice</h3>
            <p>Protecting communities from environmental harm while promoting clean energy.</p>

            <h3>3. Job Creation & Workforce Transition</h3>
            <p>Creating decent green jobs while supporting workers in declining industries.</p>

            <h3>4. Reducing Inequalities</h3>
            <p>Addressing systemic inequalities in energy systems and economic outcomes.</p>

            <h3>5. Community Involvement</h3>
            <p>Ensuring meaningful participation of communities in energy decisions.</p>
          </div>

          <h3>Pillar Interconnections</h3>
          <p>The five pillars are deeply interconnected and work together to create a just transition.</p>
        `,
      videoUrl: "https://youtu.be/ipOeH7GW0M8",
      type: "lesson",
      orderIndex: 2,
      duration: 50,
      isAvailable: true,
    });

    await storage.createModule({
      id: "jet-module-3",
      courseId: course.id,
      sectionId: section2.id,
      title: "Pillar 1: Equitable Access to Clean Energy",
      description: "Ensuring everyone has access to affordable, reliable, and clean energy.",
      content: `
        <h2>Equitable Access to Clean Energy</h2>
        <p>The first pillar focuses on ensuring that the benefits of clean energy reach everyone, especially marginalized communities.</p>

        <h3>What Does Equitable Access Mean?</h3>
        <ul>
          <li><strong>Affordability:</strong> Clean energy must be financially accessible</li>
          <li><strong>Reliability:</strong> Energy systems must provide consistent service</li>
          <li><strong>Quality:</strong> Energy services must meet modern standards</li>
          <li><strong>Geographic Reach:</strong> Rural and remote areas must be included</li>
        </ul>

        <h3>Current Energy Inequalities</h3>
        <p>Today, significant energy inequalities exist:</p>
        <ul>
          <li>Over 750 million people lack access to electricity</li>
          <li>2.8 billion people rely on traditional biomass for cooking</li>
          <li>Energy poverty affects both developing and developed countries</li>
          <li>Indigenous and rural communities often face energy access challenges</li>
        </ul>

        <h3>Solutions and Strategies</h3>
        <ul>
          <li><strong>Distributed Energy Systems:</strong> Local solar, wind, and micro-grids</li>
          <li><strong>Subsidies and Support:</strong> Financial assistance for low-income households</li>
          <li><strong>Community Ownership:</strong> Local control of energy projects</li>
          <li><strong>Technology Innovation:</strong> Affordable clean energy solutions</li>
        </ul>

        <h3>Case Study: Solar Home Systems in Africa</h3>
        <p>Pay-as-you-go solar systems have brought electricity to millions of households across Africa, demonstrating how innovative financing can make clean energy accessible.</p>
      `,
      type: "lesson",
      orderIndex: 1,
      duration: 50,
      isAvailable: true,
    });

    await storage.createModule({
      id: "jet-module-4",
      courseId: course.id,
      sectionId: section2.id,
      title: "Pillar 2: Environmental Justice",
      description: "Addressing environmental impacts and protecting vulnerable communities.",
      content: `
        <h2>Environmental Justice in Energy Transition</h2>
        <p>Environmental justice ensures that no community bears a disproportionate burden of environmental harm while ensuring all communities benefit from environmental improvements.</p>

        <h3>Key Principles of Environmental Justice</h3>
        <ul>
          <li><strong>No Disproportionate Impact:</strong> Avoiding concentrated environmental burdens</li>
          <li><strong>Meaningful Participation:</strong> Including affected communities in decision-making</li>
          <li><strong>Fair Treatment:</strong> Equal protection from environmental harm</li>
          <li><strong>Equitable Benefits:</strong> Sharing environmental improvements fairly</li>
        </ul>

        <h3>Environmental Justice Challenges</h3>
        <p>Historically, marginalized communities have faced:</p>
        <ul>
          <li>Higher exposure to pollution from fossil fuel facilities</li>
          <li>Limited voice in energy planning decisions</li>
          <li>Less access to clean air and water</li>
          <li>Greater health impacts from environmental degradation</li>
        </ul>

        <h3>Solutions in Energy Transition</h3>
        <ul>
          <li><strong>Community Engagement:</strong> Early and meaningful consultation</li>
          <li><strong>Health Impact Assessments:</strong> Evaluating potential health effects</li>
          <li><strong>Remediation Efforts:</strong> Cleaning up legacy pollution</li>
          <li><strong>Green Infrastructure:</strong> Creating local environmental benefits</li>
        </ul>

        <h3>Renewable Energy and Environmental Justice</h3>
        <p>While renewable energy is generally cleaner, we must still consider:</p>
        <ul>
          <li>Land use impacts of large renewable projects</li>
          <li>Mining impacts for renewable energy materials</li>
          <li>Waste management for solar panels and wind turbines</li>
          <li>Ensuring local communities benefit from nearby projects</li>
        </ul>
      `,
      type: "lesson",
      orderIndex: 2,
      duration: 45,
      isAvailable: true,
    });

    // Add Career Pathways and Skills Module
    await storage.createModule({
      id: "jet-module-6",
      courseId: course.id,
      sectionId: section3.id,
      title: "Career Pathways in Renewable Energy",
      description: "Exploring job opportunities and required skills in the growing renewable energy sector.",
      content: `
        <div class="module-header">
          <h1>Career Pathways in Renewable Energy</h1>
          <p class="module-intro">The renewable energy sector offers diverse career opportunities across technical, business, and policy domains. This module explores pathways to build a successful career in green energy.</p>
        </div>

        <section class="content-section">
          <h2>🚀 The Green Jobs Revolution</h2>
          <div class="jobs-stats">
            <div class="stat-highlight">
              <span class="big-number">13.7M</span>
              <span class="stat-desc">Global renewable energy jobs in 2022</span>
            </div>
            <div class="stat-highlight">
              <span class="big-number">38M</span>
              <span class="stat-desc">Projected jobs by 2030</span>
            </div>
            <div class="stat-highlight">
              <span class="big-number">5.5M</span>
              <span class="stat-desc">Potential jobs in Africa</span>
            </div>
          </div>

          <h2>💼 Career Categories</h2>
          <div class="career-paths">
            <div class="career-category">
              <h3>🔧 Technical & Engineering</h3>
              <div class="jobs-list">
                <div class="job-item">
                  <h4>Solar PV Technician</h4>
                  <p>Install, maintain, and repair solar systems</p>
                  <span class="salary">$25,000 - $45,000</span>
                  <span class="demand high">High Demand</span>
                </div>
                <div class="job-item">
                  <h4>Wind Turbine Technician</h4>
                  <p>Service and maintain wind energy equipment</p>
                  <span class="salary">$30,000 - $55,000</span>
                  <span class="demand high">High Demand</span>
                </div>
                <div class="job-item">
                  <h4>Energy Systems Engineer</h4>
                  <p>Design and optimize renewable energy systems</p>
                  <span class="salary">$45,000 - $85,000</span>
                  <span class="demand growing">Growing</span>
                </div>
              </div>
            </div>

            <div class="career-category">
              <h3>📊 Business & Finance</h3>
              <div class="jobs-list">
                <div class="job-item">
                  <h4>Project Developer</h4>
                  <p>Identify and develop renewable energy projects</p>
                  <span class="salary">$40,000 - $80,000</span>
                  <span class="demand high">High Demand</span>
                </div>
                <div class="job-item">
                  <h4>Green Finance Specialist</h4>
                  <p>Structure financing for clean energy projects</p>
                  <span class="salary">$45,000 - $95,000</span>
                  <span class="demand growing">Growing</span>
                </div>
              </div>
            </div>

            <div class="career-category">
              <h3>🏛️ Policy & Community</h3>
              <div class="jobs-list">
                <div class="job-item">
                  <h4>Energy Policy Analyst</h4>
                  <p>Research and develop energy policies</p>
                  <span class="salary">$35,000 - $70,000</span>
                  <span class="demand medium">Medium Demand</span>
                </div>
                <div class="job-item">
                  <h4>Community Engagement Officer</h4>
                  <p>Facilitate community participation in projects</p>
                  <span class="salary">$28,000 - $50,000</span>
                  <span class="demand high">High Demand</span>
                </div>
              </div>
            </div>
          </div>

          <h2>🎓 Skills Development Framework</h2>
          <div class="skills-framework">
            <div class="skill-category">
              <h3>Technical Skills</h3>
              <ul>
                <li>Renewable energy technologies</li>
                <li>Energy efficiency principles</li>
                <li>Grid integration and storage</li>
                <li>Environmental monitoring</li>
                <li>Data analysis and modeling</li>
              </ul>
            </div>
            <div class="skill-category">
              <h3>Soft Skills</h3>
              <ul>
                <li>Communication and presentation</li>
                <li>Stakeholder engagement</li>
                <li>Cross-cultural competence</li>
                <li>Problem-solving and innovation</li>
                <li>Leadership and teamwork</li>
              </ul>
            </div>
            <div class="skill-category">
              <h3>Digital Skills</h3>
              <ul>
                <li>Energy modeling software</li>
                <li>GIS and mapping tools</li>
                <li>Project management platforms</li>
                <li>Financial modeling</li>
                <li>Data visualization</li>
              </ul>
            </div>
          </div>

          <div class="action-box">
            <h4>🎯 Career Planning Exercise</h4>
            <p>Identify your interests and skills. Which career pathway appeals to you most? What skills do you need to develop? Create a personal development plan.</p>
          </div>
        </section>
      `,
      type: "lesson",
      orderIndex: 2,
      duration: 45,
      isAvailable: true,
    });

    await storage.createModule({
      id: "jet-module-5",
      courseId: course.id,
      sectionId: section3.id,
      title: "South African JET Partnership Case Study",
      description: "Examining South Africa's comprehensive approach to just energy transition through international partnership and the REIPPPP success story.",
      content: `
        <div class="module-header">
          <h1>South African Just Energy Transition Partnership</h1>
          <p class="module-intro">South Africa's JET Partnership, announced at COP26, represents one of the world's most significant just energy transition initiatives, building on the success of the REIPPPP program.</p>
        </div>

        <section class="content-section">
          <h2>🏭 Background: South Africa's Energy Landscape</h2>
          <div class="context-grid">
            <div class="challenge-box">
              <h3>⚠️ Key Challenges</h3>
              <ul>
                <li><strong>Coal Dependency:</strong> 80% of electricity from coal</li>
                <li><strong>Aging Infrastructure:</strong> Eskom's fleet averaging 35+ years</li>
                <li><strong>Load Shedding:</strong> Rolling blackouts affecting economy</li>
                <li><strong>High Unemployment:</strong> 29% unemployment rate</li>
                <li><strong>Energy Poverty:</strong> 3.8 million households without electricity</li>
                <li><strong>Climate Impact:</strong> World's 14th largest CO2 emitter</li>
              </ul>
            </div>
            <div class="opportunity-box">
              <h3>✨ Opportunities</h3>
              <ul>
                <li><strong>Renewable Potential:</strong> World-class solar and wind resources</li>
                <li><strong>REIPPPP Success:</strong> Proven procurement model</li>
                <li><strong>Skills Base:</strong> Engineering and technical expertise</li>
                <li><strong>Industrial Base:</strong> Manufacturing capabilities</li>
                <li><strong>Strategic Location:</strong> Gateway to African markets</li>
              </ul>
            </div>
          </div>

          <h2>🤝 The JET Partnership Structure</h2>
          <div class="partnership-details">
            <div class="funding-breakdown">
              <h3>💰 $8.5 Billion Funding Package</h3>
              <div class="funding-grid">
                <div class="funding-item">
                  <span class="amount">$3.5B</span>
                  <span class="type">Grants</span>
                </div>
                <div class="funding-item">
                  <span class="amount">$5.0B</span>
                  <span class="type">Concessional Loans</span>
                </div>
              </div>
              
              <h4>International Partners:</h4>
              <ul>
                <li>🇺🇸 United States</li>
                <li>🇬🇧 United Kingdom</li>
                <li>🇪🇺 European Union</li>
                <li>🇩🇪 Germany</li>
                <li>🇫🇷 France</li>
              </ul>
            </div>
          </div>

          <h3>🎯 Key Focus Areas</h3>
          <div class="focus-areas">
            <div class="focus-card">
              <h4>⚡ Power Sector Transformation</h4>
              <ul>
                <li>Accelerate renewable energy deployment</li>
                <li>Modernize grid infrastructure</li>
                <li>Phase down coal power plants</li>
                <li>Improve energy access</li>
              </ul>
            </div>
            <div class="focus-card">
              <h4>💼 Just Transition Support</h4>
              <ul>
                <li>Worker retraining programs</li>
                <li>Community development initiatives</li>
                <li>Economic diversification in coal regions</li>
                <li>Social protection measures</li>
              </ul>
            </div>
            <div class="focus-card">
              <h4>🔋 Green Economy Development</h4>
              <ul>
                <li>Green hydrogen production</li>
                <li>Electric vehicle manufacturing</li>
                <li>Critical minerals processing</li>
                <li>Green finance mechanisms</li>
              </ul>
            </div>
          </div>

          <h2>📈 REIPPPP: The Foundation Success</h2>
          <div class="reipppp-success">
            <h3>🏆 Program Achievements (2011-2018)</h3>
            <div class="achievements-grid">
              <div class="achievement">
                <span class="number">6,200MW</span>
                <span class="label">Renewable Capacity</span>
              </div>
              <div class="achievement">
                <span class="number">R194B</span>
                <span class="label">Investment Attracted</span>
              </div>
              <div class="achievement">
                <span class="number">40,000+</span>
                <span class="label">Construction Jobs</span>
              </div>
              <div class="achievement">
                <span class="number">70%</span>
                <span class="label">Solar Cost Reduction</span>
              </div>
            </div>

            <h4>📊 Bid Window Results</h4>
            <table class="results-table">
              <thead>
                <tr>
                  <th>Bid Window</th>
                  <th>Year</th>
                  <th>Capacity (MW)</th>
                  <th>Investment (R Billion)</th>
                  <th>Average Tariff</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>BW1</td>
                  <td>2011</td>
                  <td>1,416</td>
                  <td>47</td>
                  <td>R2.40/kWh</td>
                </tr>
                <tr>
                  <td>BW2</td>
                  <td>2012</td>
                  <td>1,363</td>
                  <td>43</td>
                  <td>R1.85/kWh</td>
                </tr>
                <tr>
                  <td>BW3</td>
                  <td>2013</td>
                  <td>1,473</td>
                  <td>58</td>
                  <td>R1.25/kWh</td>
                </tr>
                <tr>
                  <td>BW4</td>
                  <td>2014</td>
                  <td>1,980</td>
                  <td>62</td>
                  <td>R0.87/kWh</td>
                </tr>
              </tbody>
            </table>
          </div>

          <h2>🚧 Implementation Challenges</h2>
          <div class="challenges-section">
            <div class="challenge-category">
              <h3>🏛️ Governance Challenges</h3>
              <ul>
                <li>Coordinating multiple government departments</li>
                <li>Aligning national and provincial priorities</li>
                <li>Managing stakeholder expectations</li>
                <li>Ensuring transparent implementation</li>
              </ul>
            </div>
            <div class="challenge-category">
              <h3>💰 Financial Challenges</h3>
              <ul>
                <li>Currency risk management</li>
                <li>Blending different funding sources</li>
                <li>Ensuring additionality of finance</li>
                <li>Managing debt sustainability</li>
              </ul>
            </div>
            <div class="challenge-category">
              <h3>👥 Social Challenges</h3>
              <ul>
                <li>Managing job losses in coal sector</li>
                <li>Ensuring community participation</li>
                <li>Addressing inequality concerns</li>
                <li>Building public support</li>
              </ul>
            </div>
          </div>

          <h2>🌍 Lessons for Africa</h2>
          <div class="lessons-section">
            <div class="lesson-card">
              <h3>✅ Success Factors</h3>
              <ul>
                <li><strong>Clear Policy Framework:</strong> Strong government commitment</li>
                <li><strong>International Partnerships:</strong> Leveraging global support</li>
                <li><strong>Proven Track Record:</strong> REIPPPP credibility</li>
                <li><strong>Just Transition Focus:</strong> Social considerations upfront</li>
              </ul>
            </div>
            <div class="lesson-card">
              <h3>⚠️ Risk Mitigation</h3>
              <ul>
                <li><strong>Stakeholder Buy-in:</strong> Early and continuous engagement</li>
                <li><strong>Institutional Capacity:</strong> Strong project management</li>
                <li><strong>Financial Planning:</strong> Sustainable funding models</li>
                <li><strong>Political Continuity:</strong> Cross-party consensus</li>
              </ul>
            </div>
          </div>

          <div class="action-box">
            <h4>🎯 Discussion Question</h4>
            <p>How could other African countries adapt South Africa's JET Partnership model to their specific contexts? What elements would be most important to replicate, and what would need to be different?</p>
          </div>
        </section>
      `,
      type: "lesson",
      orderIndex: 1,
      duration: 60,
      isAvailable: true,
    });
    }

    console.log("Database seeded successfully with simplified course structure!");

  } catch (error) {
    console.error("Error seeding database:", error);
  }
}

// Run seeding if this file is executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  seedDatabase().then(() => {
    console.log("Seeding completed");
    process.exit(0);
  }).catch((error) => {
    console.error("Seeding failed:", error);
    process.exit(1);
  });
}