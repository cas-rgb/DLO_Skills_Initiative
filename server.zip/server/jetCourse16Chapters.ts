// Comprehensive 16-Chapter JET 101 Course Structure - Harvard-Level Quality
export const jetCourse16Chapters = [
  {
    id: "chapter-1",
    title: "Chapter 1: Understanding Energy and Society",
    order: 1,
    duration: "45 minutes",
    points: 100,
    badge: "Energy Foundation",
    content: `
# Chapter 1: Understanding Energy and Society

## Learning Objectives
By the end of this chapter, you will be able to:
- Define energy and its fundamental role in society
- Identify different energy sources and their characteristics
- Explain the relationship between energy access and development
- Analyze energy consumption patterns in African contexts

## What is Energy?
Energy is the capacity to do work - to power our homes, run our industries, and fuel our transportation. It's the foundation of modern civilization and economic development.

### Types of Energy Sources:

**Primary Energy Sources:**
- **Fossil Fuels**: Coal, oil, natural gas
- **Renewable Sources**: Solar, wind, hydro, biomass, geothermal
- **Nuclear**: Uranium-based nuclear fission

**Secondary Energy Forms:**
- Electricity
- Heat
- Mechanical energy

## Energy and Development
Access to reliable, affordable energy is crucial for:
- Economic growth and job creation
- Health and education services
- Food security and agriculture
- Communication and connectivity

### African Context
Africa has abundant energy resources but faces significant energy poverty:
- 600 million Africans lack access to electricity
- 900 million rely on traditional biomass for cooking
- Massive potential for renewable energy development

## Case Study: Energy Access in Rural Kenya
The M-KOPA solar program has provided clean energy access to over 1 million homes in Kenya, demonstrating how innovative financing can unlock energy access.

## Interactive Elements
- Energy consumption calculator
- Photo comparison: Villages with/without electricity access
- Interactive map of African energy resources

## Assessment Questions
1. What are the three main categories of primary energy sources?
2. How does energy access impact economic development?
3. What are the main energy challenges facing Africa today?
    `,
    videoUrl: "https://www.youtube.com/embed/Toxic_Cost_of_Going_Green",
    interactiveElements: [
      {
        type: "calculator",
        title: "Personal Energy Footprint Calculator",
        description: "Calculate your daily energy consumption"
      },
      {
        type: "quiz",
        title: "Energy Basics Quiz",
        questions: 5
      }
    ]
  },
  {
    id: "chapter-2", 
    title: "Chapter 2: The Climate Crisis and Energy Systems",
    order: 2,
    duration: "50 minutes",
    points: 120,
    badge: "Climate Aware",
    content: `
# Chapter 2: The Climate Crisis and Energy Systems

## Learning Objectives
- Understand the greenhouse effect and climate change
- Analyze the role of energy systems in climate change
- Evaluate climate impacts on African communities
- Identify mitigation and adaptation strategies

## The Greenhouse Effect
The greenhouse effect is a natural process where certain gases in Earth's atmosphere trap heat from the sun, keeping our planet warm enough to support life.

### Greenhouse Gases:
- Carbon Dioxide (CO₂) - 76% of emissions
- Methane (CH₄) - 16% of emissions  
- Nitrous Oxide (N₂O) - 6% of emissions
- Fluorinated gases - 2% of emissions

## Energy's Role in Climate Change
Energy production and use account for about 75% of global greenhouse gas emissions:
- Burning fossil fuels releases stored carbon
- Deforestation reduces carbon absorption
- Industrial processes emit various greenhouse gases

## Climate Impacts in Africa
Africa contributes only 4% of global emissions but faces disproportionate impacts:
- Rising temperatures and changing rainfall patterns
- Droughts and desertification
- Coastal erosion and sea-level rise
- Food and water insecurity

### Case Study: Cape Town Water Crisis
Cape Town's "Day Zero" water crisis (2017-2018) showed how climate change can threaten major African cities. Energy-intensive desalination became necessary to avoid complete water depletion.

## Solutions and Opportunities
**Mitigation** (reducing emissions):
- Transition to renewable energy
- Improve energy efficiency
- Develop carbon capture technologies

**Adaptation** (adjusting to impacts):
- Climate-resilient infrastructure
- Drought-resistant agriculture
- Early warning systems

## Africa's Renewable Energy Potential
- Solar: 10 TW potential (world-class solar resources)
- Wind: 110 GW potential 
- Hydro: 350 GW potential
- Geothermal: 15 GW potential (Great Rift Valley)

## Interactive Elements
- Climate change simulator
- Carbon footprint calculator
- African climate impact map
    `,
    videoUrl: null,
    interactiveElements: [
      {
        type: "simulator", 
        title: "Climate Change Impact Simulator",
        description: "See how different emission scenarios affect temperature"
      },
      {
        type: "map",
        title: "African Climate Impacts Map", 
        description: "Explore climate impacts across the continent"
      }
    ]
  },
  {
    id: "chapter-3",
    title: "Chapter 3: Introduction to Just Energy Transition",
    order: 3,
    duration: "55 minutes", 
    points: 150,
    badge: "JET Pioneer",
    content: `
# Chapter 3: Introduction to Just Energy Transition

## Learning Objectives
- Define Just Energy Transition (JET)
- Understand the five pillars of JET
- Analyze why "justice" is central to energy transition
- Evaluate JET principles in African contexts

## What is Just Energy Transition?
Just Energy Transition (JET) is a framework ensuring that the shift to clean energy is fair, inclusive, and leaves no one behind. It recognizes that energy transition must address social, economic, and environmental justice simultaneously.

## The Five Pillars of JET

### 1. Equitable Access to Clean Energy
- Universal access to electricity and clean cooking
- Affordable energy services for all income levels
- Priority for underserved communities
- Gender-responsive energy solutions

### 2. Environmental Justice
- Protecting communities from pollution and environmental harm
- Ensuring environmental benefits reach all communities
- Preventing environmental racism and discrimination
- Sustainable resource management

### 3. Job Creation and Workforce Transition
- Creating new green jobs in renewable energy sectors
- Retraining workers from fossil fuel industries
- Supporting local economic development
- Building local capacity and skills

### 4. Reducing Inequalities
- Addressing energy poverty
- Ensuring equal participation in energy decisions
- Promoting inclusive economic benefits
- Supporting vulnerable communities

### 5. Community Involvement and Participation
- Meaningful consultation with affected communities
- Local ownership of energy projects
- Cultural sensitivity and respect
- Transparent decision-making processes

## Why Justice Matters in Energy Transition
Without justice considerations, energy transitions can:
- Exclude marginalized communities
- Concentrate benefits among the wealthy
- Destroy local livelihoods
- Ignore cultural and social impacts
- Create new forms of inequality

## JET in the African Context
Africa's JET must address unique challenges:
- High energy poverty rates
- Rural-urban energy divides
- Gender inequalities in energy access
- Limited financial resources
- Need for rapid economic development

### Success Story: Morocco's Noor Solar Complex
Morocco's Noor Solar Complex demonstrates JET principles:
- Local job creation (2000+ jobs during construction)
- Skills development programs for local communities
- Women's participation in technical roles
- Environmental protection measures
- Community benefit programs

## Global JET Initiatives
- **South Africa's JET Partnership**: $8.5 billion international support
- **Indonesia's JET Partnership**: Focus on coal transition
- **Just Transition Fund (EU)**: €150 billion for fair transitions
- **Climate Investment Funds**: Supporting developing country transitions

## Interactive Exercise: JET Assessment Tool
Evaluate energy projects using JET criteria:
1. Does it improve equitable access?
2. Does it protect the environment?
3. Does it create quality jobs?
4. Does it reduce inequalities?
5. Does it involve communities meaningfully?
    `,
    videoUrl: null,
    interactiveElements: [
      {
        type: "assessment_tool",
        title: "JET Project Assessment Tool",
        description: "Evaluate real projects using JET criteria"
      },
      {
        type: "case_study",
        title: "Morocco Noor Solar Deep Dive",
        description: "Analyze how JET principles were applied"
      }
    ]
  },
  {
    id: "chapter-4",
    title: "Chapter 4: Energy Poverty and Access Challenges", 
    order: 4,
    duration: "50 minutes",
    points: 130,
    badge: "Access Champion",
    content: `
# Chapter 4: Energy Poverty and Access Challenges

## Learning Objectives
- Define energy poverty and its dimensions
- Analyze barriers to energy access in Africa
- Understand gender dimensions of energy poverty
- Evaluate solutions for expanding energy access

## Understanding Energy Poverty
Energy poverty exists when people cannot access adequate, reliable, safe, and affordable energy services to meet their basic needs.

### Dimensions of Energy Poverty:
1. **Physical Access**: Availability of energy infrastructure
2. **Economic Access**: Affordability of energy services
3. **Reliability**: Consistent energy supply
4. **Safety**: Safe energy technologies and practices
5. **Quality**: Adequate energy for all needs

## Global Energy Access Statistics
- 733 million people lack access to electricity globally
- 2.4 billion people lack access to clean cooking
- Sub-Saharan Africa accounts for 70% of the global access deficit

### African Energy Access Challenges
- **Electrification Rate**: 48% (2020), ranging from 8% to 100% by country
- **Urban vs Rural**: 78% urban access vs 28% rural access
- **Clean Cooking**: Only 17% have access to clean cooking solutions
- **Reliability**: Frequent power outages even where electricity exists

## Barriers to Energy Access

### Technical Barriers
- Inadequate infrastructure
- Geographic challenges (remote/dispersed populations)
- Limited grid extension
- Poor maintenance systems

### Financial Barriers
- High upfront costs
- Limited access to credit
- Inadequate subsidies or financing mechanisms
- Low purchasing power

### Institutional Barriers
- Weak governance structures
- Inadequate regulatory frameworks
- Corruption and mismanagement
- Limited technical capacity

### Social Barriers
- Gender inequality
- Cultural practices
- Limited awareness and education
- Resistance to new technologies

## Gender Dimensions of Energy Poverty
Women and girls are disproportionately affected by energy poverty:

### Impacts on Women:
- **Time burden**: Collecting firewood takes 2-4 hours daily
- **Health impacts**: Indoor air pollution from cooking fires
- **Economic limitations**: Limited income-generating opportunities
- **Education impacts**: Girls missing school to collect fuel
- **Safety risks**: Violence when collecting fuel in remote areas

### Women as Energy Leaders:
- Often make household energy decisions
- Strong advocates for clean energy adoption
- Leaders in community energy initiatives
- Entrepreneurs in energy access solutions

## Solutions and Innovations

### Grid Extension and Densification
- National electrification programs
- Regional power pools and trading
- Smart grid technologies
- Mini-grid development

### Off-Grid Solutions
- Solar home systems
- Pay-as-you-go (PAYG) models
- Mini and micro-grids
- Improved cookstoves

### Financing Innovations
- Mobile money integration
- Microfinance for energy access
- Results-based financing
- Carbon finance mechanisms

### Case Study: M-KOPA Solar (Kenya)
M-KOPA's pay-as-you-go solar systems have:
- Connected over 1 million homes
- Created 1000+ direct jobs
- Enabled customers to save $120/year on energy costs
- Demonstrated successful mobile money integration

## Policy Solutions
- Energy access targets and monitoring
- Subsidies and cross-subsidization
- Rural electrification agencies
- Gender-inclusive energy policies
- Productive use promotion
    `,
    videoUrl: null,
    interactiveElements: [
      {
        type: "data_visualization",
        title: "African Energy Access Dashboard",
        description: "Explore energy access data across Africa"
      },
      {
        type: "cost_calculator",
        title: "Energy Solution Cost Comparison",
        description: "Compare costs of different energy access solutions"
      }
    ]
  },
  {
    id: "chapter-5",
    title: "Chapter 5: Renewable Energy Technologies",
    order: 5,
    duration: "60 minutes",
    points: 140,
    badge: "Tech Innovator",
    content: `
# Chapter 5: Renewable Energy Technologies

## Learning Objectives
- Understand major renewable energy technologies
- Analyze technology suitability for African conditions
- Evaluate costs and benefits of different technologies
- Explore emerging renewable energy innovations

## Solar Energy

### Solar Photovoltaic (PV)
**How it works**: Converts sunlight directly into electricity using semiconductor cells

**Types of Solar PV**:
- **Monocrystalline**: 18-22% efficiency, higher cost
- **Polycrystalline**: 15-18% efficiency, moderate cost  
- **Thin-film**: 10-13% efficiency, lower cost, flexible

**African Solar Potential**:
- Best solar resources globally (Northern and Southern Africa)
- 10,000 GW technical potential
- Solar irradiance 1,500-3,000 kWh/m²/year

### Concentrated Solar Power (CSP)
**How it works**: Uses mirrors to concentrate sunlight to generate heat for electricity production

**Technologies**:
- Parabolic trough systems
- Solar power towers
- Dish/engine systems
- Linear Fresnel reflectors

**African CSP Projects**:
- Morocco's Noor Complex (580 MW)
- South Africa's Redstone Project (100 MW)

## Wind Energy

### Wind Turbine Technology
**Components**:
- Rotor blades (capture wind energy)
- Nacelle (contains gearbox and generator)
- Tower (elevates turbine for better wind access)

**Types**:
- **Onshore Wind**: Land-based installations
- **Offshore Wind**: Ocean-based installations (higher speeds, more consistent)

### African Wind Potential
- 110 GW technical potential
- Best resources: North Africa, Horn of Africa, Southern Africa
- Capacity factors 20-60% depending on location

**Success Story**: Lake Turkana Wind Power (Kenya)
- 365 MW capacity (largest in Africa)
- 310 days/year average wind availability
- Powers 1 million Kenyan homes

## Hydroelectric Power

### Technology Types
**Large Hydro** (>100 MW):
- Dam-based systems
- Pumped storage
- High capacity factors (40-60%)

**Small Hydro** (<10 MW):
- Run-of-river systems
- Micro-hydro for rural communities
- Less environmental impact

### African Hydro Potential
- 350 GW technical potential
- Only 11% currently utilized
- Major projects: Grand Ethiopian Renaissance Dam, Inga Falls (DRC)

## Geothermal Energy

### How Geothermal Works
Uses heat from Earth's interior to generate electricity or provide direct heating

**Types**:
- **Dry Steam**: Direct steam from underground
- **Flash Steam**: Hot water converted to steam
- **Binary Cycle**: Heat transfer fluid systems

### African Geothermal Potential
- 15 GW potential along East African Rift
- Countries with major potential: Kenya, Ethiopia, Tanzania, Uganda
- Kenya generates 45% of electricity from geothermal

## Biomass and Bioenergy

### Biomass Sources
- Agricultural residues
- Forest residues  
- Energy crops
- Organic waste
- Animal waste

### Technologies
- **Direct Combustion**: Burning biomass for heat/electricity
- **Gasification**: Converting biomass to syngas
- **Pyrolysis**: Thermal decomposition without oxygen
- **Anaerobic Digestion**: Biogas from organic waste

### African Biomass Potential
- Abundant agricultural and forest residues
- High population growth = more organic waste
- Opportunity for rural job creation

## Ocean Energy (Emerging)

### Wave Energy
Captures energy from surface waves
- Limited deployment in Africa but high potential along coasts

### Tidal Energy
Uses rise and fall of tides
- Predictable but limited suitable sites in Africa

## Technology Selection Criteria

### Resource Assessment
- Solar irradiance levels
- Wind speed and consistency
- Water flow availability
- Geothermal gradients

### Technical Factors
- Grid integration requirements
- Energy storage needs
- Maintenance requirements
- Technology maturity

### Economic Factors
- Capital costs (CAPEX)
- Operating costs (OPEX)
- Levelized cost of electricity (LCOE)
- Financing availability

### Social and Environmental Factors
- Community acceptance
- Environmental impacts
- Land use requirements
- Local job creation potential

## Technology Costs Trends
Global renewable energy costs have declined dramatically:
- Solar PV: 85% cost reduction (2010-2020)
- Onshore wind: 70% cost reduction
- Offshore wind: 48% cost reduction
- Hydropower: 20% cost reduction

## Emerging Technologies
- **Floating Solar**: PV systems on water bodies
- **Agrivoltaics**: Solar panels over agricultural land
- **Perovskite Solar Cells**: Next-generation high-efficiency PV
- **Floating Wind**: Offshore wind in deeper waters
- **Green Hydrogen**: Renewable electricity to produce hydrogen fuel
    `,
    videoUrl: null,
    interactiveElements: [
      {
        type: "technology_comparison",
        title: "Renewable Energy Technology Comparison Tool",
        description: "Compare technologies for your specific location and needs"
      },
      {
        type: "resource_map", 
        title: "African Renewable Energy Resource Map",
        description: "Explore renewable energy potential across Africa"
      },
      {
        type: "cost_calculator",
        title: "LCOE Calculator",
        description: "Calculate levelized cost of electricity for different technologies"
      }
    ]
  },
  {
    id: "chapter-6",
    title: "Chapter 6: South Africa's Energy Landscape",
    order: 6,
    duration: "55 minutes",
    points: 135,
    badge: "SA Energy Expert",
    content: `
# Chapter 6: South Africa's Energy Landscape

## Learning Objectives
- Analyze South Africa's current energy mix and challenges
- Understand the role of Eskom in the energy system
- Evaluate the Renewable Energy Independent Power Producer Programme (REIPPPP)
- Assess energy policy developments and reforms

## South Africa's Energy Profile
South Africa is Africa's most industrialized economy and largest energy consumer, facing significant energy challenges that offer lessons for the continent.

### Current Energy Mix (2023):
- **Coal**: 69% of electricity generation
- **Nuclear**: 5% (Koeberg Power Station)
- **Renewable Energy**: 14% (hydro, solar, wind)
- **Gas/Diesel**: 8% (peaking power)
- **Other**: 4%

### Key Energy Statistics:
- Total installed capacity: 58,095 MW
- Electricity access rate: 84% national (95% urban, 72% rural)
- Per capita electricity consumption: 4,198 kWh/year
- Energy intensity: High due to mining and heavy industry

## Historical Context: Apartheid's Energy Legacy
South Africa's energy system reflects historical inequalities:
- Cheap electricity for white-owned mines and industries
- Limited access for black townships and rural areas
- Coal-dependent infrastructure built for resource extraction
- Centralized system designed to serve privileged areas

## Eskom: The State Utility Giant
Eskom is one of the world's largest power utilities, generating 95% of South Africa's electricity and 45% of Africa's electricity.

### Eskom's Challenges:
1. **Aging Infrastructure**: Coal plants built 1970s-1980s requiring maintenance
2. **Financial Crisis**: R396 billion debt (2023), requiring government bailouts
3. **Load Shedding**: Rolling blackouts affecting economic growth
4. **Corruption and Mismanagement**: State capture scandal, cost overruns
5. **Just Energy Transition**: Pressure to decarbonize coal-dependent system

### Load Shedding Impact:
- Economic losses: R500 billion+ since 2008
- Business closures and job losses
- Reduced investment confidence
- Social and health impacts

## Renewable Energy Independent Power Producer Programme (REIPPPP)
Launched in 2011, REIPPPP has been Africa's most successful renewable energy programme.

### Programme Achievements:
- **Capacity Procured**: 6,380 MW across 5 bid rounds
- **Investment Attracted**: R209 billion in foreign and domestic investment
- **Job Creation**: 40,000+ jobs during construction, 1,000+ permanent jobs
- **Cost Reduction**: 70% decline in solar and wind tariffs
- **Local Content**: Significant localization requirements

### Bid Rounds Overview:
1. **Round 1-2 (2011-2012)**: Established market, higher prices
2. **Round 3-4 (2013-2014)**: Dramatic price reductions, increased competition
3. **Round 4.5 (2021)**: Resumed after delays, record low prices
4. **Round 5-6 (2022-2023)**: Focus on grid stability and energy security

### REIPPPP Success Factors:
- Competitive bidding process
- Strong regulatory framework
- Development finance institution support
- Local content requirements
- Community ownership provisions

## Energy Policy Framework

### Key Policy Documents:
1. **National Energy Act (2008)**: Established energy planning framework
2. **Integrated Energy Plan (IEP)**: Long-term energy planning document
3. **Integrated Resource Plan (IRP 2019)**: Electricity capacity planning
4. **Just Energy Transition Investment Plan**: R1.5 trillion transition roadmap

### IRP 2019 Capacity Plan (2030):
- Decommission 11,000 MW of old coal plants
- Add 18,000 MW of solar PV
- Add 14,400 MW of wind
- Add 2,500 MW of hydro
- Add 8,100 MW of gas
- Build 2,500 MW of battery storage

## Just Energy Transition Partnership
In 2021, South Africa secured an $8.5 billion Just Energy Transition Partnership with international partners (US, UK, EU, Germany, France).

### Partnership Objectives:
- Accelerate decarbonization of electricity system
- Support affected workers and communities
- Develop green hydrogen economy
- Build electric vehicle manufacturing

### Implementation Challenges:
- Coordination between multiple stakeholders
- Ensuring benefits reach affected communities
- Managing political and economic pressures
- Technical capacity for rapid transition

## Coal Mining Communities and Just Transition
South Africa has significant coal mining regions facing transition challenges:

### Mpumalanga Province:
- 90% of South Africa's coal production
- High unemployment and poverty
- Air pollution and health impacts
- Economic dependence on coal value chain

### Just Transition Initiatives:
- **Mpumalanga Economic Growth and Development Path**: Diversification strategy
- **Komati Power Station Transition**: Converting old coal plant to renewables hub
- **Skills Development Programs**: Retraining coal workers
- **Community Development**: Alternative livelihood programs

## Energy Access Challenges
Despite progress, energy access remains uneven:

### Urban vs Rural Access:
- Urban areas: 95% electricity access
- Rural areas: 72% electricity access
- Quality and reliability issues persist

### Energy Poverty:
- 3.5 million households without electricity
- 13 million people use unsafe cooking fuels
- Electricity costs consume 15-20% of household income

### Off-Grid Solutions:
- Solar home systems in rural areas
- Mini-grids for remote communities
- Improved cookstoves programs
- Community energy cooperatives

## Industrial Energy Users and Efficiency
Large industrial users consume 60% of South Africa's electricity:

### Major Energy Users:
- Mining (gold, platinum, coal): 15% of total consumption
- Steel and aluminum smelting: 20% of consumption
- Chemical and petrochemical: 10% of consumption

### Energy Efficiency Programs:
- 12L Energy Efficiency Tax Incentive
- Standard Offer Programme for demand response
- Industrial Energy Efficiency Private Financing Programme

## Future Outlook: Opportunities and Challenges

### Opportunities:
- World-class renewable energy resources
- Established manufacturing base
- Strong financial and legal systems
- Regional energy hub potential
- Green hydrogen export opportunities

### Challenges:
- Financing the energy transition (R1.5 trillion required)
- Managing social impacts of transition
- Building technical and institutional capacity
- Ensuring energy security during transition
- Addressing spatial inequalities

## Case Study: Komati Power Station Repurposing
Komati, South Africa's oldest coal power station, is being transformed into a renewables hub:
- 140 MW of solar and battery storage
- Skills development for former coal workers
- Industrial development zone for green technologies
- Community benefit programs
- Model for other coal plant transitions

## Regional Leadership Role
South Africa's energy transition has continental implications:
- Technology and financing models for other African countries
- Regional power trade through Southern African Power Pool
- South-South cooperation and knowledge sharing
- Industrial development and value chain integration
    `,
    videoUrl: "https://www.youtube.com/embed/Toxic_Cost_of_Going_Green",
    interactiveElements: [
      {
        type: "timeline",
        title: "South Africa Energy Policy Timeline",
        description: "Interactive timeline of key energy policy milestones"
      },
      {
        type: "map",
        title: "REIPPPP Projects Map",
        description: "Explore renewable energy projects across South Africa"
      }
    ]
  },
  {
    id: "chapter-7",
    title: "Chapter 7: Energy Value Chains and Economics",
    order: 7,
    duration: "50 minutes",
    points: 125,
    badge: "Value Chain Analyst",
    content: `
# Chapter 7: Energy Value Chains and Economics

## Learning Objectives
- Understand energy value chain components and relationships
- Compare coal and renewable energy value chains
- Analyze economic impacts of different energy systems
- Evaluate job creation potential across energy sectors

## What is an Energy Value Chain?
An energy value chain encompasses all activities from resource extraction to end-use consumption, including the supporting industries and services.

### Generic Energy Value Chain Stages:
1. **Resource Extraction/Harvesting**
2. **Processing/Conversion**
3. **Transportation/Transmission**
4. **Distribution**
5. **End-Use Consumption**
6. **Waste Management/Recycling**

## Coal Value Chain Analysis

### Upstream (Resource Extraction):
**Activities:**
- Geological surveying and exploration
- Mine development and construction
- Coal extraction (surface and underground mining)
- Primary processing and washing

**Key Players:**
- Mining companies (Anglo American, Sasol, Glencore)
- Equipment suppliers (Caterpillar, Komatsu)
- Engineering firms (AECOM, Worley)

**Employment:** 80,000+ direct jobs in South Africa

### Midstream (Processing and Transportation):
**Activities:**
- Coal beneficiation and upgrading
- Transportation (rail, road, conveyor)
- Port handling and export
- Storage and stockyarding

**Key Infrastructure:**
- Transnet Freight Rail coal lines
- Richards Bay Coal Terminal (world's largest coal export terminal)
- Coal-fired power stations

**Employment:** 30,000+ jobs in transport and logistics

### Downstream (Conversion and Distribution):
**Activities:**
- Electricity generation at coal power plants
- Transmission via high-voltage grid
- Distribution to end users
- Retail electricity sales

**Key Players:**
- Eskom (dominant generator and grid operator)
- Municipalities (distribution)
- Independent power producers

**Employment:** 45,000+ jobs in power generation and grid operations

### Coal Value Chain Characteristics:
- **Capital Intensive**: High upfront investment in mines and plants
- **Labor Intensive**: Significant employment in mining operations
- **Geographically Concentrated**: Mpumalanga coal belt
- **Export Oriented**: 30% of production exported
- **Declining Economics**: Stranded asset risks, environmental costs

## Renewable Energy Value Chain Analysis

### Solar PV Value Chain:

**Upstream (Manufacturing):**
- Silicon purification and wafer production
- Solar cell and module manufacturing
- Balance-of-system component production (inverters, mounting systems)

**Midstream (Project Development):**
- Site identification and assessment
- Financing and project development
- Engineering, procurement, construction (EPC)
- Grid connection and commissioning

**Downstream (Operations):**
- Operations and maintenance (O&M)
- Asset management
- Electricity sales and trading
- End-of-life recycling

### Wind Value Chain:

**Upstream (Manufacturing):**
- Turbine component manufacturing (blades, nacelles, towers)
- Raw materials (steel, rare earth elements, composites)
- Specialized equipment and tools

**Midstream (Development and Construction):**
- Wind resource assessment
- Project development and financing
- Installation and commissioning
- Grid integration

**Downstream (Operations):**
- Operations and maintenance
- Performance monitoring
- Grid services provision
- Decommissioning and recycling

### Renewable Energy Value Chain Characteristics:
- **Technology Driven**: Rapid innovation and cost reduction
- **Modular and Scalable**: Can be deployed at various scales
- **Distributed Manufacturing**: Global supply chains
- **Service Intensive**: High-skilled technical jobs
- **Long-term Assets**: 20-25 year operational life

## Economic Impact Comparison

### Job Creation Analysis:

**Jobs per MW of Capacity (Construction Phase):**
- Coal: 5.5 jobs/MW
- Solar PV: 5.2 jobs/MW
- Wind: 4.8 jobs/MW
- Hydro: 7.4 jobs/MW

**Jobs per MW of Capacity (Operations Phase):**
- Coal: 1.1 jobs/MW
- Solar PV: 0.4 jobs/MW
- Wind: 0.2 jobs/MW
- Nuclear: 0.75 jobs/MW

**Job Quality Comparison:**
- **Coal**: Historically well-paid but hazardous, declining sector
- **Renewables**: Growing sector, require higher skills, safer conditions
- **Grid Operations**: Stable employment, require technical skills

### Investment Requirements:

**Capital Costs ($/MW, 2023):**
- Coal: $3,500-5,000/MW (new build)
- Solar PV: $800-1,200/MW
- Onshore Wind: $1,200-1,700/MW
- Nuclear: $6,000-9,000/MW

**Total System Costs:**
Include transmission, distribution, storage, and grid integration costs

### Economic Multiplier Effects:

**Coal Value Chain Multipliers:**
- Direct: $1 spent → $1 output
- Indirect: Additional $0.65 in supplier industries
- Induced: Additional $0.40 in household spending

**Renewable Energy Multipliers:**
- Direct: $1 spent → $1 output
- Indirect: Additional $0.55 in supplier industries (more import-intensive)
- Induced: Additional $0.45 in household spending

## Local Content and Industrialization

### South Africa's Local Content Requirements:
REIPPPP local content thresholds have driven industrial development:

**Solar PV Local Content:**
- Round 1-2: 25% local content
- Round 3-4: 40% local content
- Round 5: 30% local content (adjusted for market realities)

**Wind Local Content:**
- Towers: 100% local manufacturing
- Civil works: 100% local
- Overall: 40-45% local content achieved

### Industrial Development Outcomes:
**Solar Manufacturing:**
- ARTsolar (module assembly)
- Jinko Solar (assembly plant in Cape Town)
- Multiple component manufacturers

**Wind Manufacturing:**
- Nordex (nacelle assembly, Cape Town)
- DCD Wind Towers (tower manufacturing)
- LM Wind Power (blade manufacturing, temporarily closed)

### Challenges for Local Manufacturing:
- Small domestic market size
- Competition from Asian manufacturers
- Skills and technology transfer
- Currency volatility
- Policy uncertainty

## Skills and Human Capital Development

### Traditional Energy Skills (Coal/Grid):
- Mining engineering and geology
- Power systems engineering
- Plant operations and maintenance
- Grid control and dispatch

### Renewable Energy Skills:
- Renewable energy engineering
- Project development and finance
- Data analytics and performance monitoring
- Grid integration and storage systems

### Skills Transition Programs:
**Eskom Academy of Learning:**
- Retraining programs for coal workers
- Renewable energy and grid flexibility courses
- Partnership with universities and technical colleges

**Energy Skills Development Institute:**
- Sector skills development and training
- Apprenticeship programs
- Certification and standards

### New Skill Requirements:
- Digital and data analytics skills
- Environmental and social impact assessment
- Financial modeling and project finance
- Community engagement and development

## Regional Value Chain Integration

### Southern African Power Pool (SAPP):
- Regional electricity market with 12 member countries
- 280,000 km of transmission lines
- Potential for renewable energy trade

### Value Chain Opportunities:
**Manufacturing Hubs:**
- South Africa: Technical manufacturing and services
- Namibia: Green hydrogen production
- Botswana: Solar component assembly
- Mozambique: Aluminum smelting with renewable power

**Resource Complementarity:**
- South Africa: Manufacturing and technical expertise
- DRC: Critical minerals for batteries and solar
- Mozambique: Hydroelectric power
- Botswana: Solar and wind resources

## Financial Value Chains

### Traditional Energy Finance:
- Development finance institutions
- Commercial banks
- Export credit agencies
- Sovereign funding

### Renewable Energy Finance:
- Green bonds and climate finance
- Development finance institutions
- Private equity and infrastructure funds
- Blended finance mechanisms

### Innovative Financing Models:
- Pay-as-you-go solar systems
- Crowdfunding platforms
- Green sukuk (Islamic finance)
- Results-based financing

## Case Study: Saldanha Bay Industrial Development Zone
South Africa's first green industrial development zone demonstrates value chain integration:

**Objectives:**
- Manufacturing hub for renewable energy components
- Green hydrogen production facility
- Skills development and job creation
- Export manufacturing base

**Key Projects:**
- Coriolis wind turbine blade factory
- Green ammonia production facility
- Skills development center
- Port infrastructure upgrades

**Outcomes:**
- 1,400+ direct jobs created
- R14 billion in investment attracted
- Technology transfer and local capability building
- Model for other industrial development zones
    `,
    videoUrl: null,
    interactiveElements: [
      {
        type: "flow_diagram",
        title: "Interactive Value Chain Comparison",
        description: "Compare coal vs renewable energy value chains"
      },
      {
        type: "calculator",
        title: "Economic Impact Calculator",
        description: "Calculate jobs and economic impacts of energy investments"
      }
    ]
  },
  {
    id: "chapter-8",
    title: "Chapter 8: Key Stakeholders in Energy Transition",
    order: 8,
    duration: "45 minutes",
    points: 115,
    badge: "Stakeholder Navigator",
    content: `
# Chapter 8: Key Stakeholders in Energy Transition

## Learning Objectives
- Identify primary stakeholders in energy transition
- Analyze stakeholder interests, power, and influence
- Understand stakeholder engagement strategies
- Evaluate successful stakeholder collaboration examples

## Stakeholder Mapping Framework
Energy transition involves complex stakeholder ecosystems with varying interests, power levels, and influence. Understanding these dynamics is crucial for successful project implementation.

### Stakeholder Categories:
1. **Government and Regulatory Bodies**
2. **Private Sector and Industry**
3. **Civil Society and Communities**
4. **Financial Institutions and Investors**
5. **International Organizations and Development Partners**
6. **Academia and Research Institutions**
7. **Labor Organizations and Workers**

## Government and Regulatory Bodies

### National Government:
**Key Departments/Ministries:**
- Department of Mineral Resources and Energy (DMRE)
- Department of Environment, Forestry and Fisheries
- National Treasury
- Department of Trade, Industry and Competition

**Roles and Responsibilities:**
- Energy policy development and regulation
- Licensing and permitting
- Economic incentives and subsidies
- Industrial development strategies
- Environmental protection

**Interests:**
- Energy security and reliability
- Economic growth and job creation
- Climate commitments and international reputation
- Political stability and public support

### Regulatory Agencies:
**National Energy Regulator of South Africa (NERSA):**
- Electricity tariff regulation
- Power generation licensing
- Grid access and connection rules
- Consumer protection

**Other Key Regulators:**
- Competition Commission (market competition)
- Environmental authorities (impact assessments)
- Municipal regulators (distribution licensing)

### Local and Provincial Government:
**Roles:**
- Electricity distribution (municipalities)
- Land use planning and zoning
- Local economic development
- Community consultation and consent

**Challenges:**
- Limited technical capacity
- Conflicting national and local priorities
- Revenue concerns from reduced electricity sales
- Political pressures and electoral cycles

## Private Sector and Industry

### Energy Companies:
**State-Owned Enterprises:**
- Eskom (generation, transmission, distribution)
- Transnet (energy transportation infrastructure)
- Central Energy Fund (petroleum and gas)

**Independent Power Producers (IPPs):**
- International developers (Scatec, Mainstream, ACWA Power)
- Local developers (H1 Holdings, Mulilo)
- Community-owned projects

**Traditional Energy Companies:**
- Coal mining companies (Anglo American, Sasol)
- Oil and gas companies (Shell, BP, Total)
- Petrochemicals (Sasol, Natref)

### Equipment Manufacturers and Service Providers:
**International Manufacturers:**
- Solar: First Solar, Canadian Solar, JinkoSolar
- Wind: Nordex, Vestas, Siemens Gamesa
- Grid equipment: ABB, Siemens, GE

**Local Manufacturers:**
- Solar components (ARTsolar, Solairedirect)
- Wind towers and components (DCD, Nordex SA)
- Grid infrastructure (Powertech)

**Service Providers:**
- Engineering, Procurement, Construction (EPC)
- Operations and Maintenance (O&M)
- Financial and legal services
- Environmental and social consultants

### Energy-Intensive Industries:
**Major Users:**
- Mining companies (gold, platinum, coal)
- Smelters (aluminum, steel, ferrochrome)
- Cement and chemicals
- Data centers and telecommunications

**Interests:**
- Reliable and affordable energy supply
- Long-term price certainty
- Environmental compliance requirements
- Operational flexibility and grid services

## Civil Society and Communities

### Community Organizations:
**Types:**
- Traditional authorities and councils
- Community-based organizations (CBOs)
- Cooperative organizations
- Faith-based organizations

**Roles:**
- Representing community interests
- Facilitating consultation processes
- Implementing community development programs
- Monitoring project impacts

**Concerns:**
- Equitable benefit sharing
- Environmental and health impacts
- Cultural heritage protection
- Local employment and procurement

### Non-Governmental Organizations (NGOs):
**Environmental Organizations:**
- Greenpeace Africa
- WWF South Africa
- earthlife Africa
- Centre for Environmental Rights

**Social Justice Organizations:**
- Section27 (right to healthcare)
- groundWork (environmental justice)
- Organisation Undoing Tax Abuse (OUTA)

**Research and Advocacy Organizations:**
- Institute for Security Studies (ISS)
- Trade & Industrial Policy Strategies (TIPS)
- Council for Scientific and Industrial Research (CSIR)

### Labor Organizations:
**Trade Unions:**
- National Union of Mineworkers (NUM)
- National Union of Metalworkers of South Africa (NUMSA)
- South African Municipal Workers' Union (SAMWU)
- Solidarity

**Concerns:**
- Job security and protection
- Skills development and retraining
- Fair wages and working conditions
- Just transition for affected workers

## Financial Institutions and Investors

### Development Finance Institutions (DFIs):
**Multilateral:**
- World Bank Group (IFC, MIGA)
- African Development Bank (AfDB)
- New Development Bank (BRICS Bank)
- Climate Investment Funds

**Bilateral:**
- KfW (Germany)
- AFD (France)
- JICA (Japan)
- USTDA (United States)

**Domestic:**
- Development Bank of Southern Africa (DBSA)
- Industrial Development Corporation (IDC)
- Public Investment Corporation (PIC)

### Commercial Financial Institutions:
**International Banks:**
- Standard Chartered
- HSBC
- Citibank
- Deutsche Bank

**Domestic Banks:**
- Standard Bank
- FirstRand/RMB
- Nedbank
- ABSA

**Insurance and Asset Managers:**
- Old Mutual
- Sanlam
- Liberty
- Government Employees Pension Fund

### Private Equity and Infrastructure Funds:
- Actis (renewable energy focus)
- H1 Holdings (local infrastructure)
- African Infrastructure Investment Managers (AIIM)
- Harith General Partners

## International Organizations and Development Partners

### United Nations System:
- UNDP (capacity building and governance)
- UNEP (environmental sustainability)
- UNIDO (industrial development)
- ILO (just transition and labor)

### Climate Finance Organizations:
- Green Climate Fund (GCF)
- Climate Investment Funds (CIF)
- Adaptation Fund
- Global Environment Facility (GEF)

### Bilateral Development Partners:
**Major Contributors to SA's JET Partnership:**
- European Union
- United Kingdom (UK PACT)
- Germany (GIZ, KfW)
- France (AFD)
- United States (USAID, DFC)

### Technical Assistance Providers:
- International Energy Agency (IEA)
- International Renewable Energy Agency (IRENA)
- Rocky Mountain Institute (RMI)
- Energy Sector Management Assistance Program (ESMAP)

## Academia and Research Institutions

### Universities:
**Leading Energy Research Centers:**
- University of Cape Town (Energy Research Centre)
- Stellenbosch University (renewable energy)
- University of the Witwatersrand (mining and energy)
- North-West University (nuclear and renewable energy)

**Research Institutes:**
- Council for Scientific and Industrial Research (CSIR)
- South African National Energy Development Institute (SANEDI)
- Energy Research Centre (University of Cape Town)

**Roles:**
- Applied research and technology development
- Policy analysis and recommendation
- Human capital development and training
- Innovation and technology transfer

## Stakeholder Engagement Strategies

### Engagement Principles:
1. **Early and Continuous**: Engage stakeholders from project conception
2. **Inclusive and Representative**: Include all affected and interested parties
3. **Transparent and Accessible**: Provide clear, understandable information
4. **Respectful and Culturally Appropriate**: Respect local customs and languages
5. **Responsive and Adaptive**: Address concerns and adapt based on feedback

### Engagement Methods:
**Information Sharing:**
- Public meetings and presentations
- Websites and information centers
- Newsletters and media communications
- Social media and digital platforms

**Consultation:**
- Focus group discussions
- Surveys and questionnaires
- Public comment periods
- Stakeholder workshops

**Participation:**
- Community advisory committees
- Joint planning processes
- Co-design workshops
- Collaborative monitoring

**Partnership:**
- Joint ventures and ownership structures
- Skills development partnerships
- Community development agreements
- Benefit-sharing arrangements

## Managing Stakeholder Conflicts

### Common Sources of Conflict:
- Competing interests and priorities
- Unequal power relations
- Information asymmetries
- Historical grievances
- Resource competition

### Conflict Resolution Approaches:
1. **Prevention**: Early engagement and transparent communication
2. **Mediation**: Third-party facilitation of negotiations
3. **Arbitration**: Independent decision-making processes
4. **Legal Resolution**: Court-based dispute resolution
5. **Collaborative Problem-Solving**: Joint development of solutions

## Case Study: Sere Wind Farm Stakeholder Engagement

### Project Overview:
- 100 MW wind farm in Western Cape
- R3.2 billion investment
- First project under REIPPPP Round 1

### Stakeholder Engagement Approach:
**Community Consultation:**
- 18-month consultation process
- Meetings in local languages (Afrikaans, isiXhosa)
- Visual impact assessments and site visits
- Cultural heritage surveys

**Benefit Sharing:**
- 12% community ownership stake
- Local employment during construction
- Skills development programs
- Community development fund

**Environmental Management:**
- Independent environmental monitoring
- Biodiversity offset programs
- Noise and visual impact mitigation
- Stakeholder monitoring committee

### Outcomes:
- Broad community support achieved
- No significant legal challenges
- Successful construction and operation
- Model for subsequent wind projects

## Success Factors for Stakeholder Engagement

### Institutional Factors:
- Strong project leadership and commitment
- Adequate budget and timeline for engagement
- Clear roles and responsibilities
- Effective grievance mechanisms

### Process Factors:
- Stakeholder mapping and analysis
- Culturally appropriate engagement methods
- Regular communication and feedback loops
- Adaptive management approaches

### Outcome Factors:
- Shared understanding of project benefits/risks
- Collaborative solutions to challenges
- Sustainable partnerships and relationships
- Social license to operate
    `,
    videoUrl: null,
    interactiveElements: [
      {
        type: "stakeholder_map",
        title: "Interactive Stakeholder Mapping Tool",
        description: "Map stakeholders by interest and influence levels"
      },
      {
        type: "scenario_builder",
        title: "Stakeholder Engagement Scenario Builder",
        description: "Practice managing different stakeholder situations"
      }
    ]
  },
  {
    id: "chapter-9",
    title: "Chapter 9: Environmental Justice and Community Impact",
    order: 9,
    duration: "55 minutes",
    points: 145,
    badge: "Justice Champion",
    content: `
# Chapter 9: Environmental Justice and Community Impact

## Learning Objectives
- Understand environmental justice principles and frameworks
- Analyze environmental impacts of different energy systems
- Evaluate community impact assessment methods
- Design inclusive environmental protection strategies

## Understanding Environmental Justice

### Definition and Origins:
Environmental Justice is the fair treatment and meaningful involvement of all people regardless of race, color, national origin, or income with respect to the development, implementation, and enforcement of environmental laws, regulations, and policies.

### Core Principles:
1. **Fair Treatment**: No group should bear a disproportionate share of environmental harm
2. **Meaningful Involvement**: Communities have the right to participate in decisions affecting their environment
3. **Access to Information**: Environmental information should be accessible to all communities
4. **Procedural Justice**: Fair and transparent decision-making processes
5. **Distributive Justice**: Equitable distribution of environmental benefits and burdens

### Historical Context in South Africa:
Environmental injustice has deep historical roots in South Africa:
- **Apartheid Spatial Planning**: Forced removals to environmentally degraded areas
- **Industrial Siting**: Polluting industries located near black communities
- **Resource Extraction**: Environmental damage in rural areas with minimal compensation
- **Limited Participation**: Exclusion from environmental decision-making processes

## Environmental Impacts of Energy Systems

### Coal-Based Energy System Impacts:

**Air Quality Impacts:**
- **Particulate Matter (PM2.5, PM10)**: Respiratory and cardiovascular diseases
- **Sulfur Dioxide (SO2)**: Acid rain, respiratory problems
- **Nitrogen Oxides (NOx)**: Smog formation, respiratory issues
- **Mercury**: Neurotoxic effects, especially harmful to children
- **Carbon Dioxide (CO2)**: Climate change and global warming

**Health Impact Statistics:**
- Coal pollution causes 2,200 premature deaths annually in South Africa
- Mpumalanga has the highest air pollution levels in Africa
- Healthcare costs from coal pollution: R30 billion annually
- Disproportionately affects low-income communities near coal plants

**Water Impacts:**
- **Water Consumption**: Coal plants use 1.9 liters per kWh generated
- **Thermal Pollution**: Heated water discharge affects aquatic ecosystems
- **Chemical Pollution**: Ash ponds leach heavy metals into groundwater
- **Acid Mine Drainage**: Long-term contamination of water sources

**Land and Ecosystem Impacts:**
- **Surface Mining**: Landscape destruction and habitat loss
- **Ash Disposal**: Large ash dumps covering productive land
- **Coal Transportation**: Rail and road infrastructure impacts
- **Biodiversity Loss**: Ecosystem fragmentation and species displacement

### Renewable Energy Environmental Impacts:

**Solar Energy:**
**Positive Impacts:**
- No air or water pollution during operation
- Minimal water use compared to conventional power
- No greenhouse gas emissions during operation
- Modular deployment with minimal land disturbance

**Potential Negative Impacts:**
- Manufacturing impacts (silicon processing, rare materials)
- Land use for utility-scale projects
- Visual impacts in sensitive landscapes
- End-of-life waste management

**Wind Energy:**
**Positive Impacts:**
- No air or water pollution during operation
- Minimal water consumption
- Land can still be used for agriculture
- Strong job creation potential

**Potential Negative Impacts:**
- Noise impacts on nearby communities
- Visual landscape changes
- Bird and bat mortality
- Construction phase impacts

**Hydroelectric Power:**
**Positive Impacts:**
- No air pollution during operation
- Long-term reliable electricity supply
- Flood control and water storage benefits
- Recreational opportunities

**Potential Negative Impacts:**
- Displacement of communities
- Ecosystem disruption and species migration
- Methane emissions from reservoirs
- Downstream flow alterations

## Community Impact Assessment

### Social Impact Assessment (SIA) Framework:
SIA is the process of analyzing, monitoring and managing the intended and unintended social consequences of planned interventions and social change processes invoked by those interventions.

**Key Components:**
1. **Scoping**: Identifying potential impacts and affected communities
2. **Baseline Studies**: Understanding current social conditions
3. **Impact Prediction**: Forecasting likely social changes
4. **Evaluation**: Assessing significance of predicted impacts
5. **Mitigation**: Developing measures to address negative impacts
6. **Monitoring**: Tracking actual impacts during implementation

### Community Profiling Methods:

**Demographic Analysis:**
- Population size and growth patterns
- Age and gender distributions
- Ethnic and cultural composition
- Educational levels and literacy rates

**Socioeconomic Assessment:**
- Income levels and poverty rates
- Employment and livelihood strategies
- Asset ownership and wealth distribution
- Access to basic services (water, sanitation, healthcare)

**Social Capital Mapping:**
- Community organizations and leadership structures
- Social networks and relationships
- Trust levels and collective efficacy
- Cultural practices and traditions

**Vulnerability Assessment:**
- Identification of vulnerable groups (women, children, elderly, disabled)
- Risk exposure and coping mechanisms
- Access to resources and support systems
- Historical experiences with development projects

### Participatory Research Methods:

**Community Mapping:**
- Spatial representation of community assets and concerns
- Identification of sacred sites and cultural landmarks
- Resource use patterns and access rights
- Infrastructure and service gaps

**Focus Group Discussions:**
- Gender-segregated groups for sensitive topics
- Age-specific groups (youth, elderly)
- Occupation-based groups (farmers, small business owners)
- Interest groups (environmental concerns, development priorities)

**Household Surveys:**
- Representative sampling of community households
- Standardized questionnaires for quantitative data
- Economic and social indicators
- Baseline data for monitoring changes

**Key Informant Interviews:**
- Traditional leaders and community elders
- Local government representatives
- Civil society organization leaders
- Service providers (healthcare, education)

## Free, Prior and Informed Consent (FPIC)

### FPIC Principles:
**Free**: Consent given without coercion, intimidation, or manipulation
**Prior**: Consent sought before project authorization or implementation
**Informed**: Access to complete, accessible information about the project
**Consent**: Right to approve or reject projects affecting their territories

### FPIC Implementation Process:

**Phase 1: Preparation and Planning**
- Identify rights holders and representative institutions
- Develop culturally appropriate engagement protocols
- Establish independent grievance mechanisms
- Ensure adequate time and resources for consultation

**Phase 2: Information Sharing**
- Provide comprehensive project information in local languages
- Use multiple communication channels and formats
- Allow time for community deliberation
- Respond to questions and concerns transparently

**Phase 3: Consultation and Negotiation**
- Facilitate meaningful dialogue about project impacts
- Negotiate benefit-sharing arrangements
- Develop impact mitigation measures
- Agree on monitoring and evaluation procedures

**Phase 4: Decision Making**
- Respect community decision-making processes
- Document consent agreements clearly
- Establish review and modification procedures
- Implement agreed-upon measures

### FPIC Challenges in Practice:
- Complex community structures and competing interests
- Power imbalances between developers and communities
- Limited technical capacity for impact assessment
- Pressure from government and investors
- Long-term nature of energy projects vs. immediate needs

## Environmental Health and Safety

### Health Impact Assessment (HIA):
HIA is a systematic process for evaluating potential health impacts of policies, plans, programs or projects and developing recommendations to address identified impacts.

**HIA Steps:**
1. **Screening**: Determine if HIA is needed and beneficial
2. **Scoping**: Define scope, methods, and stakeholder engagement
3. **Assessment**: Analyze potential health impacts
4. **Recommendations**: Develop mitigation and enhancement measures
5. **Reporting**: Communicate findings to decision-makers
6. **Monitoring**: Track health outcomes during implementation

### Air Quality Management:

**Ambient Air Quality Standards:**
South Africa's National Ambient Air Quality Standards set limits for:
- PM10: 50 μg/m³ (annual average)
- PM2.5: 20 μg/m³ (annual average)
- SO2: 50 μg/m³ (annual average)
- NO2: 40 μg/m³ (annual average)

**Monitoring and Enforcement:**
- Real-time air quality monitoring stations
- Community-based monitoring programs
- Public reporting of air quality data
- Enforcement actions against violators

**Community Health Protection:**
- Health screening and treatment programs
- Public awareness and education
- Indoor air quality improvement
- Vulnerable group protection (children, elderly)

### Water Quality Protection:

**Water Quality Standards:**
- Drinking water quality guidelines
- Surface water quality objectives
- Groundwater protection standards
- Industrial discharge limits

**Watershed Management:**
- Integrated catchment management
- Point and non-point source pollution control
- Ecosystem restoration programs
- Community-based water management

### Noise and Visual Impact Management:

**Noise Standards:**
- Residential area limits: 45 dB(A) nighttime, 55 dB(A) daytime
- Mixed-use areas: 50 dB(A) nighttime, 60 dB(A) daytime
- Industrial areas: 55 dB(A) nighttime, 70 dB(A) daytime

**Visual Impact Mitigation:**
- Landscape design and screening
- Community input on siting decisions
- Cultural and aesthetic considerations
- Light pollution minimization

## Community Benefit Programs

### Benefit-Sharing Models:

**Community Ownership:**
- Direct equity stakes in energy projects
- Community energy cooperatives
- Shared ownership structures
- Revenue sharing mechanisms

**Economic Development Programs:**
- Local procurement requirements
- Skills development and training
- Small business development support
- Infrastructure improvement projects

**Social Investment:**
- Education and healthcare facility improvements
- Scholarship and bursary programs
- Community center development
- Cultural preservation initiatives

**Environmental Enhancement:**
- Ecosystem restoration projects
- Biodiversity conservation programs
- Carbon offset projects
- Sustainable agriculture support

### Case Study: Longyuan Mulilo De Aar Wind Farm

**Project Overview:**
- 244 MW wind farm in Northern Cape
- R4.7 billion investment
- 103 wind turbines across 8,000 hectares

**Environmental Justice Approach:**
**Community Engagement:**
- 2-year consultation process before construction
- Meetings with affected landowners and communities
- Environmental and social impact assessments
- Independent environmental monitoring

**Benefit Sharing:**
- 51% local ownership (community trusts and local investors)
- Preference for local workers during construction
- Local business development programs
- Annual community development contributions

**Environmental Protection:**
- Bird and bat monitoring programs
- Vegetation restoration after construction
- Noise monitoring and management
- Visual impact mitigation measures

**Health and Safety:**
- Comprehensive health and safety training
- Local clinic support and medical programs
- Emergency response capacity building
- Worker accommodation and welfare facilities

**Outcomes:**
- 400+ local jobs during construction phase
- 40+ permanent operations jobs
- R20 million+ annual community contributions
- Measurable improvement in local development indicators
- Model for environmental justice in renewable energy

## Monitoring and Adaptive Management

### Community-Based Monitoring:
- Training community members as environmental monitors
- Providing monitoring equipment and technical support
- Regular data collection and reporting
- Integration with official monitoring systems

### Grievance Mechanisms:
- Accessible complaint procedures
- Independent investigation processes
- Timely response and resolution
- Appeals and escalation procedures

### Adaptive Management:
- Regular review of impact predictions vs. actual outcomes
- Adjustment of mitigation measures based on monitoring results
- Community feedback integration
- Continuous improvement processes

## Building Environmental Justice Capacity

### Community Empowerment:
- Environmental literacy programs
- Leadership development initiatives
- Technical capacity building
- Legal rights awareness training

### Institutional Strengthening:
- Support for community-based organizations
- Government capacity building
- Multi-stakeholder platforms
- Policy advocacy training

### Knowledge Systems Integration:
- Combining scientific and indigenous knowledge
- Participatory research methodologies
- Community-based research initiatives
- Knowledge sharing platforms
    `,
    videoUrl: null,
    interactiveElements: [
      {
        type: "impact_assessment",
        title: "Environmental Impact Assessment Tool",
        description: "Assess environmental impacts of different energy projects"
      },
      {
        type: "case_study",
        title: "Environmental Justice Case Studies",
        description: "Analyze real-world environmental justice scenarios"
      }
    ]
  }
];

// Gamification system
export const gamificationSystem = {
  levels: [
    { level: 1, title: "Energy Newcomer", pointsRequired: 0, badge: "🌱" },
    { level: 2, title: "Sustainability Seeker", pointsRequired: 500, badge: "🔍" },
    { level: 3, title: "Renewable Advocate", pointsRequired: 1200, badge: "♻️" },
    { level: 4, title: "JET Champion", pointsRequired: 2000, badge: "⚡" },
    { level: 5, title: "Energy Expert", pointsRequired: 3000, badge: "🏆" },
    { level: 6, title: "Transition Leader", pointsRequired: 4500, badge: "👑" },
  ],
  
  achievements: [
    { id: "first_chapter", title: "First Steps", description: "Complete your first chapter", points: 50 },
    { id: "quiz_master", title: "Quiz Master", description: "Score 90%+ on 5 quizzes", points: 200 },
    { id: "video_watcher", title: "Visual Learner", description: "Watch all chapter videos", points: 150 },
    { id: "discussion_contributor", title: "Community Voice", description: "Contribute to 10 discussions", points: 100 },
    { id: "case_study_analyst", title: "Real-World Analyst", description: "Complete all case studies", points: 300 },
    { id: "perfect_score", title: "Perfectionist", description: "Score 100% on a final assessment", points: 250 },
  ],

  pointSystem: {
    chapterCompletion: 100,
    quizPassed: 50,
    perfectQuiz: 100,
    videoWatched: 25,
    discussionPost: 20,
    caseStudyCompleted: 75,
    assignmentSubmitted: 60,
    peerReviewCompleted: 40,
  },

  leaderboards: {
    weekly: "Weekly Progress Leaders",
    monthly: "Monthly Achievement Champions", 
    allTime: "All-Time Learning Legends"
  }
};

// Complete course structure with all 16 chapters
export const completeJETCourse = {
  id: "jet-101-course",
  title: "JET 101: Introduction to Just Energy Transition", 
  description: "A comprehensive 16-chapter Harvard-level course on Just Energy Transition, designed for African learners seeking job-ready skills in the energy sector.",
  category: "energy_transition",
  level: "beginner",
  duration: "12 weeks",
  totalPoints: 2400,
  chapters: jetCourse16Chapters,
  gamification: gamificationSystem,
  prerequisites: [],
  outcomes: [
    "Understand fundamental energy concepts and their role in society",
    "Master the five pillars of Just Energy Transition",
    "Analyze renewable energy technologies and their applications",
    "Evaluate energy policies and their social impacts", 
    "Develop skills for careers in the clean energy sector",
    "Apply JET principles to real-world energy challenges"
  ],
  certification: {
    title: "Just Energy Transition Specialist",
    issuer: "DLO Academy",
    credentialId: "JET-101-CERT",
    skills: ["Energy Systems Analysis", "Renewable Energy Technologies", "Just Transition Planning", "Policy Analysis", "Community Engagement"]
  }
};