import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import { seedDatabase } from "./seedData";

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

// Startup function with proper error handling and deployment optimization
async function startServer() {
  try {
    // Register routes and get server instance
    const server = await registerRoutes(app);
    
    // Global error handler to prevent crashes
    app.use((err: any, req: Request, res: Response, _next: NextFunction) => {
      const status = err.status || err.statusCode || 500;
      const message = err.message || "Internal Server Error";
      
      // Log error details for debugging (but don't crash the app)
      console.error(`[${new Date().toISOString()}] ${req.method} ${req.path} - Error:`, err);
      
      // Send error response
      res.status(status).json({ 
        message,
        error: process.env.NODE_ENV === 'development' ? err.stack : undefined
      });
    });

    // Setup environment-specific middleware
    if (app.get("env") === "development") {
      await setupVite(app, server);
    } else {
      serveStatic(app);
    }

    // Get port configuration
    const port = parseInt(process.env.PORT || '5000', 10);
    
    // Enhanced server startup with resource conflict prevention
    const serverInstance = await new Promise<any>((resolve, reject) => {
      const instance = server.listen({
        port,
        host: "0.0.0.0",
        reusePort: true,
      }, (err?: Error) => {
        if (err) {
          console.error("❌ Failed to start server on port", port, ":", err);
          
          // Handle specific deployment scenarios
          if (err.message.includes('EADDRINUSE')) {
            console.log("🔄 Port conflict detected - attempting graceful resolution...");
            // In deployment, this might be a previous instance
            setTimeout(() => {
              console.log("🔄 Retrying server startup after brief delay...");
              reject(new Error(`Port ${port} conflict - deployment may need restart`));
            }, 2000);
          } else {
            reject(err);
          }
        } else {
          log(`✅ Server successfully started on port ${port}`);
          log("🌐 Health check endpoint available at /health");
          log("🔗 Root endpoint available at /");
          resolve(instance);
        }
      });

      // Enhanced server error handling for deployment stability
      instance.on('error', (error: any) => {
        console.error("🚨 Server error detected:", error);
        
        if (error.code === 'EADDRINUSE') {
          console.error(`🚨 Port ${port} is already in use - deployment conflict detected`);
          console.log("💡 This may indicate multiple application instances running");
          console.log("🔄 Deployment system should handle instance management");
        } else if (error.code === 'EACCES') {
          console.error(`🚨 Permission denied on port ${port}`);
        } else if (error.code === 'ECONNRESET') {
          console.log("⚠️ Connection reset - continuing operation");
          return; // Don't reject for connection resets
        }
        
        reject(error);
      });

      // Add connection handling for deployment stability
      instance.on('connection', (socket) => {
        socket.on('error', (socketError) => {
          console.warn('⚠️ Socket error (non-fatal):', socketError.message);
          // Don't crash on socket errors
        });
      });
    });

    // Add graceful shutdown handling (deployment-optimized)
    const gracefulShutdown = (signal: string) => {
      log(`Received ${signal}, shutting down gracefully...`);
      serverInstance.close(() => {
        log("Server closed successfully");
        process.exit(0);
      });

      // Force close after longer timeout for deployment stability
      setTimeout(() => {
        log("Forcing shutdown after timeout...");
        process.exit(1);
      }, 45000); // Increased timeout for deployment stability
    };

    // Handle shutdown signals
    process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown('SIGINT'));

    // Handle uncaught exceptions and rejections without exiting
    process.on('uncaughtException', (error) => {
      console.error('Uncaught Exception (server continues):', error);
      console.error('Stack:', error.stack);
      // Log but don't exit - let the server continue running
    });

    process.on('unhandledRejection', (reason, promise) => {
      console.error('Unhandled Rejection (server continues) at:', promise, 'reason:', reason);
      if (reason instanceof Error) {
        console.error('Stack:', reason.stack);
      }
      // Log but don't exit - let the server continue running
    });

    // Log successful startup
    log("✅ Server started successfully and ready to handle requests");
    log("✅ Application is healthy and running persistently");
    log("🚀 Application initialization complete - server ready for deployment");
    
    // Move database seeding to background to prevent blocking health checks
    setImmediate(async () => {
      try {
        await seedDatabase();
        log("Database seeded successfully");
      } catch (error) {
        console.error("Database seeding failed (server continues running):", error);
        // Seeding failure should not affect server operation
      }
    });
    
    return serverInstance;
    
  } catch (error) {
    console.error("❌ Critical failure during server startup:", error);
    console.error("Stack trace:", error instanceof Error ? error.stack : 'No stack trace');
    
    // Try to provide more specific error information
    if (error instanceof Error) {
      console.error("Error name:", error.name);
      console.error("Error message:", error.message);
    }
    
    throw error; // Re-throw to be caught by main function
  }
}

// Optimized main function for fast deployment health checks
async function main() {
  try {
    log("🚀 Starting DLO Academy application...");
    const serverInstance = await startServer();
    
    log("✅ Application startup completed successfully");
    log("🔄 Main process is now running persistently");
    log("🎯 Entering persistent runtime mode...");
    
    // Simple keep-alive mechanism without blocking deployment
    const keepAliveInterval = setInterval(() => {
      if (process.env.NODE_ENV === 'development') {
        log("Process keep-alive heartbeat");
      }
    }, 60000);
    
    // Handle graceful shutdown
    const cleanup = () => {
      log("Cleaning up keep-alive interval...");
      clearInterval(keepAliveInterval);
    };
    
    process.on('SIGTERM', cleanup);
    process.on('SIGINT', cleanup);
    
    // Immediate readiness for production traffic (no delays)
    log("⚡ Application fully initialized and ready for production traffic");
    
    // Return server instance to allow main function to complete normally
    // Keep process alive through the server itself, not blocking promises
    return serverInstance;
    
  } catch (error) {
    console.error("❌ Fatal error during server startup:", error);
    console.error("Stack trace:", error instanceof Error ? error.stack : 'No stack trace');
    throw error;
  }
}

// Start the application with deployment-optimized error handling
main().then((serverInstance) => {
  log("🎯 Main function completed successfully - server running");
  
  // Server instance keeps the process alive automatically
  // No need for blocking promises or complex keep-alive mechanisms
}).catch((error) => {
  console.error("❌ Unhandled error in main function:", error);
  console.error("Stack trace:", error instanceof Error ? error.stack : 'No stack trace');
  
  // Exit with error code only in case of actual startup failure
  process.exit(1);
});
