// Case studies and assignments based on JET 101 course content
export const jetCaseStudies = [
  {
    id: 'mining-case-study',
    title: 'Clean Tech Mining Video Analysis - Toxic Cost of Going Green',
    description: 'Analyze the "Toxic Cost of Going Green - Unreported World" documentary and evaluate if Just Energy Transition principles are being observed in global mining operations',
    type: 'video_analysis',
    videoUrl: '/assets/Toxic Cost of Going Green  Unreported World_1754941553735.mp4',
    videoDuration: '25 minutes',
    questions: [
      {
        question: 'Are the key pillars of the just energy transition being observed?',
        type: 'multiple_choice',
        options: ['YES', 'NO'],
        points: 10
      },
      {
        question: 'What is the primary resource being mined in this video and what is it used for?',
        type: 'multiple_choice', 
        options: ['COPPER', 'GOLD', 'COBALT'],
        correctAnswer: 'COBALT',
        points: 15
      },
      {
        question: 'Why is this resource important for the just energy transition?',
        type: 'multiple_choice',
        options: ['Cooling', 'Solar panels', 'Battery storage'],
        correctAnswer: 'Battery storage',
        points: 15
      },
      {
        question: 'Are the communities benefiting from the mining activities?',
        type: 'multiple_choice',
        options: ['YES', 'NO'],
        points: 10
      },
      {
        question: 'Are workers benefiting from the mining activities?',
        type: 'multiple_choice',
        options: ['YES', 'NO'], 
        points: 10
      },
      {
        question: 'Are health and safety regulations being observed?',
        type: 'multiple_choice',
        options: ['YES', 'NO'],
        points: 10
      },
      {
        question: 'Who stands to benefit from this mining activity?',
        type: 'multiple_choice',
        options: ['DRC and the global South', 'Global North'],
        points: 15
      },
      {
        question: 'Write a detailed analysis (300-500 words) on whether this mining operation aligns with Just Energy Transition principles. Consider community benefits, worker welfare, environmental impact, and equitable distribution of benefits.',
        type: 'essay',
        points: 25
      }
    ],
    totalPoints: 110,
    estimatedTime: 45 // minutes
  },
  {
    id: 'solar-project-case-study',
    title: 'South African Solar Power Plant Analysis',
    description: 'Analyze a renewable energy project and evaluate its impact on local communities and job creation',
    type: 'project_analysis',
    questions: [
      {
        question: 'What is the size of the solar plant mentioned in the video?',
        type: 'short_answer',
        points: 10
      },
      {
        question: 'Where is the solar plant located?',
        type: 'short_answer',
        points: 10
      },
      {
        question: 'Who is the EPC contractor in this video?',
        type: 'short_answer',
        points: 10
      },
      {
        question: 'How does the community benefit from this power plant?',
        type: 'short_answer',
        points: 15
      },
      {
        question: 'Are the panels made locally or are they imported?',
        type: 'multiple_choice',
        options: ['Made locally', 'Imported'],
        points: 10
      },
      {
        question: 'Is there a safe working environment?',
        type: 'multiple_choice',
        options: ['YES', 'NO'],
        points: 10
      },
      {
        question: 'Can renewable energy power plants create as many long-term jobs as coal fired power plants?',
        type: 'multiple_choice',
        options: ['YES', 'NO'],
        points: 15
      },
      {
        question: 'In your observations of the video, are the long-term jobs that are created highly skilled jobs or unskilled jobs?',
        type: 'multiple_choice',
        options: ['Highly skilled', 'Unskilled', 'Mix of both'],
        points: 10
      },
      {
        question: 'Name one job title you observed from the video?',
        type: 'short_answer',
        points: 10
      },
      {
        question: 'Who is doing the unskilled labour in the video?',
        type: 'short_answer',
        points: 10
      }
    ],
    totalPoints: 120,
    estimatedTime: 60 // minutes
  },
  {
    id: 'value-chain-comparison',
    title: 'Coal vs Renewable Energy Value Chain Analysis',
    description: 'Compare and contrast the job creation potential of coal and renewable energy value chains',
    type: 'comparative_analysis',
    questions: [
      {
        question: 'Between the coal and the renewable energy value chain, which do you believe has the ability to create more jobs?',
        type: 'multiple_choice',
        options: ['Coal value chain', 'Renewable energy value chain', 'Both create equal jobs'],
        points: 15
      },
      {
        question: 'Where do you think South Africa needs to improve in order to create more jobs in the renewable energy sector?',
        type: 'essay',
        points: 25,
        guidelines: 'Consider local manufacturing, skills development, policy framework, and supply chain challenges'
      },
      {
        question: 'Does South Africa currently have enough local manufacturing to support growth and local job creation in the sector?',
        type: 'multiple_choice',
        options: ['YES', 'NO'],
        points: 10
      },
      {
        question: 'Based on the course content, analyze the challenges and opportunities for local manufacturing in South Africa\'s renewable energy sector. Discuss the R17.5 billion solar panel imports from China and propose solutions.',
        type: 'essay',
        points: 30,
        guidelines: 'Address economies of scale, supply chain issues, policy uncertainty, and potential solutions'
      },
      {
        question: 'Create a detailed action plan for a young South African who wants to enter the renewable energy sector. Include specific career paths, required skills, and steps to get started.',
        type: 'project',
        points: 40,
        guidelines: 'Consider different education levels, geographical locations, and available opportunities'
      }
    ],
    totalPoints: 120,
    estimatedTime: 90 // minutes
  }
];

export const practicalAssignments = [
  {
    id: 'community-engagement-plan',
    title: 'Community Engagement Plan for Renewable Energy Project',
    description: 'Design a comprehensive community engagement strategy for a proposed 100MW solar farm in rural South Africa',
    requirements: [
      'Identify key stakeholders in the community',
      'Develop consultation timeline and methods',
      'Address the 5 pillars of Just Energy Transition',
      'Create benefit-sharing mechanisms',
      'Design communication materials for different literacy levels',
      'Include conflict resolution procedures'
    ],
    deliverables: [
      'Stakeholder mapping document',
      'Engagement timeline (Gantt chart)',
      'Community benefits proposal',
      'Sample consultation materials',
      'Risk assessment and mitigation plan'
    ],
    duration: '2 weeks',
    points: 200
  },
  {
    id: 'skills-transition-program',
    title: 'Skills Transition Program for Coal Workers',
    description: 'Develop a comprehensive retraining program for coal mine workers transitioning to renewable energy jobs',
    requirements: [
      'Assess transferable skills from coal mining',
      'Identify skill gaps for renewable energy roles',
      'Design training curriculum and timeline',
      'Create partnerships with training institutions',
      'Develop job placement strategy',
      'Include psychological and financial support'
    ],
    deliverables: [
      'Skills assessment framework',
      'Training curriculum outline',
      'Partnership agreements template',
      'Financial support package proposal',
      'Success metrics and evaluation plan'
    ],
    duration: '3 weeks',
    points: 250
  },
  {
    id: 'local-manufacturing-strategy',
    title: 'Local Manufacturing Development Strategy',
    description: 'Create a business plan to establish local solar panel manufacturing in South Africa',
    requirements: [
      'Market analysis of current imports vs local demand',
      'Technology and equipment requirements',
      'Supply chain development plan',
      'Financial projections and funding sources',
      'Job creation estimates and skills requirements',
      'Policy recommendations for government support'
    ],
    deliverables: [
      'Executive summary and business plan',
      'Financial model with 5-year projections',
      'Supply chain mapping',
      'Skills development plan',
      'Policy advocacy document'
    ],
    duration: '4 weeks',
    points: 300
  }
];

export const realWorldData = {
  southAfricaEnergyStats: {
    coalPercentage: 80,
    renewablePercentage: 10,
    mpumalangaCoalProduction: 83, // percentage of SA coal production
    coalWorkers: 91000,
    unemploymentRate: 31.9, // Q3 2023
    youthNotInEducationOrWork: 32.7, // percentage
    reipppProjectsProcured: 11904, // MW
    reipppProjectsOnline: 6106, // MW
    solarImportsFromChina2023: 17.5 // billion Rand
  },
  jobCreationData: {
    windFarmJobsPer100MW: {min: 7, max: 11},
    constructionJobsTemporary: true,
    engineeringJobsLocation: 'Often international',
    localContentRequirements: 'Required by REIPPPP'
  },
  globalContext: {
    justEnergyTransitionPillars: 5,
    parisAgreementCommitment: 'South Africa NDC',
    coalRetirementBy2035: 22000 // MW
  }
};