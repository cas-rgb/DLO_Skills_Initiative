import {
  users,
  courses,
  courseSections,
  courseModules,
  enrollments,
  moduleCompletions,
  audioCompletions,
  moduleQuizCompletions,
  moduleNarrations,
  quizzes,
  quizQuestions,
  quizAttempts,
  quizResponses,
  type User,
  type UpsertUser,
  type Course,
  type InsertCourse,
  type CourseSection,
  type InsertCourseSection,
  type CourseModule,
  type InsertCourseModule,
  type Enrollment,
  type InsertEnrollment,
  type ModuleCompletion,
  type InsertModuleCompletion,
  type AudioCompletion,
  type InsertAudioCompletion,
  type ModuleQuizCompletion,
  type InsertModuleQuizCompletion,
  type Quiz,
  type InsertQuiz,
  type QuizQuestion,
  type InsertQuizQuestion,
  type QuizAttempt,
  type InsertQuizAttempt,
  type QuizResponse,
  type InsertQuizResponse,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and } from "drizzle-orm";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Course operations
  getCourses(): Promise<Course[]>;
  getCourse(id: string): Promise<Course | undefined>;
  createCourse(course: InsertCourse): Promise<Course>;
  
  // Section operations
  getCourseSections(courseId: string): Promise<CourseSection[]>;
  createSection(section: InsertCourseSection): Promise<CourseSection>;
  
  // Module operations
  getCourseModules(courseId: string): Promise<CourseModule[]>;
  getSectionModules(sectionId: string): Promise<CourseModule[]>;
  getModule(id: string): Promise<CourseModule | undefined>;
  createModule(module: InsertCourseModule): Promise<CourseModule>;
  
  // Enrollment operations
  getUserEnrollments(userId: string): Promise<Enrollment[]>;
  enrollUser(enrollment: InsertEnrollment): Promise<Enrollment>;
  getUserEnrollment(userId: string, courseId: string): Promise<Enrollment | undefined>;
  
  // Progress tracking
  markModuleComplete(userId: string, moduleId: string): Promise<ModuleCompletion>;
  getUserModuleCompletions(userId: string): Promise<ModuleCompletion[]>;
  updateEnrollmentProgress(userId: string, courseId: string, progress: number): Promise<void>;
  
  // Quiz operations
  getQuizzes(courseId?: string): Promise<Quiz[]>;
  getQuiz(id: string): Promise<Quiz | undefined>;
  createQuiz(quiz: InsertQuiz): Promise<Quiz>;
  updateQuiz(id: string, quiz: Partial<InsertQuiz>): Promise<Quiz>;
  deleteQuiz(id: string): Promise<void>;
  
  // Quiz question operations
  getQuizQuestions(quizId: string): Promise<QuizQuestion[]>;
  createQuizQuestion(question: InsertQuizQuestion): Promise<QuizQuestion>;
  updateQuizQuestion(id: string, question: Partial<InsertQuizQuestion>): Promise<QuizQuestion>;
  deleteQuizQuestion(id: string): Promise<void>;
  
  // Quiz attempt operations
  getUserQuizAttempts(userId: string, quizId?: string): Promise<QuizAttempt[]>;
  createQuizAttempt(attempt: InsertQuizAttempt): Promise<QuizAttempt>;
  updateQuizAttempt(id: string, attempt: Partial<InsertQuizAttempt>): Promise<QuizAttempt>;
  submitQuizAttempt(attemptId: string, responses: InsertQuizResponse[]): Promise<QuizAttempt>;
  
  // Quiz grading operations
  getQuizAttemptDetails(attemptId: string): Promise<QuizAttempt & { responses: QuizResponse[]; quiz: Quiz; questions: QuizQuestion[] } | undefined>;
  gradeQuizAttempt(attemptId: string, gradedBy: string, feedback?: string): Promise<QuizAttempt>;
  getAttemptsToGrade(instructorId: string): Promise<QuizAttempt[]>;
  
  // Module narration operations
  getModuleById(id: string): Promise<CourseModule | undefined>;
  getModuleNarration(moduleId: string): Promise<any>;
  saveModuleNarration(moduleId: string, data: any): Promise<void>;
  updateModuleNarration(moduleId: string, data: any): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Course operations
  async getCourses(): Promise<Course[]> {
    return await db.select().from(courses).where(eq(courses.isPublished, true)).orderBy(desc(courses.createdAt));
  }

  async getCourse(id: string): Promise<Course | undefined> {
    const [course] = await db.select().from(courses).where(eq(courses.id, id));
    return course;
  }

  async createCourse(courseData: InsertCourse): Promise<Course> {
    const [course] = await db.insert(courses).values(courseData).returning();
    return course;
  }

  // Section operations
  async getCourseSections(courseId: string): Promise<CourseSection[]> {
    return await db
      .select()
      .from(courseSections)
      .where(eq(courseSections.courseId, courseId))
      .orderBy(courseSections.orderIndex);
  }

  async createSection(sectionData: InsertCourseSection): Promise<CourseSection> {
    const [section] = await db.insert(courseSections).values(sectionData).returning();
    return section;
  }

  // Module operations
  async getCourseModules(courseId: string): Promise<CourseModule[]> {
    return await db
      .select()
      .from(courseModules)
      .where(eq(courseModules.courseId, courseId))
      .orderBy(courseModules.orderIndex);
  }

  async getSectionModules(sectionId: string): Promise<CourseModule[]> {
    return await db
      .select()
      .from(courseModules)
      .where(eq(courseModules.sectionId, sectionId))
      .orderBy(courseModules.orderIndex);
  }

  async getModule(id: string): Promise<CourseModule | undefined> {
    const [module] = await db.select().from(courseModules).where(eq(courseModules.id, id));
    return module;
  }

  async createModule(moduleData: InsertCourseModule): Promise<CourseModule> {
    const [module] = await db.insert(courseModules).values(moduleData).returning();
    return module;
  }

  // Enrollment operations
  async getUserEnrollments(userId: string): Promise<Enrollment[]> {
    return await db
      .select()
      .from(enrollments)
      .where(eq(enrollments.userId, userId))
      .orderBy(desc(enrollments.enrolledAt));
  }

  async enrollUser(enrollmentData: InsertEnrollment): Promise<Enrollment> {
    const [enrollment] = await db.insert(enrollments).values(enrollmentData).returning();
    return enrollment;
  }

  async getUserEnrollment(userId: string, courseId: string): Promise<Enrollment | undefined> {
    const [enrollment] = await db
      .select()
      .from(enrollments)
      .where(and(
        eq(enrollments.userId, userId),
        eq(enrollments.courseId, courseId)
      ));
    return enrollment;
  }

  // Progress tracking
  async markModuleComplete(userId: string, moduleId: string): Promise<ModuleCompletion> {
    const [completion] = await db
      .insert(moduleCompletions)
      .values({ userId, moduleId })
      .returning();
    return completion;
  }

  async getUserModuleCompletions(userId: string): Promise<ModuleCompletion[]> {
    return await db
      .select()
      .from(moduleCompletions)
      .where(eq(moduleCompletions.userId, userId));
  }

  async updateEnrollmentProgress(userId: string, courseId: string, progress: number): Promise<void> {
    await db
      .update(enrollments)
      .set({ progress })
      .where(and(
        eq(enrollments.userId, userId),
        eq(enrollments.courseId, courseId)
      ));
  }

  // Audio completion tracking
  async markAudioComplete(userId: string, moduleId: string): Promise<AudioCompletion> {
    const [completion] = await db
      .insert(audioCompletions)
      .values({ userId, moduleId })
      .returning();
    return completion;
  }

  async getUserAudioCompletions(userId: string): Promise<AudioCompletion[]> {
    return await db
      .select()
      .from(audioCompletions)
      .where(eq(audioCompletions.userId, userId));
  }

  async isAudioCompleted(userId: string, moduleId: string): Promise<boolean> {
    const [completion] = await db
      .select()
      .from(audioCompletions)
      .where(and(
        eq(audioCompletions.userId, userId),
        eq(audioCompletions.moduleId, moduleId)
      ));
    return !!completion;
  }

  // Module quiz completion tracking
  async markModuleQuizComplete(userId: string, moduleId: string, score: number, answers: any): Promise<ModuleQuizCompletion> {
    const [completion] = await db
      .insert(moduleQuizCompletions)
      .values({ userId, moduleId, score, answers })
      .returning();
    return completion;
  }

  async getUserModuleQuizCompletions(userId: string): Promise<ModuleQuizCompletion[]> {
    return await db
      .select()
      .from(moduleQuizCompletions)
      .where(eq(moduleQuizCompletions.userId, userId));
  }

  async isModuleQuizCompleted(userId: string, moduleId: string): Promise<boolean> {
    const [completion] = await db
      .select()
      .from(moduleQuizCompletions)
      .where(and(
        eq(moduleQuizCompletions.userId, userId),
        eq(moduleQuizCompletions.moduleId, moduleId)
      ));
    return !!completion;
  }

  // Quiz operations
  async getQuizzes(courseId?: string): Promise<Quiz[]> {
    if (courseId) {
      return await db.select().from(quizzes).where(eq(quizzes.courseId, courseId));
    }
    return await db.select().from(quizzes);
  }

  async getQuiz(id: string): Promise<Quiz | undefined> {
    const [quiz] = await db.select().from(quizzes).where(eq(quizzes.id, id));
    return quiz;
  }

  async createQuiz(quiz: InsertQuiz): Promise<Quiz> {
    const [newQuiz] = await db.insert(quizzes).values(quiz).returning();
    return newQuiz;
  }

  async updateQuiz(id: string, quiz: Partial<InsertQuiz>): Promise<Quiz> {
    const [updatedQuiz] = await db
      .update(quizzes)
      .set({ ...quiz, updatedAt: new Date() })
      .where(eq(quizzes.id, id))
      .returning();
    return updatedQuiz;
  }

  async deleteQuiz(id: string): Promise<void> {
    await db.delete(quizzes).where(eq(quizzes.id, id));
  }

  // Quiz question operations
  async getQuizQuestions(quizId: string): Promise<QuizQuestion[]> {
    return await db
      .select()
      .from(quizQuestions)
      .where(eq(quizQuestions.quizId, quizId))
      .orderBy(quizQuestions.orderIndex);
  }

  async createQuizQuestion(question: InsertQuizQuestion): Promise<QuizQuestion> {
    const [newQuestion] = await db.insert(quizQuestions).values(question).returning();
    return newQuestion;
  }

  async updateQuizQuestion(id: string, question: Partial<InsertQuizQuestion>): Promise<QuizQuestion> {
    const [updatedQuestion] = await db
      .update(quizQuestions)
      .set(question)
      .where(eq(quizQuestions.id, id))
      .returning();
    return updatedQuestion;
  }

  async deleteQuizQuestion(id: string): Promise<void> {
    await db.delete(quizQuestions).where(eq(quizQuestions.id, id));
  }

  // Quiz attempt operations
  async getUserQuizAttempts(userId: string, quizId?: string): Promise<QuizAttempt[]> {
    if (quizId) {
      return await db
        .select()
        .from(quizAttempts)
        .where(eq(quizAttempts.userId, userId))
        .where(eq(quizAttempts.quizId, quizId))
        .orderBy(desc(quizAttempts.startedAt));
    }
    return await db
      .select()
      .from(quizAttempts)
      .where(eq(quizAttempts.userId, userId))
      .orderBy(desc(quizAttempts.startedAt));
  }

  async createQuizAttempt(attempt: InsertQuizAttempt): Promise<QuizAttempt> {
    const [newAttempt] = await db.insert(quizAttempts).values(attempt).returning();
    return newAttempt;
  }

  async updateQuizAttempt(id: string, attempt: Partial<InsertQuizAttempt>): Promise<QuizAttempt> {
    const [updatedAttempt] = await db
      .update(quizAttempts)
      .set(attempt)
      .where(eq(quizAttempts.id, id))
      .returning();
    return updatedAttempt;
  }

  async submitQuizAttempt(attemptId: string, responses: InsertQuizResponse[]): Promise<QuizAttempt> {
    // Insert all responses
    const insertedResponses = await db.insert(quizResponses).values(responses).returning();
    
    // Calculate score
    let totalPoints = 0;
    let earnedPoints = 0;
    
    for (const response of insertedResponses) {
      const [question] = await db
        .select()
        .from(quizQuestions)
        .where(eq(quizQuestions.id, response.questionId!));
      
      if (question) {
        totalPoints += question.points || 1;
        earnedPoints += response.pointsEarned || 0;
      }
    }
    
    const score = totalPoints > 0 ? Math.round((earnedPoints / totalPoints) * 100) : 0;
    
    // Update attempt with results
    const [updatedAttempt] = await db
      .update(quizAttempts)
      .set({
        submittedAt: new Date(),
        score,
        totalPoints,
        earnedPoints,
        isPassed: score >= 70 // Default passing score
      })
      .where(eq(quizAttempts.id, attemptId))
      .returning();
    
    return updatedAttempt;
  }

  async getQuizAttemptDetails(attemptId: string): Promise<QuizAttempt & { responses: QuizResponse[]; quiz: Quiz; questions: QuizQuestion[] } | undefined> {
    const [attempt] = await db.select().from(quizAttempts).where(eq(quizAttempts.id, attemptId));
    if (!attempt) return undefined;
    
    const [quiz] = await db.select().from(quizzes).where(eq(quizzes.id, attempt.quizId));
    const questions = await db.select().from(quizQuestions).where(eq(quizQuestions.quizId, attempt.quizId));
    const responses = await db.select().from(quizResponses).where(eq(quizResponses.attemptId, attemptId));
    
    return {
      ...attempt,
      quiz,
      questions,
      responses
    };
  }

  async gradeQuizAttempt(attemptId: string, gradedBy: string, feedback?: string): Promise<QuizAttempt> {
    const [updatedAttempt] = await db
      .update(quizAttempts)
      .set({
        gradedAt: new Date(),
        gradedBy,
        feedback
      })
      .where(eq(quizAttempts.id, attemptId))
      .returning();
    
    return updatedAttempt;
  }

  async getAttemptsToGrade(instructorId: string): Promise<QuizAttempt[]> {
    return await db
      .select()
      .from(quizAttempts)
      .innerJoin(quizzes, eq(quizAttempts.quizId, quizzes.id))
      .where(eq(quizzes.createdBy, instructorId))
      .orderBy(desc(quizAttempts.submittedAt));
  }

  // Module narration operations
  async getModuleById(id: string): Promise<CourseModule | undefined> {
    return this.getModule(id);
  }

  async getModuleNarration(moduleId: string): Promise<any> {
    try {
      const [narration] = await db
        .select()
        .from(moduleNarrations)
        .where(eq(moduleNarrations.moduleId, moduleId));
      return narration;
    } catch (error) {
      console.error("Error getting module narration:", error);
      return null;
    }
  }

  async saveModuleNarration(moduleId: string, data: any): Promise<void> {
    try {
      await db
        .insert(moduleNarrations)
        .values({
          moduleId,
          teacherScript: data.teacherScript,
          voiceType: data.voiceType || "female",
          scriptGeneratedAt: new Date(),
        })
        .onConflictDoUpdate({
          target: moduleNarrations.moduleId,
          set: {
            teacherScript: data.teacherScript,
            scriptGeneratedAt: new Date(),
            updatedAt: new Date(),
          },
        });
    } catch (error) {
      console.error("Error saving module narration:", error);
    }
  }

  async updateModuleNarration(moduleId: string, data: any): Promise<void> {
    try {
      await db
        .update(moduleNarrations)
        .set({
          audioFilePath: data.audioFilePath,
          audioGeneratedAt: new Date(),
          updatedAt: new Date(),
        })
        .where(eq(moduleNarrations.moduleId, moduleId));
    } catch (error) {
      console.error("Error updating module narration:", error);
    }
  }
}

export const storage = new DatabaseStorage();