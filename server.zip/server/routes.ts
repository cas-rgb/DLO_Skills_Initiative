import type { Express } from "express";
import { createServer, type Server } from "http";
import path from "path";
import express from "express";
import { z } from "zod";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import {
  generateCourseNarration,
  generateSectionAudio,
  generateAITutorSpeech,
  generateContextualResponse,
  generateTeacherScript,
  saveAudioFile
} from "./gemini";

// Helper function to convert facilitator scripts to Naledi's narration style
function convertFacilitatorScriptToNaledi(scriptContent: string, moduleNumber: number): string {
  // Extract key content from the facilitator script
  const lines = scriptContent.split('\n');
  let content = '';

  // Extract the module title and learning objectives
  const moduleTitle = lines.find(line => line.startsWith('# Module'))?.replace(/^# /, '') || `Module ${moduleNumber}`;

  // Find learning objectives section
  const objectivesStart = lines.findIndex(line => line.includes('Learning Objectives'));
  const objectivesEnd = lines.findIndex((line, index) => index > objectivesStart && line.startsWith('---'));

  let objectives = '';
  if (objectivesStart !== -1 && objectivesEnd !== -1) {
    objectives = lines.slice(objectivesStart, objectivesEnd)
      .filter(line => line.startsWith('- '))
      .map(line => line.replace(/^- /, ''))
      .join(', ');
  }

  // Extract key content sections
  const contentSections = [];
  let currentSection = '';
  let inContentSection = false;

  for (const line of lines) {
    if (line.startsWith('### ') || line.startsWith('#### ')) {
      if (currentSection.trim()) {
        contentSections.push(currentSection.trim());
      }
      currentSection = line.replace(/^#{3,4} /, '') + '\n';
      inContentSection = true;
    } else if (line.startsWith('## ')) {
      inContentSection = false;
    } else if (inContentSection && line.trim() && !line.startsWith('**') && !line.includes('Facilitator')) {
      currentSection += line + '\n';
    }
  }

  if (currentSection.trim()) {
    contentSections.push(currentSection.trim());
  }

  // Create Naledi's narrative style
  const nalediScript = `
Hello! I'm Naledi, your AI learning companion for the Just Energy Transition course. Welcome to ${moduleTitle}.

In this module, we'll explore ${objectives || 'important concepts about energy transition'}. I'm here to guide you through this journey with a warm South African perspective.

Let me share some insights about what we'll cover today:

${contentSections.slice(0, 3).map(section => {
  // Clean up the section content for narration
  const cleanSection = section
    .replace(/\*\*(.*?)\*\*/g, '$1') // Remove bold markers
    .replace(/\*(.*?)\*/g, '$1') // Remove italic markers
    .replace(/^"(.*)"$/gm, '$1') // Remove quotes
    .replace(/\n+/g, ' ') // Replace line breaks with spaces
    .trim();

  return cleanSection;
}).join('\n\nNow, let me tell you about another important aspect: ')}

As we go through this module together, remember that energy transition is not just about technology - it's about creating opportunities for all African communities. Each concept we explore today will help you understand how to be part of this transformation.

Take your time with the material, and remember - I'm here to support your learning journey. Let's begin this exciting exploration together!
  `.trim();

  return nalediScript;
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Ultra-fast root route handler optimized for deployment health checks
  app.get('/', (req, res, next) => {
    // Deployment health checks need instant response without any delays
    const userAgent = req.get('User-Agent') || '';
    const isHealthCheck = userAgent.includes('curl') || 
                         userAgent.includes('wget') || 
                         userAgent.includes('Go-http-client') ||
                         userAgent.includes('health') ||
                         userAgent.includes('deployment') ||
                         req.headers['x-health-check'] ||
                         req.query.health !== undefined;
    
    if (isHealthCheck) {
      // Ultra-minimal response for fastest possible health check
      return res.status(200).json({
        status: 'healthy',
        ready: true,
        timestamp: Date.now()
      });
    }
    
    // Let browser requests pass through to the frontend
    next();
  });

  // Ultra-fast health check endpoint - instant response without database checks
  app.get('/health', (req, res) => {
    // Ultra-minimal response for maximum deployment speed
    res.status(200).json({
      status: 'healthy',
      timestamp: Date.now(),
      uptime: Math.floor(process.uptime())
    });
  });

  // Ultra-fast ping endpoint for load balancers and monitoring
  app.get('/ping', (req, res) => {
    res.status(200).send('pong');
  });

  // Additional ultra-fast health check endpoint
  app.get('/healthz', (req, res) => {
    res.status(200).send('ok');
  });

  // Additional minimal endpoints for various health check patterns
  app.get('/status', (req, res) => {
    res.status(200).json({ status: 'ok' });
  });

  app.get('/heartbeat', (req, res) => {
    res.status(200).send('alive');
  });

  // Additional deployment-friendly endpoints
  app.get('/ready', (req, res) => {
    // Readiness probe - server is ready to handle traffic
    res.status(200).json({ ready: true, timestamp: Date.now() });
  });

  app.get('/alive', (req, res) => {
    // Liveness probe - server is alive and responsive
    res.status(200).json({ alive: true, uptime: Math.floor(process.uptime()) });
  });

  // Auth middleware
  await setupAuth(app);

  // Serve static LMS content - protected routes
  app.use('/lms', isAuthenticated, express.static(path.join(process.cwd(), 'lms')));
  app.use('/ai', isAuthenticated, express.static(path.join(process.cwd(), 'ai')));
  app.use('/data', isAuthenticated, express.static(path.join(process.cwd(), 'data')));

  // Serve audio files (public access for generated narrations)
  app.use('/audio', express.static(path.join(process.cwd(), 'public/audio')));

  // Redirect legacy course route to main course
  app.get('/course', isAuthenticated, (req, res) => {
    res.redirect('/courses/jet-energy-course');
  });

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Course routes
  app.get('/api/courses', async (req, res) => {
    try {
      const courses = await storage.getCourses();
      res.json(courses);
    } catch (error) {
      console.error("Error fetching courses:", error);
      res.status(500).json({ message: "Failed to fetch courses" });
    }
  });

  app.get('/api/courses/:id', async (req, res) => {
    try {
      const course = await storage.getCourse(req.params.id);
      if (!course) {
        return res.status(404).json({ message: "Course not found" });
      }
      res.json(course);
    } catch (error) {
      console.error("Error fetching course:", error);
      res.status(500).json({ message: "Failed to fetch course" });
    }
  });

  // Course sections routes
  app.get('/api/courses/:courseId/sections', async (req, res) => {
    try {
      const sections = await storage.getCourseSections(req.params.courseId);
      res.json(sections);
    } catch (error) {
      console.error("Error fetching course sections:", error);
      res.status(500).json({ message: "Failed to fetch course sections" });
    }
  });

  // Course modules routes
  app.get('/api/courses/:courseId/modules', async (req, res) => {
    try {
      const modules = await storage.getCourseModules(req.params.courseId);
      res.json(modules);
    } catch (error) {
      console.error("Error fetching course modules:", error);
      res.status(500).json({ message: "Failed to fetch course modules" });
    }
  });

  app.get('/api/sections/:sectionId/modules', async (req, res) => {
    try {
      const modules = await storage.getSectionModules(req.params.sectionId);
      res.json(modules);
    } catch (error) {
      console.error("Error fetching section modules:", error);
      res.status(500).json({ message: "Failed to fetch section modules" });
    }
  });

  app.get('/api/modules/:id', async (req, res) => {
    try {
      const module = await storage.getModule(req.params.id);
      if (!module) {
        return res.status(404).json({ message: "Module not found" });
      }
      res.json(module);
    } catch (error) {
      console.error("Error fetching module:", error);
      res.status(500).json({ message: "Failed to fetch module" });
    }
  });

  // Enrollment routes
  app.get('/api/users/:userId/enrollments', isAuthenticated, async (req, res) => {
    try {
      const enrollments = await storage.getUserEnrollments(req.params.userId);
      res.json(enrollments);
    } catch (error) {
      console.error("Error fetching user enrollments:", error);
      res.status(500).json({ message: "Failed to fetch enrollments" });
    }
  });

  app.post('/api/enrollments', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { courseId } = req.body;

      // Check if already enrolled
      const existingEnrollment = await storage.getUserEnrollment(userId, courseId);
      if (existingEnrollment) {
        return res.status(400).json({ message: "Already enrolled in this course" });
      }

      const enrollment = await storage.enrollUser({ userId, courseId });
      res.json(enrollment);
    } catch (error) {
      console.error("Error creating enrollment:", error);
      res.status(500).json({ message: "Failed to enroll in course" });
    }
  });

  // Progress tracking routes
  app.post('/api/modules/:moduleId/complete', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const moduleId = req.params.moduleId;

      const completion = await storage.markModuleComplete(userId, moduleId);

      // Update enrollment progress
      const module = await storage.getModule(moduleId);
      if (module?.courseId) {
        const allModules = await storage.getCourseModules(module.courseId);
        const userCompletions = await storage.getUserModuleCompletions(userId);
        const completedCount = userCompletions.filter(c =>
          allModules.some(m => m.id === c.moduleId)
        ).length;
        const progress = Math.round((completedCount / allModules.length) * 100);

        await storage.updateEnrollmentProgress(userId, module.courseId, progress);
      }

      res.json(completion);
    } catch (error) {
      console.error("Error marking module complete:", error);
      res.status(500).json({ message: "Failed to mark module complete" });
    }
  });

  app.get('/api/users/:userId/completions', isAuthenticated, async (req, res) => {
    try {
      const completions = await storage.getUserModuleCompletions(req.params.userId);
      res.json(completions);
    } catch (error) {
      console.error("Error fetching user completions:", error);
      res.status(500).json({ message: "Failed to fetch completions" });
    }
  });

  // Audio completion tracking
  app.post('/api/modules/:moduleId/audio-complete', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const moduleId = req.params.moduleId;

      const completion = await storage.markAudioComplete(userId, moduleId);
      res.json(completion);
    } catch (error) {
      console.error("Error marking audio complete:", error);
      res.status(500).json({ message: "Failed to mark audio complete" });
    }
  });

  app.get('/api/users/:userId/audio-completions', isAuthenticated, async (req, res) => {
    try {
      const completions = await storage.getUserAudioCompletions(req.params.userId);
      res.json(completions);
    } catch (error) {
      console.error("Error fetching audio completions:", error);
      res.status(500).json({ message: "Failed to fetch audio completions" });
    }
  });

  // Module quiz completion tracking
  app.post('/api/modules/:moduleId/quiz-complete', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const moduleId = req.params.moduleId;
      const { score, answers } = req.body;

      if (typeof score !== 'number' || score < 0 || score > 100) {
        return res.status(400).json({ message: "Invalid score. Must be a number between 0-100." });
      }

      const completion = await storage.markModuleQuizComplete(userId, moduleId, score, answers);
      res.json(completion);
    } catch (error) {
      console.error("Error marking quiz complete:", error);
      res.status(500).json({ message: "Failed to mark quiz complete" });
    }
  });

  app.get('/api/users/:userId/quiz-completions', isAuthenticated, async (req, res) => {
    try {
      const completions = await storage.getUserModuleQuizCompletions(req.params.userId);
      res.json(completions);
    } catch (error) {
      console.error("Error fetching quiz completions:", error);
      res.status(500).json({ message: "Failed to fetch quiz completions" });
    }
  });

  // Text-to-Speech AI API Routes
  // Generate Course Narration using Google Cloud TTS
  app.post("/api/ai/course-narration", isAuthenticated, async (req, res) => {
    try {
      const { text, options = {} } = req.body;

      if (!text) {
        return res.status(400).json({ error: "Text is required for narration" });
      }

      const result = await generateCourseNarration(text, options);

      // Return the audio data as base64 for immediate playback
      const audioBase64 = result.audioData.toString('base64');

      res.json({
        success: true,
        audioData: audioBase64,
        duration: result.duration,
        mimeType: 'audio/mpeg',
        message: "Course narration generated successfully"
      });
    } catch (error) {
      console.error("Error generating course narration:", error);
      res.status(500).json({ error: "Failed to generate course narration" });
    }
  });

  // Generate Section Audio and save to file
  app.post("/api/ai/section-audio", isAuthenticated, async (req, res) => {
    try {
      const { sectionId, content, options = {} } = req.body;

      if (!sectionId || !content) {
        return res.status(400).json({ error: "Section ID and content are required" });
      }

      const audioPath = await generateSectionAudio(sectionId, content, options);

      res.json({
        success: true,
        audioPath,
        sectionId,
        message: "Section audio generated successfully"
      });
    } catch (error) {
      console.error("Error generating section audio:", error);
      res.status(500).json({ error: "Failed to generate section audio" });
    }
  });

  // Generate AI Tutor Speech
  app.post("/api/ai/tutor-speech", isAuthenticated, async (req, res) => {
    try {
      const { message, context = "instruction" } = req.body;

      if (!message) {
        return res.status(400).json({ error: "Message is required for tutor speech" });
      }

      const audioData = await generateAITutorSpeech(message, context);
      const audioBase64 = audioData.toString('base64');

      res.json({
        success: true,
        audioData: audioBase64,
        mimeType: 'audio/mpeg',
        context,
        message: "AI tutor speech generated successfully"
      });
    } catch (error) {
      console.error("Error generating AI tutor speech:", error);
      res.status(500).json({ error: "Failed to generate AI tutor speech" });
    }
  });

  // AI Chat endpoint for Naledi tutor
  app.post("/api/ai/chat", isAuthenticated, async (req, res) => {
    try {
      const { message, context = {} } = req.body;

      if (!message) {
        return res.status(400).json({ error: "Message is required" });
      }

      // Build context-aware prompt for Naledi
      let contextPrompt = `You are Naledi, an AI learning companion helping students understand Just Energy Transition concepts.
      You are warm, encouraging, and focused on African energy contexts.`;

      if (context.moduleTitle) {
        contextPrompt += `\nCurrent Module: ${context.moduleTitle}`;
      }

      if (context.moduleContent) {
        contextPrompt += `\nModule Content Summary: ${context.moduleContent?.substring(0, 500)}...`;
      }

      contextPrompt += `\n\nStudent Question: ${message}

      Provide a helpful, educational response that:
      1. Directly answers the question
      2. Relates to Just Energy Transition concepts
      3. Uses examples relevant to African contexts when possible
      4. Encourages deeper learning and critical thinking
      5. Is conversational and supportive`;

      const response = await generateContextualResponse(contextPrompt, "tutor");

      res.json({
        success: true,
        response,
        context: context.moduleId || 'general'
      });
    } catch (error) {
      console.error("Error in AI chat:", error);
      res.status(500).json({ error: "Failed to generate AI response" });
    }
  });

  // Get module narration data
  app.get('/api/narration/module/:moduleId', isAuthenticated, async (req, res) => {
    try {
      const { moduleId } = req.params;

      const narration = await storage.getModuleNarration(moduleId);

      if (!narration) {
        return res.status(404).json({ error: "Module narration not found" });
      }

      res.json(narration);
    } catch (error) {
      console.error("Error fetching module narration:", error);
      res.status(500).json({ error: "Failed to fetch module narration" });
    }
  });

  // Step 1: Generate teacher scripts for modules
  app.post("/api/ai/generate-teacher-scripts", isAuthenticated, async (req, res) => {
    try {
      const { moduleId } = req.body;

      if (!moduleId) {
        return res.status(400).json({ error: "Module ID is required" });
      }

      // Get module content
      const module = await storage.getModuleById(moduleId);
      if (!module) {
        return res.status(404).json({ error: "Module not found" });
      }

      // Generate teacher script using AI
      const script = await generateTeacherScript(module.title, module.content);

      // Save script to database
      await storage.saveModuleNarration(moduleId, { teacherScript: script });

      res.json({
        success: true,
        moduleId,
        script,
        message: "Teacher script generated successfully"
      });
    } catch (error) {
      console.error("Error generating teacher script:", error);
      res.status(500).json({ error: "Failed to generate teacher script" });
    }
  });

  // Step 2-3: Convert script to audio and save
  app.post("/api/ai/generate-module-audio", isAuthenticated, async (req, res) => {
    try {
      const { moduleId } = req.body;

      if (!moduleId) {
        return res.status(400).json({ error: "Module ID is required" });
      }

      // Get saved teacher script
      const narration = await storage.getModuleNarration(moduleId);
      if (!narration || !narration.teacherScript) {
        return res.status(404).json({ error: "Teacher script not found. Generate script first." });
      }

      // Generate audio using Google Cloud TTS
      const audioResult = await generateCourseNarration(narration.teacherScript, {
        voiceType: narration.voiceType || "female"
      });

      // Save audio file
      const audioPath = `/audio/modules/${moduleId}.mp3`;
      await saveAudioFile(audioResult.audioData, audioPath);

      // Update database with audio file path
      await storage.updateModuleNarration(moduleId, { audioFilePath: audioPath });

      res.json({
        success: true,
        moduleId,
        audioPath,
        message: "Audio generated and saved successfully"
      });
    } catch (error) {
      console.error("Error generating module audio:", error);
      res.status(500).json({ error: "Failed to generate module audio" });
    }
  });

  // Step 4: Get audio for a specific module
  app.get("/api/ai/module-audio/:moduleId", isAuthenticated, async (req, res) => {
    try {
      const { moduleId } = req.params;

      const narration = await storage.getModuleNarration(moduleId);
      if (!narration || !narration.audioFilePath) {
        return res.status(404).json({ error: "Audio not found for this module" });
      }

      res.json({
        success: true,
        moduleId,
        audioPath: narration.audioFilePath,
        script: narration.teacherScript
      });
    } catch (error) {
      console.error("Error fetching module audio:", error);
      res.status(500).json({ error: "Failed to fetch module audio" });
    }
  });

  // Generate Naledi narration using your preferred TTS format
  app.post("/api/ai/naledi-narration", isAuthenticated, async (req, res) => {
    try {
      const { text, moduleId } = req.body;

      if (!text) {
        return res.status(400).json({ error: "Text is required for narration" });
      }

      // Use South African English voice (Naledi)
      const audioResult = await generateCourseNarration(text, {
        voiceType: "female", // Uses en-ZA-Standard-A
        speed: 0.9,
        sectionType: "content",
        useSSML: true
      });

      // Save audio file if moduleId provided
      let audioPath = null;
      if (moduleId) {
        audioPath = `/audio/modules/naledi-${moduleId}.mp3`;
        await saveAudioFile(audioResult.audioData, audioPath);
      }

      // Return audio data as base64 for immediate playback
      const audioBase64 = audioResult.audioData.toString('base64');

      res.json({
        success: true,
        audioData: audioBase64,
        audioPath,
        duration: audioResult.duration,
        mimeType: 'audio/mpeg',
        voice: 'en-ZA-Standard-A',
        message: "Naledi narration generated successfully"
      });
    } catch (error) {
      console.error("Error generating Naledi narration:", error);
      res.status(500).json({ error: "Failed to generate Naledi narration" });
    }
  });

  // Batch generate scripts and audio for all modules
  app.post("/api/ai/batch-generate-course-audio", isAuthenticated, async (req, res) => {
    try {
      const { courseId } = req.body;

      if (!courseId) {
        return res.status(400).json({ error: "Course ID is required" });
      }

      // Get all modules for the course
      const modules = await storage.getCourseModules(courseId);

      const results = await Promise.allSettled(
        modules.map(async (module: any) => {
          // Generate script
          const script = await generateTeacherScript(module.title, module.content);
          await storage.saveModuleNarration(module.id, { teacherScript: script });

          // Generate audio
          const audioResult = await generateCourseNarration(script, {
            voiceType: "female"
          });

          const audioPath = `/audio/modules/${module.id}.mp3`;
          await saveAudioFile(audioResult.audioData, audioPath);
          await storage.updateModuleNarration(module.id, { audioFilePath: audioPath });

          return { moduleId: module.id, audioPath };
        })
      );

      const successful = results
        .filter((result): result is PromiseFulfilledResult<any> => result.status === 'fulfilled')
        .map(result => result.value);

      const failed = results
        .map((result, index) => result.status === 'rejected' ? modules[index].id : null)
        .filter(Boolean);

      res.json({
        success: true,
        generated: successful,
        failed,
        message: `Generated audio for ${successful.length} modules, ${failed.length} failed`
      });
    } catch (error) {
      console.error("Error batch generating course audio:", error);
      res.status(500).json({ error: "Failed to batch generate course audio" });
    }
  });

  // Quiz Management Routes for Teachers/Facilitators

  // Get all quizzes for a course (or all quizzes if admin/facilitator)
  app.get('/api/quizzes', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      const courseId = req.query.courseId as string;

      if (!user || user.role === 'learner') {
        return res.status(403).json({ message: "Access denied. Teacher privileges required." });
      }

      const quizzes = await storage.getQuizzes(courseId);
      res.json(quizzes);
    } catch (error) {
      console.error("Error fetching quizzes:", error);
      res.status(500).json({ message: "Failed to fetch quizzes" });
    }
  });

  // Get quiz details with questions
  app.get('/api/quizzes/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);

      if (!user) {
        return res.status(403).json({ message: "Access denied" });
      }

      const quiz = await storage.getQuiz(req.params.id);
      if (!quiz) {
        return res.status(404).json({ message: "Quiz not found" });
      }

      const questions = await storage.getQuizQuestions(req.params.id);
      res.json({ ...quiz, questions });
    } catch (error) {
      console.error("Error fetching quiz:", error);
      res.status(500).json({ message: "Failed to fetch quiz" });
    }
  });

  // Create new quiz
  app.post('/api/quizzes', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);

      if (!user || user.role === 'learner') {
        return res.status(403).json({ message: "Access denied. Teacher privileges required." });
      }

      const quizData = {
        ...req.body,
        createdBy: userId
      };

      const quiz = await storage.createQuiz(quizData);
      res.status(201).json(quiz);
    } catch (error) {
      console.error("Error creating quiz:", error);
      res.status(500).json({ message: "Failed to create quiz" });
    }
  });

  // Update quiz
  app.put('/api/quizzes/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);

      if (!user || user.role === 'learner') {
        return res.status(403).json({ message: "Access denied. Teacher privileges required." });
      }

      const quiz = await storage.updateQuiz(req.params.id, req.body);
      res.json(quiz);
    } catch (error) {
      console.error("Error updating quiz:", error);
      res.status(500).json({ message: "Failed to update quiz" });
    }
  });

  // Delete quiz
  app.delete('/api/quizzes/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);

      if (!user || user.role === 'learner') {
        return res.status(403).json({ message: "Access denied. Teacher privileges required." });
      }

      await storage.deleteQuiz(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting quiz:", error);
      res.status(500).json({ message: "Failed to delete quiz" });
    }
  });

  // Quiz Questions Management

  // Add question to quiz
  app.post('/api/quizzes/:quizId/questions', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);

      if (!user || user.role === 'learner') {
        return res.status(403).json({ message: "Access denied. Teacher privileges required." });
      }

      const questionData = {
        ...req.body,
        quizId: req.params.quizId
      };

      const question = await storage.createQuizQuestion(questionData);
      res.status(201).json(question);
    } catch (error) {
      console.error("Error creating quiz question:", error);
      res.status(500).json({ message: "Failed to create quiz question" });
    }
  });

  // Update quiz question
  app.put('/api/quizzes/:quizId/questions/:questionId', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);

      if (!user || user.role === 'learner') {
        return res.status(403).json({ message: "Access denied. Teacher privileges required." });
      }

      const question = await storage.updateQuizQuestion(req.params.questionId, req.body);
      res.json(question);
    } catch (error) {
      console.error("Error updating quiz question:", error);
      res.status(500).json({ message: "Failed to update quiz question" });
    }
  });

  // Delete quiz question
  app.delete('/api/quizzes/:quizId/questions/:questionId', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);

      if (!user || user.role === 'learner') {
        return res.status(403).json({ message: "Access denied. Teacher privileges required." });
      }

      await storage.deleteQuizQuestion(req.params.questionId);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting quiz question:", error);
      res.status(500).json({ message: "Failed to delete quiz question" });
    }
  });

  // Student Quiz Taking Routes

  // Start quiz attempt
  app.post('/api/quizzes/:quizId/attempts', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;

      // Check existing attempts
      const existingAttempts = await storage.getUserQuizAttempts(userId, req.params.quizId);
      const quiz = await storage.getQuiz(req.params.quizId);

      if (!quiz) {
        return res.status(404).json({ message: "Quiz not found" });
      }

      if (quiz.maxAttempts && existingAttempts.length >= quiz.maxAttempts) {
        return res.status(400).json({ message: "Maximum attempts reached" });
      }

      const attemptData = {
        quizId: req.params.quizId,
        userId,
        attemptNumber: existingAttempts.length + 1
      };

      const attempt = await storage.createQuizAttempt(attemptData);
      res.status(201).json(attempt);
    } catch (error) {
      console.error("Error starting quiz attempt:", error);
      res.status(500).json({ message: "Failed to start quiz attempt" });
    }
  });

  // Submit quiz attempt
  app.post('/api/quiz-attempts/:attemptId/submit', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { responses } = req.body;

      if (!responses || !Array.isArray(responses)) {
        return res.status(400).json({ message: "Responses array is required" });
      }

      // Add attempt ID to each response
      const responseData = responses.map((response: any) => ({
        ...response,
        attemptId: req.params.attemptId
      }));

      const result = await storage.submitQuizAttempt(req.params.attemptId, responseData);
      res.json(result);
    } catch (error) {
      console.error("Error submitting quiz attempt:", error);
      res.status(500).json({ message: "Failed to submit quiz attempt" });
    }
  });

  // Get user's quiz attempts
  app.get('/api/users/:userId/quiz-attempts', isAuthenticated, async (req: any, res) => {
    try {
      const currentUserId = req.user.claims.sub;
      const targetUserId = req.params.userId;
      const user = await storage.getUser(currentUserId);

      // Users can only see their own attempts unless they're teachers/admins
      if (currentUserId !== targetUserId && (!user || user.role === 'learner')) {
        return res.status(403).json({ message: "Access denied" });
      }

      const quizId = req.query.quizId as string;
      const attempts = await storage.getUserQuizAttempts(targetUserId, quizId);
      res.json(attempts);
    } catch (error) {
      console.error("Error fetching quiz attempts:", error);
      res.status(500).json({ message: "Failed to fetch quiz attempts" });
    }
  });

  // Quiz Grading Routes for Teachers

  // Get attempts to grade
  app.get('/api/grading/attempts', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);

      if (!user || user.role === 'learner') {
        return res.status(403).json({ message: "Access denied. Teacher privileges required." });
      }

      const attempts = await storage.getAttemptsToGrade(userId);
      res.json(attempts);
    } catch (error) {
      console.error("Error fetching attempts to grade:", error);
      res.status(500).json({ message: "Failed to fetch attempts to grade" });
    }
  });

  // Get detailed attempt for grading
  app.get('/api/quiz-attempts/:attemptId/details', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);

      if (!user || user.role === 'learner') {
        return res.status(403).json({ message: "Access denied. Teacher privileges required." });
      }

      const attemptDetails = await storage.getQuizAttemptDetails(req.params.attemptId);
      if (!attemptDetails) {
        return res.status(404).json({ message: "Quiz attempt not found" });
      }

      res.json(attemptDetails);
    } catch (error) {
      console.error("Error fetching attempt details:", error);
      res.status(500).json({ message: "Failed to fetch attempt details" });
    }
  });

  // Grade quiz attempt
  app.post('/api/quiz-attempts/:attemptId/grade', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);

      if (!user || user.role === 'learner') {
        return res.status(403).json({ message: "Access denied. Teacher privileges required." });
      }

      const { feedback } = req.body;
      const gradedAttempt = await storage.gradeQuizAttempt(req.params.attemptId, userId, feedback);
      res.json(gradedAttempt);
    } catch (error) {
      console.error("Error grading quiz attempt:", error);
      res.status(500).json({ message: "Failed to grade quiz attempt" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}