import * as fs from "fs";
import * as path from "path";
import { GoogleGenAI, Modality } from "@google/genai";

// This API key is from Gemini Developer API Key, not vertex AI API Key
const ai = process.env.GEMINI_API_KEY ? new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY }) : null;

export async function generateCourseContent(topic: string, level: string = "beginner"): Promise<string> {
    if (!ai) {
        console.warn("Gemini API not configured, returning fallback content");
        return `# ${topic}\n\nThis is placeholder content for ${topic} at ${level} level. Please configure the Gemini API key to enable AI-generated content.`;
    }

    try {
        const prompt = `Create comprehensive course content about "${topic}" for ${level} level learners. 
        Include clear explanations, examples, and practical applications. 
        Structure the content with headers, bullet points, and engaging language suitable for African learners interested in energy transition and sustainable development.`;

        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
        });

        return response.text || "Unable to generate course content.";
    } catch (error) {
        console.error("Error generating course content:", error);
        return `# ${topic}\n\nThis is placeholder content for ${topic} at ${level} level. AI content generation is currently unavailable.`;
    }
}

export async function generateQuizQuestions(moduleContent: string, questionCount: number = 5): Promise<Array<{
    question: string;
    options: string[];
    correctAnswer: number;
    explanation: string;
}>> {
    const systemPrompt = `You are an expert educational content creator. Generate ${questionCount} multiple-choice quiz questions based on the provided module content. Each question should:
    1. Test understanding, not just memorization
    2. Have 4 plausible options
    3. Include a clear explanation for the correct answer
    4. Be relevant to energy transition and sustainable development in Africa

    Respond with JSON in this exact format:
    {
        "questions": [
            {
                "question": "string",
                "options": ["A", "B", "C", "D"],
                "correctAnswer": 0,
                "explanation": "string"
            }
        ]
    }`;

    if (!ai) {
        console.warn("Gemini API not configured, returning fallback quiz questions");
        return [{
            question: "What is the main goal of just energy transition?",
            options: [
                "To completely stop using energy",
                "To transition to renewable energy while ensuring social equity",
                "To increase energy consumption",
                "To maintain current energy systems"
            ],
            correctAnswer: 1,
            explanation: "Just energy transition focuses on moving to renewable energy sources while ensuring that the benefits are shared equitably and no communities are left behind."
        }];
    }

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-pro",
            config: {
                systemInstruction: systemPrompt,
                responseMimeType: "application/json",
                responseSchema: {
                    type: "object",
                    properties: {
                        questions: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    question: { type: "string" },
                                    options: { 
                                        type: "array",
                                        items: { type: "string" },
                                        minItems: 4,
                                        maxItems: 4
                                    },
                                    correctAnswer: { type: "number", minimum: 0, maximum: 3 },
                                    explanation: { type: "string" }
                                },
                                required: ["question", "options", "correctAnswer", "explanation"]
                            }
                        }
                    },
                    required: ["questions"]
                }
            },
            contents: moduleContent,
        });

        const rawJson = response.text;
        if (rawJson) {
            const data = JSON.parse(rawJson);
            return data.questions || [];
        }
        return [];
    } catch (error) {
        console.error("Error generating quiz questions:", error);
        return [];
    }
}

export async function analyzeStudentProgress(submissionText: string): Promise<{
    score: number;
    feedback: string;
    strengths: string[];
    improvements: string[];
    nextSteps: string[];
}> {
    const systemPrompt = `You are an expert educational assessment tool. Analyze the student's submission and provide:
    1. A score from 0-100
    2. Constructive feedback
    3. List of strengths demonstrated
    4. Areas for improvement
    5. Recommended next steps

    Focus on energy transition knowledge, critical thinking, and practical application.
    Be encouraging while providing actionable guidance.

    Respond with JSON in this format:
    {
        "score": number,
        "feedback": "string",
        "strengths": ["string"],
        "improvements": ["string"],
        "nextSteps": ["string"]
    }`;

    if (!ai) {
        console.warn("Gemini API not configured, returning fallback analysis");
        return {
            score: 70,
            feedback: "Your submission shows good understanding. AI analysis is currently unavailable.",
            strengths: ["Good effort", "Shows engagement"],
            improvements: ["Continue learning", "Practice more exercises"],
            nextSteps: ["Review module materials", "Complete additional practice"]
        };
    }

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-pro",
            config: {
                systemInstruction: systemPrompt,
                responseMimeType: "application/json",
                responseSchema: {
                    type: "object",
                    properties: {
                        score: { type: "number", minimum: 0, maximum: 100 },
                        feedback: { type: "string" },
                        strengths: { 
                            type: "array",
                            items: { type: "string" }
                        },
                        improvements: { 
                            type: "array",
                            items: { type: "string" }
                        },
                        nextSteps: { 
                            type: "array",
                            items: { type: "string" }
                        }
                    },
                    required: ["score", "feedback", "strengths", "improvements", "nextSteps"]
                }
            },
            contents: submissionText,
        });

        const rawJson = response.text;
        if (rawJson) {
            return JSON.parse(rawJson);
        }

        // Fallback response
        return {
            score: 70,
            feedback: "Your submission shows good understanding. Keep building on these concepts.",
            strengths: ["Good effort", "Shows engagement"],
            improvements: ["Expand on key concepts", "Provide more examples"],
            nextSteps: ["Review module materials", "Practice with additional exercises"]
        };
    } catch (error) {
        console.error("Error analyzing student progress:", error);
        return {
            score: 0,
            feedback: "Unable to analyze submission at this time.",
            strengths: [],
            improvements: ["Please resubmit your work"],
            nextSteps: ["Contact your instructor for assistance"]
        };
    }
}

export async function generatePersonalizedRecommendations(
    userProfile: {
        completedModules: string[];
        interests: string[];
        careerGoals: string[];
        location: string;
    }
): Promise<{
    courseSuggestions: string[];
    careerPaths: string[];
    localOpportunities: string[];
    skillsToFocus: string[];
}> {
    const systemPrompt = `You are a career guidance expert specializing in energy transition and sustainable development in Africa. 
    Based on the user's profile, provide personalized recommendations.

    Consider:
    - Their completed modules and demonstrated interests
    - Career goals and location
    - Opportunities specific to their region in Africa
    - Skills needed for energy transition careers

    Respond with JSON in this format:
    {
        "courseSuggestions": ["string"],
        "careerPaths": ["string"],
        "localOpportunities": ["string"],
        "skillsToFocus": ["string"]
    }`;

    if (!ai) {
        console.warn("Gemini API not configured, returning fallback recommendations");
        return {
            courseSuggestions: ["Energy Basics", "Renewable Technologies"],
            careerPaths: ["Energy Technician", "Solar Installer"],
            localOpportunities: ["Local solar projects", "Energy consulting"],
            skillsToFocus: ["Technical skills", "Communication"]
        };
    }

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-pro",
            config: {
                systemInstruction: systemPrompt,
                responseMimeType: "application/json",
                responseSchema: {
                    type: "object",
                    properties: {
                        courseSuggestions: { 
                            type: "array",
                            items: { type: "string" }
                        },
                        careerPaths: { 
                            type: "array",
                            items: { type: "string" }
                        },
                        localOpportunities: { 
                            type: "array",
                            items: { type: "string" }
                        },
                        skillsToFocus: { 
                            type: "array",
                            items: { type: "string" }
                        }
                    },
                    required: ["courseSuggestions", "careerPaths", "localOpportunities", "skillsToFocus"]
                }
            },
            contents: JSON.stringify(userProfile),
        });

        const rawJson = response.text;
        if (rawJson) {
            return JSON.parse(rawJson);
        }

        // Fallback response
        return {
            courseSuggestions: ["Advanced Energy Systems", "Renewable Energy Policy"],
            careerPaths: ["Renewable Energy Engineer", "Sustainability Consultant"],
            localOpportunities: ["Solar installation projects", "Energy efficiency consulting"],
            skillsToFocus: ["Technical analysis", "Project management"]
        };
    } catch (error) {
        console.error("Error generating recommendations:", error);
        return {
            courseSuggestions: [],
            careerPaths: [],
            localOpportunities: [],
            skillsToFocus: []
        };
    }
}

export async function analyzeCourseMaterial(filePath: string): Promise<string> {
    if (!ai) {
        console.warn("Gemini API not configured, returning fallback analysis");
        return "Course material analysis is currently unavailable. Please configure the Gemini API key to enable AI-powered content analysis.";
    }

    try {
        const fileContent = await fs.promises.readFile(filePath, 'utf-8');

        const prompt = `Analyze this educational material and provide:
        1. Key learning objectives
        2. Main concepts covered
        3. Difficulty level assessment
        4. Suggestions for improvement
        5. Recommended prerequisites

        Material content:
        ${fileContent}`;

        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
        });

        return response.text || "Unable to analyze the course material.";
    } catch (error) {
        console.error("Error analyzing course material:", error);
        throw new Error(`Failed to analyze course material: ${error}`);
    }
}

export async function generateEducationalImage(
    prompt: string,
    imagePath: string,
): Promise<void> {
    if (!ai) {
        console.warn("Gemini API not configured, skipping image generation");
        throw new Error("Image generation is currently unavailable. Please configure the Gemini API key.");
    }

    try {
        const enhancedPrompt = `Educational illustration for African energy transition course: ${prompt}. 
        Style: Clean, professional, informative, suitable for learning materials. 
        Include diverse representation and African context where relevant.`;

        const response = await ai.models.generateContent({
            model: "gemini-2.0-flash-preview-image-generation",
            contents: [{ role: "user", parts: [{ text: enhancedPrompt }] }],
            config: {
                responseModalities: [Modality.TEXT, Modality.IMAGE],
            },
        });

        const candidates = response.candidates;
        if (!candidates || candidates.length === 0) {
            throw new Error("No image generated");
        }

        const content = candidates[0].content;
        if (!content || !content.parts) {
            throw new Error("No image content received");
        }

        for (const part of content.parts) {
            if (part.inlineData && part.inlineData.data) {
                const imageData = Buffer.from(part.inlineData.data, "base64");
                await fs.promises.writeFile(imagePath, imageData);
                console.log(`Educational image saved as ${imagePath}`);
                return;
            }
        }

        throw new Error("No image data found in response");
    } catch (error) {
        console.error("Error generating educational image:", error);
        throw new Error(`Failed to generate educational image: ${error}`);
    }
}

export async function generateVoiceover(
    text: string,
    filename: string,
): Promise<string> {
    if (!ai) {
        throw new Error("Gemini API key not configured for TTS");
    }

    try {
        // Clean up text for better speech synthesis
        const cleanText = text
            .replace(/<[^>]*>/g, '') // Remove HTML tags
            .replace(/\s+/g, ' ') // Normalize whitespace
            .trim();

        // Use the new TTS model with the existing GoogleGenAI client
        const response = await ai.models.generateContent({
            model: "gemini-2.5-pro-preview-tts",
            contents: [{
                role: "user",
                parts: [{ text: cleanText }]
            }],
            config: {
                responseModalities: ["AUDIO"],
                speechConfig: {
                    voiceConfig: {
                        prebuiltVoiceConfig: {
                            voiceName: "Aoede"
                        }
                    }
                }
            }
        });

        // Check for audio data in response
        const candidates = response.candidates;
        if (!candidates || candidates.length === 0) {
            throw new Error("No audio candidates received");
        }

        const content = candidates[0].content;
        if (!content || !content.parts) {
            throw new Error("No audio content parts received");
        }

        // Find audio data in the response parts
        let audioData = null;
        for (const part of content.parts) {
            if (part.inlineData && part.inlineData.data) {
                audioData = Buffer.from(part.inlineData.data, 'base64');
                break;
            }
        }

        if (!audioData) {
            throw new Error("No audio data found in response");
        }

        // Save the audio file
        const outputPath = `public/audio/${filename}`;
        await fs.promises.mkdir('public/audio', { recursive: true });
        await fs.promises.writeFile(outputPath, audioData);

        console.log(`Voiceover saved as ${outputPath}`);
        return outputPath;
    } catch (error) {
        console.error("Error generating voiceover:", error);
        throw new Error(`Failed to generate voiceover: ${error}`);
    }
}

// Generate teacher script for a module
export async function generateTeacherScript(moduleTitle: string, moduleContent: string): Promise<string> {
    try {
        // Strip HTML tags from content for analysis
        const cleanContent = moduleContent
            .replace(/<[^>]*>/g, '') // Remove HTML tags
            .replace(/\s+/g, ' ') // Normalize whitespace
            .trim();

        const prompt = `You are an expert educational content creator specializing in energy transition education for African learners.

        Create a conversational, engaging teacher narration script for the following module:

        Module Title: ${moduleTitle}
        Module Content: ${cleanContent}

        Requirements for the script:
        1. Use a warm, encouraging teaching voice similar to Harvard online courses
        2. Start with a welcoming introduction
        3. Break down complex concepts into digestible explanations
        4. Include natural pauses and transitions (mark with "...")
        5. Add emphasis where important (use *emphasis* markers)
        6. Include real-world examples relevant to African contexts
        7. Use conversational language that feels like a teacher speaking directly to the student
        8. End with a summary and encouragement to continue learning
        9. Keep the total length to about 3-5 minutes of speech (approximately 400-750 words)

        Remember: This will be converted to speech, so write it as if you're speaking, not reading.`;

        if (!ai) {
            console.warn("Gemini API not configured, returning fallback teacher script");
            return `Welcome to ${moduleTitle}! This is a placeholder script since AI content generation is currently unavailable. Please configure the Gemini API key to enable personalized teaching scripts.`;
        }

        const response = await ai.models.generateContent({
            model: "gemini-2.5-pro",
            contents: prompt,
        });

        return response.text || "Unable to generate teacher script.";
    } catch (error) {
        console.error("Error generating teacher script:", error);
        throw new Error(`Failed to generate teacher script: ${error}`);
    }
}

// Save audio file to disk
export async function saveAudioFile(audioData: Buffer, filePath: string): Promise<void> {
    try {
        // Ensure the directory exists
        const fullPath = path.join(process.cwd(), 'public', filePath);
        const dir = path.dirname(fullPath);
        await fs.promises.mkdir(dir, { recursive: true });

        // Save the audio file
        await fs.promises.writeFile(fullPath, audioData);
        console.log(`Audio file saved to: ${fullPath}`);
    } catch (error) {
        console.error("Error saving audio file:", error);
        throw new Error(`Failed to save audio file: ${error}`);
    }
}

// Enhanced course narration with SSML and context-aware voice selection
export async function generateCourseNarration(
    text: string,
    options: {
        voiceType?: "male" | "female";
        speed?: number;
        sectionType?: "introduction" | "content" | "conclusion" | "quiz" | "explanation";
        useSSML?: boolean;
    } = {}
): Promise<{ audioData: Buffer; duration: number; audioUrl?: string }> {
    try {
        const { voiceType = "female", speed = 0.9, sectionType = "content", useSSML = true } = options;

        // Process text for better speech synthesis
        let processedText = text;
        if (useSSML) {
            processedText = convertToSSML(text, sectionType);
        } else {
            processedText = preprocessTextForSpeech(text);
        }

        // Select appropriate voice based on content type and preference
        const voiceConfig = getEducationalVoiceConfig(voiceType, sectionType);

        const request = {
            input: useSSML ? { ssml: processedText } : { text: processedText },
            voice: voiceConfig,
            audioConfig: {
                audioEncoding: "MP3" as const,
                speakingRate: speed,
                pitch: getContextualPitch(sectionType),
                volumeGainDb: 2.0, // Slightly louder for clarity
                effectsProfileId: ["headphone-class-device"], // Optimize for learning
            },
        };

        // Use Gemini TTS instead of Google Cloud TTS
        if (!ai) {
            throw new Error("Gemini API key not configured for TTS");
        }

        const response = await ai.models.generateContent({
            model: "gemini-2.5-pro-preview-tts",
            contents: [{
                role: "user",
                parts: [{ text: processedText }]
            }],
            config: {
                responseModalities: ["AUDIO"],
                speechConfig: {
                    voiceConfig: {
                        prebuiltVoiceConfig: {
                            voiceName: "Aoede"
                        }
                    }
                }
            }
        });

        // Check for audio data in response
        const candidates = response.candidates;
        if (!candidates || candidates.length === 0) {
            throw new Error("No audio candidates received");
        }

        const content = candidates[0].content;
        if (!content || !content.parts) {
            throw new Error("No audio content parts received");
        }

        // Find audio data in the response parts
        let audioData = null;
        for (const part of content.parts) {
            if (part.inlineData && part.inlineData.data) {
                audioData = Buffer.from(part.inlineData.data, 'base64');
                break;
            }
        }

        if (!audioData) {
            throw new Error("No audio data found in response");
        }

        // Estimate duration (rough calculation based on word count and speaking rate)
        const wordCount = text.split(/\s+/).length;
        const avgWordsPerMinute = 150 / speed; // Adjusted for speaking rate
        const estimatedDuration = Math.ceil((wordCount / avgWordsPerMinute) * 60);

        return {
            audioData,
            duration: estimatedDuration
        };
    } catch (error) {
        console.error("Error generating course narration:", error);
        throw new Error(`Failed to generate course narration: ${error}`);
    }
}

// Convert plain text to SSML for better educational speech synthesis
function convertToSSML(text: string, sectionType: string): string {
    let ssml = `<speak>`;

    // Add section-specific prosody and emphasis
    switch (sectionType) {
        case "introduction":
            ssml += `<prosody rate="medium" pitch="+2st" volume="loud">`;
            break;
        case "conclusion":
            ssml += `<prosody rate="slow" pitch="-1st" volume="medium">`;
            break;
        case "quiz":
            ssml += `<prosody rate="medium" pitch="+1st" volume="loud">`;
            break;
        case "explanation":
            ssml += `<prosody rate="slow" pitch="0st" volume="medium">`;
            break;
        default:
            ssml += `<prosody rate="medium" pitch="0st" volume="medium">`;
    }

    // Process the text for better educational speech
    let processedText = text
        // Remove HTML tags
        .replace(/<[^>]*>/g, '')
        // Add pauses for punctuation
        .replace(/\./g, '.<break time="0.6s"/>')
        .replace(/,/g, ',<break time="0.3s"/>')
        .replace(/:/g, ':<break time="0.5s"/>')
        .replace(/;/g, ';<break time="0.4s"/>')
        .replace(/\?/g, '?<break time="0.7s"/>')
        .replace(/!/g, '!<break time="0.7s"/>')
        // Emphasize important educational terms
        .replace(/\b(important|key|critical|essential|fundamental|remember|note)\b/gi, '<emphasis level="moderate">$1</emphasis>')
        .replace(/\b(energy transition|renewable energy|just transition|sustainability|climate change)\b/gi, '<emphasis level="strong">$1</emphasis>')
        .replace(/\b(solar|wind|hydroelectric|geothermal|biomass)\b/gi, '<emphasis level="moderate">$1</emphasis>')
        // Spell out technical abbreviations for clarity
        .replace(/\bJET\b/g, '<say-as interpret-as="spell-out">JET</say-as> - Just Energy Transition')
        .replace(/\bREIPPPP\b/g, 'Renewable Energy Independent Power Producer Procurement Programme')
        .replace(/\bCOP\b/g, '<say-as interpret-as="spell-out">COP</say-as>')
        .replace(/\bGW\b/g, 'Gigawatts')
        .replace(/\bMW\b/g, 'Megawatts')
        .replace(/\bkW\b/g, 'Kilowatts')
        .replace(/\bCO2\b/g, 'Carbon Dioxide')
        // Add longer pauses for paragraph breaks and section transitions
        .replace(/\n\s*\n/g, '<break time="1.2s"/>')
        .replace(/Module \d+/g, '<break time="1s"/>$&<break time="0.8s"/>')
        .replace(/Section \d+/g, '<break time="0.8s"/>$&<break time="0.6s"/>');

    ssml += processedText;
    ssml += `</prosody></speak>`;

    return ssml;
}

// Preprocess text for non-SSML speech synthesis
function preprocessTextForSpeech(text: string): string {
    return text
        // Remove HTML tags
        .replace(/<[^>]*>/g, '')
        // Convert abbreviations for better pronunciation
        .replace(/\bJET\b/g, 'Just Energy Transition')
        .replace(/\bREIPPPP\b/g, 'Renewable Energy Independent Power Producer Procurement Programme')
        .replace(/\bCOP\b/g, 'Conference of the Parties')
        .replace(/\bGW\b/g, 'Gigawatts')
        .replace(/\bMW\b/g, 'Megawatts')
        .replace(/\bkW\b/g, 'Kilowatts')
        .replace(/\bCO2\b/g, 'Carbon Dioxide')
        .replace(/\bUK\b/g, 'United Kingdom')
        .replace(/\bUSA?\b/g, 'United States')
        .replace(/\bEU\b/g, 'European Union')
        // Clean up extra spaces
        .replace(/\s+/g, ' ')
        .trim();
}

// Get voice configuration optimized for educational content
function getEducationalVoiceConfig(
    voiceType: "male" | "female" = "female",
    sectionType: "introduction" | "content" | "conclusion" | "quiz" | "explanation" = "content"
) {
    // Configure voice based on options - prioritize South African accent for Naledi
        const voiceConfig = {
            languageCode: voiceType === "male" ? "en-US" : "en-ZA", // Use South African English
            name: voiceType === "male" ? "en-US-Standard-J" : "en-ZA-Standard-A", // South African female voice
            ssmlGender: voiceType === "male" ? "MALE" : "FEMALE"
        };

    return voiceConfig;
}

// Get contextual pitch adjustments for different section types
function getContextualPitch(sectionType: string): number {
    switch (sectionType) {
        case "introduction":
            return 1.0; // Slightly higher pitch for welcoming tone
        case "quiz":
            return 0.5; // Neutral pitch for clarity
        case "explanation":
            return -0.5; // Slightly lower pitch for authority
        case "conclusion":
            return 0.8; // Encouraging tone
        default:
            return 0.0; // Neutral
    }
}

// Generate audio for course sections with intelligent caching and optimization
export async function generateSectionAudio(
    sectionId: string,
    content: string,
    options: Parameters<typeof generateCourseNarration>[1] = {}
): Promise<string> {
    try {
        // Create unique filename with timestamp to avoid conflicts
        const timestamp = Date.now();
        const voiceType = options.voiceType || "female";
        const sectionType = options.sectionType || "content";
        const filename = `course-${sectionId}-${sectionType}-${voiceType}-${timestamp}.mp3`;
        const audioPath = `data/audio/${filename}`;

        // Ensure audio directory exists
        await fs.promises.mkdir('data/audio', { recursive: true });

        const { audioData } = await generateCourseNarration(content, options);

        await fs.promises.writeFile(audioPath, audioData);

        console.log(`Generated audio for section ${sectionId}: ${audioPath}`);
        return `/data/audio/${filename}`;
    } catch (error) {
        console.error(`Error generating section audio for ${sectionId}:`, error);
        throw new Error(`Failed to generate section audio: ${error}`);
    }
}

// Generate interactive course audio with AI tutor personality
export async function generateAITutorSpeech(
    message: string,
    context: "greeting" | "instruction" | "encouragement" | "feedback" | "question" = "instruction"
): Promise<Buffer> {
    try {
        // Add personality to the AI tutor's speech based on context
        let enhancedMessage = message;

        switch (context) {
            case "greeting":
                enhancedMessage = `Hello! I'm Naledi, your AI learning companion. ${message}`;
                break;
            case "encouragement":
                enhancedMessage = `Great work! ${message} Keep up the excellent progress!`;
                break;
            case "feedback":
                enhancedMessage = `Let me help you understand this better. ${message}`;
                break;
            case "question":
                enhancedMessage = `Here's a question to test your understanding: ${message}`;
                break;
        }

        const { audioData } = await generateCourseNarration(enhancedMessage, {
            voiceType: "female",
            speed: 0.95,
            sectionType: context === "question" ? "quiz" : "content",
            useSSML: true
        });

        return audioData;
    } catch (error) {
        console.error("Error generating AI tutor speech:", error);
        throw new Error(`Failed to generate AI tutor speech: ${error}`);
    }
}

// Generate contextual AI responses for the Naledi chatbot
export async function generateContextualResponse(
    prompt: string,
    responseType: "tutor" | "assistant" | "expert" = "tutor"
): Promise<string> {
    try {
        // Build appropriate persona based on response type
        let systemInstruction = "";

        switch (responseType) {
            case "tutor":
                systemInstruction = `You are Naledi, a warm and encouraging AI tutor specializing in Just Energy Transition education for African learners. 
                You provide clear, supportive explanations with relevant African examples. 
                Always be patient, encouraging, and focused on building understanding step by step.
                Use conversational language that's accessible to learners at all levels.`;
                break;
            case "assistant":
                systemInstruction = `You are a helpful educational assistant focused on energy transition topics.
                Provide clear, factual information with practical examples.`;
                break;
            case "expert":
                systemInstruction = `You are an expert in energy transition and sustainable development in Africa.
                Provide detailed, technical responses with current data and policy insights.`;
                break;
        }

        if (!ai) {
            console.warn("Gemini API not configured, returning fallback response");
            return "I'm currently unavailable as the AI service is not configured. Please contact your instructor for assistance.";
        }

        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            config: {
                systemInstruction,
                temperature: 0.7,
                maxOutputTokens: 1000
            },
            contents: prompt,
        });

        return response.text || "I'm having trouble generating a response right now. Please try again.";
    } catch (error) {
        console.error("Error generating contextual response:", error);
        return "I apologize, but I'm having difficulty responding at the moment. Please try rephrasing your question or try again later.";
    }
}